clear;clc


%% Generate the spreadsheet "alphas 48" in "figures.xlsx"

st_date = 197401; et_date = 201612;
z = xlsread('Portfolio_ret.xlsx','FF5','A2:I653','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
rf = z(tt,7)/100;
mkt = z(tt,2)/100;
tdate = z(tt,1);
yy = floor(tdate/100); mm = floor(tdate - yy*100);

z = xlsread('Portfolio_ret.xlsx','Anomaly','A3:BS518','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
f5 = z(tt,2:7)/100; % benchmark: 1, 3, 5, 6 factors
G = z(tt,2:end)/100;
[T,L] = size(G);


%% 48 Industry 
[~, nam48] = xlsread('Portfolio_ret.xlsx','FF48vw','B2:AW2','basic'); 
z = xlsread('Portfolio_ret.xlsx','FF48vw','A3:AW530','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
N = size(z,2)-1;
R48 = z(tt,2:end)/100 - rf*ones(1,N);
 


K=5; 

[pca1G, ~, ~] = func_3pca(G, K);
 pcaf = -pca1G*100;
 rraf  = func_rraff(R48,G,K)*100;
[~,~,~,~,~,~,~,stats] = plsregress(G,R48,K);
plsf = -G*stats.W;

f5 = f5*100;
 
N = 48;
Y = R48(:,1:N)*100;
 res = nan(2*N, K+2,4); % 4 models: FF5, PCA, PLS, and RRA
for j = 1:N
    lhv = Y(:,j);
 rhv = f5(:,1:K);
 [b,tstat,~,~,~,adjR2,~] = olsnw(lhv,rhv,1,0);
 res(2*j-1,:,1) =[b', adjR2];
 res(2*j,:,1) = [tstat',nan];
 
 rhv = pcaf(:,1:K);
 [b,tstat,~,~,~,adjR2,~] = olsnw(lhv,rhv,1,0);
 res(2*j-1,:,2) =[b', adjR2];
 res(2*j,:,2) = [tstat',nan];

 rhv = plsf(:,1:K);
 [b,tstat,~,~,~,adjR2,~] = olsnw(lhv,rhv,1,0);
 res(2*j-1,:,3) =[b', adjR2];
 res(2*j,:,3) = [tstat',nan];
 
 rhv = rraf(:,1:K);
 [b,tstat,~,~,~,adjR2,~] = olsnw(lhv,rhv,1,0);
 res(2*j-1,:,4) =[b', adjR2];
 res(2*j,:,4) = [tstat',nan];
end
f5a  = abs(res(1:2:2*N,1,1));
pcaa = abs(res(1:2:2*N,1,2));
plsa = abs(res(1:2:2*N,1,3));
rraa = abs(res(1:2:2*N,1,4));


out=[f5a pcaa plsa rraa];
%output out to excel for plot figures

