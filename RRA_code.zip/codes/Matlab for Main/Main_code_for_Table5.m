clear;clc

%% For Table 5

st_date = 197401; et_date = 201612;
z = xlsread('Portfolio_ret.xlsx','FF5','A2:I653','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
rf = z(tt,7)/100;
mkt = z(tt,2)/100;
tdate = z(tt,1);
yy = floor(tdate/100); mm = floor(tdate - yy*100);

z = xlsread('Portfolio_ret.xlsx','Anomaly','A3:BS518','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
f5 = z(tt,2:7)/100; % benchmark: 1, 3, 5, 6 factors
G = z(tt,2:end)/100;
[T,L] = size(G);


%% 48 Industry 
z = xlsread('Portfolio_ret.xlsx','FF48vw','A3:AW530','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
N = size(z,2)-1;
R48 = z(tt,2:end)/100 - rf*ones(1,N);
 

%% 202 target
z = xlsread('Portfolio_ret.xlsx','Dacheng202vw','A3:GU554','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
N = size(z,2)-1;
R202 = z(tt,2:end)/100 - rf*ones(1,N);
 
%% use the first 30-years data to estimate
L = 360;
G0=G; 

%% all stocks
load stock_ret.mat;
ret = st_dataset; clear st_dataset;
ret = double(ret); % permno, year, mon th, xret, me, exchcd
ym0=ret(:,2)*100+ret(:,3);
tt = find(ym0>=tdate(L+1)&ym0<=tdate(end));
ret = ret(tt,:); ym = ym0(tt);
ret_all = [ret(:,1), ym, ret(:,4)]; 
tdate0 = tdate(L+1:end);

%% all-but-micro stocks
load stock_ret_nomicro.mat;
ret = st_dataset; clear st_dataset;
ret = double(ret); % permno, year, month, xret, me, exchcd
ym0=ret(:,2)*100+ret(:,3);
tt = find(ym0>=tdate(L+1)&ym0<=tdate(end));
ret = ret(tt,:); ym = ym0(tt);
ret_but = [ret(:,1), ym, ret(:,4)]; 

NF = [1 3 5 6];
NoFF = 4;

MPE = nan(NoFF,size(NF,2),4);  TR2 = nan(NoFF,size(NF,2),4);  
SR = nan(NoFF,size(NF,2),4);   A2R = nan(NoFF,size(NF,2),4);   


for j = 1:size(NF,2);
[w_rra, w_pls, w_pca]=extract_factors_weight(R48(1:L,:),G0(1:L,:),NF(j));
rra48 = G0(L+1:end,:)*w_rra; 
pls48 = G0(L+1:end,:)*w_pls;
pcaG0 = G0(L+1:end,:)*w_pca;

FFs = nan(T-L,NF(j),NoFF);
FFs(:,:,1)  = f5(L+1:end,1:NF(j)); FFs(:,:,2)  = pcaG0;   
FFs(:,:,3)= pls48;   FFs(:,:,4)= rra48;

 for i = 1:NoFF;  % No. of models
           
      ff = FFs(:,:,i); 
      
      res  = oos_performance_portfolio(R48(L+1:end,:), ff); % OUTres = [MPE, TotalR2, SR, A2R];
      MPE(i,j,1) = res(1); TR2(i,j,1) = res(2); 
      SR(i,j,1)=res(3); A2R(i,j,1) = res(4);
      
      res = oos_performance_portfolio(R202(L+1:end,:), ff);
      MPE(i,j,2)=res(1); TR2(i,j,2)= res(2); 
      SR(i,j,2) =res(3); A2R(i,j,2)= res(4);
      
      res = oos_performance_stock(ret_all, ff, tdate0);
      MPE(i,j,3)=res(1);  TR2(i,j,3)= res(2); 
      SR(i,j,3) =res(3); A2R(i,j,3)= res(4);
      
      res = oos_performance_stock(ret_but, ff, tdate0);
      MPE(i,j,4)=res(1);  TR2(i,j,4)= res(2); 
      SR(i,j,4) =res(3); A2R(i,j,4)= res(4);
      
 end 
     
end

%% Table 5 Performance of different factor models: Out-of-sample
Table5 = [[MPE(:,:,1),TR2(:,:,1)];nan(1,8);...
    [MPE(:,:,2),TR2(:,:,2)];nan(1,8);...
    [MPE(:,:,3),TR2(:,:,3)];nan(1,8);...
    [MPE(:,:,4),TR2(:,:,4)]];





 