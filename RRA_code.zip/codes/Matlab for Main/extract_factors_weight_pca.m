function [w_pca, w_pca2, w_pca3]=extract_factors_weight_pca(G,K)
% RRA = G*rra_w; PLS = G0*pls_w; PCA = G0*pca_w;
[T, N] = size(G);
mu = mean(G);

[E,v] = eig(cov(G));
[v,ind] = sort(diag(v),'descend');
E = E(:,ind);
E = E(:,1:K);
w_pca= E*inv(E'*E);

y2 = G'*G/T+10*mu'*mu;        %Lettau,Pelger
[E,v] = eig(y2);
[v,ind] = sort(diag(v),'descend');
E = E(:,ind(1:K));
w_pca2 = E*inv(E'*E);

[w_pca3,~,~,~]=EFS(G,0,K); %Balvers, Stivers

 









