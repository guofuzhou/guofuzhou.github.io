clear;clc

%% For Table 1

st_date = 197401; et_date = 201612;

z = xlsread('Portfolio_ret.xlsx','Anomaly','A3:BS518','basic');
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
f5 = z(tt,2:7)/100; % benchmark: 1, 3, 5, 6 factors
G = z(tt,2:end)/100;
[T,L] = size(G);

capm=f5(:,1);

tb(1,1)=mean(G(:,1))*100;
for i=2:L;
fct=G(:,i);
tb(i,1)=mean(fct)*100;
md1 = fitlm(capm,fct);
tb(i,2)=md1.Coefficients{1,1}*100;
tb(i,3)=md1.Coefficients{1,3};
end;

%% Table 1 Summary statistics of factor proxies
Table1=tb