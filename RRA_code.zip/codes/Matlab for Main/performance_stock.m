function OUTres = performance_stock(tdate, ret, FF)
% calculate total R2 and PE
% ret=[permno ym xret]) & FF 

permno = unique(ret(:,1));
N = length(permno);

R = ret; 

res = []; 
for i = 1:N
    i
  tt = find(R(:,1)==permno(i));
  Ri = R(tt,:); Ttemp = size(Ri,1);
  Ri(any(isnan(Ri), 2), :) = [];
  [~,ia,ib] = intersect(tdate, Ri(:,2));
  ffi = FF(ia,:);   Ri = Ri(ib,3);
  
 [b,bse,~,~,~] = regress_jc(Ri,[ones(length(Ri),1),ffi],0);
  
  adj = (length(Ri)-1)/(length(Ri)-1-size(ffi,2));
  yhat = [ones(length(Ri),1),ffi]*b;
  Res_Ri2 = sum((Ri-yhat).^2)*adj; 
  Ri2 = sum(Ri.^2);
  Alpha = b(1);
  Sig_res = std(Ri-yhat);
  Rbar = mean(Ri);

  %%          1        2    3      4        5          
  res = [res; Res_Ri2, Ri2, Alpha, Sig_res, Rbar];
end
 
MPE = 100*sqrt(mean(res(:,3).^2));
TotalR2 = 100*(1- sum(res(:,1))/sum(res(:,2)) );
SR = mean( abs( res(:,3)./res(:,4) ) );
A2R = mean( abs(res(:,3)./res(:,5)) ); 
OUTres = [MPE, TotalR2, SR, A2R];
 
 