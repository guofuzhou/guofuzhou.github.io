clear;clc

%% For Table 7

st_date = 197401; et_date = 201612;
z = xlsread('Portfolio_ret.xlsx','FF5','A2:I653','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
rf = z(tt,7)/100;
mkt = z(tt,2)/100;
tdate = z(tt,1);
yy = floor(tdate/100); mm = floor(tdate - yy*100);

z = xlsread('Portfolio_ret.xlsx','Anomaly','A3:BS518','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
f5 = z(tt,2:6)/100; % benchmark: 1, 3, 5, 6 factors
G = z(tt,2:end)/100;
[T,L] = size(G);
preF = f5;
preK = size(preF,2);
Xf = [ones(T,1), preF];
b = Xf\G(:,size(preF,2)+1:end);
Gf = G(:,size(preF,2)+1:end) - preF*b(2:end,:);



%% 48 Industry 
z = xlsread('Portfolio_ret.xlsx','FF48vw','A3:AW530','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
N = size(z,2)-1;
R48 = z(tt,2:end)/100 - rf*ones(1,N);
b = Xf\R48;
R48f = R48 - preF*b(2:end,:);


%% 202 target
z = xlsread('Portfolio_ret.xlsx','Dacheng202vw','A3:GU554','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
N = size(z,2)-1;
R202 = z(tt,2:end)/100 - rf*ones(1,N);
b = Xf\R202;
R202f = R202 - preF*b(2:end,:);

%% all-but-micro stocks
load stock_ret_nomicro.mat;
ret = st_dataset; clear st_dataset;
ret = double(ret); % permno, year, month, xret, me, exchcd
ret_no_micro = [ret(:,1), ret(:,2)*100+ret(:,3), ret(:,4)]; 

%% all stocks
load stock_ret.mat;
ret = st_dataset; clear st_dataset;
ret = double(ret); % permno, year, month, xret, me, exchcd
ret_all = [ret(:,1), ret(:,2)*100+ret(:,3), ret(:,4)]; 


NF = [6 7 8 10];
NoFF = 3;

MPE = nan(NoFF,size(NF,2),4);  TR2 = nan(NoFF,size(NF,2),4);  
SR = nan(NoFF,size(NF,2),4);   A2R = nan(NoFF,size(NF,2),4);   

for j =1:size(NF,2); % No. of factors
  rra48  = func_rraff(R48f,G,NF(j)-preK);
 [~,~,pls48] = plsregress(G,R48f,NF(j)-preK);
 [pca1G, pca2G, pca3G] = func_3pca(G(:,size(preF,2)+1:end), NF(j)-preK);
 
 FFs = nan(T,NF(j)-preK,NoFF);
 FFs(:,:,2) = pls48;    FFs(:,:,3) = rra48;  FFs(:,:,1)  = pca1G; 

 
 for i = 1:NoFF;  % No. of models
           
      ff = [preF, FFs(:,:,i)];  
      
      res  = performance_portfolio(R48, ff); % OUTres = [MPE, TotalR2, SR, A2R];
      MPE(i,j,1) = res(1); TR2(i,j,1) = res(2); 
      SR(i,j,1)=res(3); A2R(i,j,1) = res(4);
      
      res = performance_portfolio(R202, ff);
      MPE(i,j,2)=res(1); TR2(i,j,2)= res(2); 
      SR(i,j,2) =res(3); A2R(i,j,2)= res(4);
      
      res = performance_stock(tdate, ret_all, ff);
      MPE(i,j,3)=res(1);  TR2(i,j,3)= res(2); 
      SR(i,j,3) =res(3); A2R(i,j,3)= res(4);
      
      res = performance_stock(tdate, ret_no_micro, ff);
      MPE(i,j,4)=res(1);  TR2(i,j,4)= res(2); 
      SR(i,j,4) =res(3); A2R(i,j,4)= res(4);
      
    end
    clear ff FFs;
end



%% Table7 Performance of different factor models with pre-specified FF five factors
Table7 = [[MPE(:,:,1),TR2(:,:,1)];nan(1,8);...
    [MPE(:,:,2),TR2(:,:,2)];nan(1,8);...
    [MPE(:,:,3),TR2(:,:,3)];nan(1,8);...
    [MPE(:,:,4),TR2(:,:,4)]];












