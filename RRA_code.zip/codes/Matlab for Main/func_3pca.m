function [pca1, pca2, pca3] = func_3pca(R, K)
%% This is to generate 3 types of K-PCA factors
%% pca1=traditional; pca2=Lettau gamma=10; pca3:gamma=1, PE=0

[T, N] = size(R);
mu = mean(R);
y1 = R'*R/T-mu'*mu;
[E,v] = eig(y1);
[v,ind] = sort(diag(v),'descend');
E = E(:,ind(1:K)); 
pca1 = R*E*inv(E'*E); % the same as pca0

y2 = R'*R/T+10*mu'*mu; 
[E,v] = eig(y2);
[v,ind] = sort(diag(v),'descend');
E = E(:,ind(1:K));
pca2 = R*E*inv(E'*E);

y3 = R'*R/T + mu'*mu; 
[E,v] = eig(y3);
[v,ind] = sort(diag(v),'descend');
E = E(:,ind(1:K));
pca3 = R*E*inv(E'*E);



























