import os
import sys
clear = lambda: os.system('cls')
clear()
 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
pd.set_option('display.max_columns', None)
import statsmodels.api as sm 
import statsmodels.formula.api as smf
import scipy.stats as stats
import math
import patsy as pt
import linearmodels as plm
import datetime as dt

wt = pd.read_excel('figures.xlsx','factor weights 48', skiprows = 1) 
 
fig, (ax1, ax2, ax3)=plt.subplots(1,3, figsize=(12,18), sharey=True)
ax1.barh(wt.aName, wt.pca1)
ax1.set_ylim(-1,70)
ax1.set_title('PCA')
ax2.barh(wt.aName, wt.pls1)
ax2.set_title('PLS')
ax3.barh(wt.aName, wt.rra1) 
ax3.set_title('RRA')
plt.savefig('Fig_weights1f48.pdf',bbox_inches='tight')

fig, (ax2, ax3, ax4, ax5)=plt.subplots(1,4, figsize=(15,20), sharey=True)
ax2.barh(wt.aName, wt.rra2)
ax2.set_ylim(-1,70)
ax2.set_title('2nd')
ax3.barh(wt.aName, wt.rra3)
ax3.set_title('3rd')
ax4.barh(wt.aName, wt.rra4) 
ax4.set_title('4th')
ax5.barh(wt.aName, wt.rra5) 
ax5.set_title('5th')
plt.savefig('Fig_weights2_5f48.pdf',bbox_inches='tight')

alph = pd.read_excel('figures.xlsx','alphas 48', skiprows = 0) 
fig, (ax2, ax3, ax4, ax5)=plt.subplots(1,4, figsize=(15,20), sharey=True)
ax2.barh(alph.idx, alph.ff5, height=0.6)
ax2.set_ylim(-1,48)
ax2.set_xlim(0,1.)
ax2.set_title(r'FF5 ($\bar \alpha = 0.28\%$)')
ax3.barh(alph.idx, alph.pca, height=0.6)
ax3.set_title(r'PCA ($\bar \alpha = 0.85\%$)')
ax4.barh(alph.idx, alph.pls, height=0.6) 
ax4.set_title(r'PLS ($\bar \alpha = 0.26\%$)')
ax4.set_xlim(0,1.)
ax5.barh(alph.idx, alph.rra, height=0.6) 
ax5.set_title(r'RRA ($\bar \alpha = 0.14\%$)')
ax5.set_xlim(0, 1.)
plt.savefig('Fig_alpha48.pdf',bbox_inches='tight')
 
 
    
    
    
    