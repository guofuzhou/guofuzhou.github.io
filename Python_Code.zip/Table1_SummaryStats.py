#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 18 17:08:52 2018

@author: larryli
"""

import pandas as pd
import numpy as np

summary_stat=pd.DataFrame(columns=['Mean','Volatility','Rho'],index=np.arange(1,56))

ret=pd.read_excel('#Asset_Return.xlsx','Sheet1')
for i in range(1,56):
    ret_s=ret[ret['ID']==i]
    summary_stat.loc[[i],['Mean']]=ret_s['ExRet'].mean()*100*12
    summary_stat.loc[[i],['Volatility']]=ret_s['ExRet'].std()*100*np.sqrt(12)
    summary_stat.loc[[i],['Rho']]=ret_s['ExRet'].autocorr()


writer = pd.ExcelWriter('Table1_SummaryStatistics.xlsx')
pd.DataFrame.to_excel(summary_stat,writer,'Summary_Statistics')