import pandas as pd
import numpy as np
import statsmodels.formula.api as smf

# =============================================================================
# Objective: run the Wild bootstrap with only data from 1985-2009
# generate the wild bootstrap t-values for four cases
# i.    predictive regression with lagged volatiliaty scaled excess return
# ii.   predictive regression with lagged volatiliaty scaled excess return's sign
# iii.  predictive regression with cumulative volatiliaty scaled excess return
# iv.   predictive regression with cumulative volatiliaty scaled excess return' sign
# =============================================================================

# =============================================================================
# create the lagged volatiliaty scaled excess returns,  
# cumulative volatiliaty scaled excess returns,
# and their signs
# =============================================================================

ret=pd.read_excel('#Asset_Return.xlsx','Sheet1')
ret=ret[ret['YM']>=198501]# make sure all returns are after 198501
ret=ret[ret['YM']<=200912]# make sure all returns are before 2009012

ret['RF']=ret['Rf']+1#capital RF is the gross risk free rate
ret['Return']=ret['ExRet']+ret['RF']

ret_summary=pd.DataFrame()
for i in range(1,56):
    ret_sub=ret[ret['ID']==i]    
    #get the scaled excess return
    ret_sub['ExRetVol']=ret_sub['ExRet']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetVol_f1']=ret_sub['ExRetVol'].shift(-1)
    ret_sub['ExRetVol_l0']=ret_sub['ExRetVol'].shift(0)
    ret_sub['ExRetVol_l1']=ret_sub['ExRetVol'].shift(1)
    ret_sub['ExRetVol_l2']=ret_sub['ExRetVol'].shift(2)
    ret_sub['ExRetVol_l3']=ret_sub['ExRetVol'].shift(3)
    ret_sub['ExRetVol_l4']=ret_sub['ExRetVol'].shift(4)
    ret_sub['ExRetVol_l5']=ret_sub['ExRetVol'].shift(5)
    ret_sub['ExRetVol_l6']=ret_sub['ExRetVol'].shift(6)
    ret_sub['ExRetVol_l7']=ret_sub['ExRetVol'].shift(7)
    ret_sub['ExRetVol_l8']=ret_sub['ExRetVol'].shift(8)
    ret_sub['ExRetVol_l9']=ret_sub['ExRetVol'].shift(9)
    ret_sub['ExRetVol_l10']=ret_sub['ExRetVol'].shift(10)
    ret_sub['ExRetVol_l11']=ret_sub['ExRetVol'].shift(11)
    #get the cumulative excess return 
    ret_sub['ExRetCum1']=ret['ExRet']
    ret_sub['ExRetCum2']=(pd.rolling_apply(ret_sub['Return'],2,lambda x : x.prod())-pd.rolling_apply(ret_sub['RF'],2,lambda x : x.prod()))/2
    ret_sub['ExRetCum3']=(pd.rolling_apply(ret_sub['Return'],3,lambda x : x.prod())-pd.rolling_apply(ret_sub['RF'],3,lambda x : x.prod()))/3
    ret_sub['ExRetCum4']=(pd.rolling_apply(ret_sub['Return'],4,lambda x : x.prod())-pd.rolling_apply(ret_sub['RF'],4,lambda x : x.prod()))/4
    ret_sub['ExRetCum5']=(pd.rolling_apply(ret_sub['Return'],5,lambda x : x.prod())-pd.rolling_apply(ret_sub['RF'],5,lambda x : x.prod()))/5
    ret_sub['ExRetCum6']=(pd.rolling_apply(ret_sub['Return'],6,lambda x : x.prod())-pd.rolling_apply(ret_sub['RF'],6,lambda x : x.prod()))/6
    ret_sub['ExRetCum7']=(pd.rolling_apply(ret_sub['Return'],7,lambda x : x.prod())-pd.rolling_apply(ret_sub['RF'],7,lambda x : x.prod()))/7
    ret_sub['ExRetCum8']=(pd.rolling_apply(ret_sub['Return'],8,lambda x : x.prod())-pd.rolling_apply(ret_sub['RF'],8,lambda x : x.prod()))/8
    ret_sub['ExRetCum9']=(pd.rolling_apply(ret_sub['Return'],9,lambda x : x.prod())-pd.rolling_apply(ret_sub['RF'],9,lambda x : x.prod()))/9
    ret_sub['ExRetCum10']=(pd.rolling_apply(ret_sub['Return'],10,lambda x : x.prod())-pd.rolling_apply(ret_sub['RF'],10,lambda x : x.prod()))/10
    ret_sub['ExRetCum11']=(pd.rolling_apply(ret_sub['Return'],11,lambda x : x.prod())-pd.rolling_apply(ret_sub['RF'],11,lambda x : x.prod()))/11
    ret_sub['ExRetCum12']=(pd.rolling_apply(ret_sub['Return'],12,lambda x : x.prod())-pd.rolling_apply(ret_sub['RF'],12,lambda x : x.prod()))/12

    ret_sub['ExRetCumVol1']=ret_sub['ExRetCum1']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol2']=ret_sub['ExRetCum2']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol3']=ret_sub['ExRetCum3']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol4']=ret_sub['ExRetCum4']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol5']=ret_sub['ExRetCum5']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol6']=ret_sub['ExRetCum6']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol7']=ret_sub['ExRetCum7']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol8']=ret_sub['ExRetCum8']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol9']=ret_sub['ExRetCum9']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol10']=ret_sub['ExRetCum10']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol11']=ret_sub['ExRetCum11']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol12']=ret_sub['ExRetCum12']/ret_sub['Vol'].shift(1)

    ret_summary=pd.concat([ret_summary,ret_sub.iloc[12:]])#drop the first 12 variables
    
for i in range(0,12):
    new_name='ExRetVolSign_l'+str(i)
    old_name='ExRetVol_l'+str(i)
    ret_summary[new_name]=np.where(ret_summary[old_name]>=0,1,np.where(ret_summary[old_name]<0,-1,np.nan))

    new_name='ExRetCumVolSign'+str(i+1)
    old_name='ExRetCumVol'+str(i+1)
    ret_summary[new_name]=np.where(ret_summary[old_name]>=0,1,np.where(ret_summary[old_name]<0,-1,np.nan))

# =============================================================================
# prepare a table to fitted value and the residual value of the panel regression
# =============================================================================
    
fitted_residual=pd.DataFrame()
#keep four variables fitted, residual, explanatory 

for i in range(0,12):
    new_name='ExRetVol_l'+str(i)
    regression=ret_summary[['YM','ExRetVol_f1',new_name]].dropna()
    form="ExRetVol_f1 ~ ExRetVol_l"+str(i)
    result=smf.ols(formula=form, data=regression).fit(cov_type='cluster',cov_kwds={'groups': regression['YM']},use_t=True)
    fitted_residual['fitted_Lag'+str(i+1)]=result.fittedvalues
    fitted_residual['residual_Lag'+str(i+1)]=result.resid
    fitted_residual[new_name]=regression[new_name]

for i in range(0,12):
    new_name='ExRetVolSign_l'+str(i)
    regression=ret_summary[['YM','ExRetVol_f1',new_name]].dropna()
    form="ExRetVol_f1 ~ ExRetVolSign_l"+str(i)
    result=smf.ols(formula=form, data=regression).fit(cov_type='cluster',cov_kwds={'groups': regression['YM']},use_t=True)
    fitted_residual['fitted_LagSign'+str(i+1)]=result.fittedvalues
    fitted_residual['residual_LagSign'+str(i+1)]=result.resid
    fitted_residual[new_name]=regression[new_name]

for i in range(0,12):
    new_name='ExRetCumVol'+str(i+1)
    regression=ret_summary[['YM','ExRetVol_f1',new_name]].dropna()
    form="ExRetVol_f1 ~ ExRetCumVol"+str(i+1)
    result=smf.ols(formula=form, data=regression).fit(cov_type='cluster',cov_kwds={'groups': regression['YM']},use_t=True)
    fitted_residual['fitted_Cum'+str(i+1)]=result.fittedvalues
    fitted_residual['residual_Cum'+str(i+1)]=result.resid
    fitted_residual[new_name]=regression[new_name]

for i in range(0,12):
    new_name='ExRetCumVolSign'+str(i+1)
    regression=ret_summary[['YM','ExRetVol_f1',new_name]].dropna()
    form="ExRetVol_f1 ~ ExRetCumVolSign"+str(i+1)
    result=smf.ols(formula=form, data=regression).fit(cov_type='cluster',cov_kwds={'groups': regression['YM']},use_t=True)
    fitted_residual['fitted_CumSign'+str(i+1)]=result.fittedvalues
    fitted_residual['residual_CumSign'+str(i+1)]=result.resid
    fitted_residual[new_name]=regression[new_name]

fitted_residual[['YM','ExRetVol_f1']]=regression[['YM','ExRetVol_f1']]

# =============================================================================
# run the wild bootstrap regression
# =============================================================================

size=len(fitted_residual)
np.random.seed(10)

tLag_Wild=np.empty((10000,12))
tLagSign_Wild=np.empty((10000,12))
tCum_Wild=np.empty((10000,12))
tCumSign_Wild=np.empty((10000,12))

for n in range(0,10000):
    vera=np.random.uniform(0,1,size)
    vera=np.where(vera>=0.5,1,-1)
    fitted_residual['vera']=vera
    for i in range(1,13):
        fitted_residual['star_Lag'+str(i)]=fitted_residual['fitted_Lag'+str(i)]+fitted_residual['vera']*fitted_residual['residual_Lag'+str(i)]
        fitted_residual['star_LagSign'+str(i)]=fitted_residual['fitted_LagSign'+str(i)]+fitted_residual['vera']*fitted_residual['residual_LagSign'+str(i)]
        fitted_residual['star_Cum'+str(i)]=fitted_residual['fitted_Cum'+str(i)]+fitted_residual['vera']*fitted_residual['residual_Cum'+str(i)]
        fitted_residual['star_CumSign'+str(i)]=fitted_residual['fitted_CumSign'+str(i)]+fitted_residual['vera']*fitted_residual['residual_CumSign'+str(i)]
        
        regression=fitted_residual[['YM','star_Lag'+str(i),'ExRetVol_l'+str(i-1)]].dropna()
        form="star_Lag"+str(i)+" ~ ExRetVol_l"+str(i-1)
        result=smf.ols(formula=form, data=regression).fit(cov_type='cluster',cov_kwds={'groups': regression['YM']},use_t=True)
        tLag_Wild[n,i-1]=result.tvalues[1]        
        
        regression=fitted_residual[['YM','star_LagSign'+str(i),'ExRetVolSign_l'+str(i-1)]].dropna()
        form="star_LagSign"+str(i)+" ~ ExRetVolSign_l"+str(i-1)
        result=smf.ols(formula=form, data=regression).fit(cov_type='cluster',cov_kwds={'groups': regression['YM']},use_t=True)
        tLagSign_Wild[n,i-1]=result.tvalues[1]
        
        regression=fitted_residual[['YM','star_Cum'+str(i),'ExRetCumVol'+str(i)]].dropna()
        form="star_Cum"+str(i)+" ~ ExRetCumVol"+str(i)
        result=smf.ols(formula=form, data=regression).fit(cov_type='cluster',cov_kwds={'groups': regression['YM']},use_t=True)
        tCum_Wild[n,i-1]=result.tvalues[1]

        regression=fitted_residual[['YM','star_CumSign'+str(i),'ExRetCumVolSign'+str(i)]].dropna()
        form="star_CumSign"+str(i)+" ~ ExRetCumVolSign"+str(i)
        result=smf.ols(formula=form, data=regression).fit(cov_type='cluster',cov_kwds={'groups': regression['YM']},use_t=True)
        tCumSign_Wild[n,i-1]=result.tvalues[1]

Table6_Wild=pd.DataFrame(columns=['Lag','LagSign','Cum','CumSign'],index=np.arange(1,13))

for i in range(1,13):
    Table6_Wild.loc[[i],['Lag']]=np.percentile(tLag_Wild[:,i-1],97.5)
    Table6_Wild.loc[[i],['LagSign']]=np.percentile(tLagSign_Wild[:,i-1],97.5)
    Table6_Wild.loc[[i],['Cum']]=np.percentile(tCum_Wild[:,i-1],97.5)
    Table6_Wild.loc[[i],['CumSign']]=np.percentile(tCumSign_Wild[:,i-1],97.5)

pd.DataFrame.to_csv(Table6_Wild,'Table6_Wild.csv')