import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
#==============================================================================
# Define a function to calculate CW test
#==============================================================================
def CWtest(r_real, r_hat, r_bar,lag):
    f=(r_real-r_bar)**2-((r_real-r_hat)**2-(r_bar-r_hat)**2)
    f=pd.DataFrame(f,columns=['f'])
    f=sm.add_constant(f)
    f=f.dropna()
    result = smf.OLS(f['f'],f['const']).fit(cov_type='HAC',cov_kwds={'maxlags':lag})
    return result.tvalues[0]