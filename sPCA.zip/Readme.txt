This is a demo to use scaled PCA method to forecast inflation with macro factor

sPCAest.m is the program to estimate sPCA factors

main.m is the file to forecast inflation
however, in main.m, we have embedded the sPCA procedure within the program and have not used sPCAest.m separately

Select_AR_lag_SIC.m is used to estimate number of lagged inflation to control for 