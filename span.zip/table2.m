%
%	table2.m	Date: 12/15/1999
%
load figure4
delete table2.out
diary table2.out
for Ti = 1:length(T1),
    for Nj = 1:length(N1),
        fprintf('\n N = %3.0f, T = %3.0f\n',N1(Nj),T1(Ti))
        lr1 = squeeze(lr(Ti,Nj,:,:));
        wald1 = squeeze(wald(Ti,Nj,:,:));
        lm1 = squeeze(lm(Ti,Nj,:,:));
        n = length(wald1);
        fprintf('\n Comparison of Three Tests:\n')
        win = zeros(n);
        for i=1:n,
            for j=1:i,
                if (lr1(i,j)>wald1(i,j)&lr1(i,j)>lm1(i,j)),
                   win(i,j) = 1;
                end;
                if (wald1(i,j)>lr1(i,j)&wald1(i,j)>lm1(i,j)),
                   win(i,j) = 2;
                end;
                if (lm1(i,j)>lr1(i,j)&lm1(i,j)>wald1(i,j)),
                   win(i,j) = 3;
                end;
                fprintf('%2.0f',win(i,j))
            end;
            fprintf('\n')
        end;
        fprintf('\n')
        fprintf('\n Likelihood Ratio Test\n')
        for i=1:6:n,
            for j=1:6:i,
                fprintf('%8.4f',lr1(i,j))
                if (lr1(i,j)>wald1(i,j)&lr1(i,j)>lm1(i,j)),
                   fprintf('*')
                else,
                   fprintf(' ')
                end;
            end;
            fprintf('\n')
        end;
        fprintf('\n Wald Test\n')
        for i=1:6:n,
            for j=1:6:i,
                fprintf('%8.4f',wald1(i,j))
                if (wald1(i,j)>lr1(i,j)&wald1(i,j)>lm1(i,j)),
                   fprintf('*')
                else,
                   fprintf(' ')
                end;
            end;
            fprintf('\n')
        end;
        fprintf('\n Largrange Multiplier Test\n')
        for i=1:6:n,
            for j=1:6:i,
                fprintf('%8.4f',lm1(i,j))
                if (lm1(i,j)>lr1(i,j)&lm1(i,j)>wald1(i,j)),
                   fprintf('*')
                else,
                   fprintf(' ')
                end;
            end;
            fprintf('\n')
        end;
    end;
end;
diary off