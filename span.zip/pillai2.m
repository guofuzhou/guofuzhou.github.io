function p = pillai2(w,n1,n2)
%
%	This function finds out the P[f1+f2<w] where f1 and f2 are
%	two eigenvalues of A*inv(A+B) with A~W_2(n1,I_2) and B~W_2(n2,I_2).
%	This function relies on direct integration but it works for both
%	odd and even n1 and n2.
%
p = zeros(size(w));
m = (n1-3)/2;
n = (n2-3)/2;
kk = 2*beta(2*m+2,2*n+3);
kk1 = 2*beta(2*m+3,2*n+2);
for i=1:length(w)
    if w(i)>=2
       p(i) = 1;
    elseif w(i)>0
       v = w(i);
       u1 = (1-0.5*v)^2;
       v1 = 0.25*v*v;
       if rem(n,1)~=0&&rem(m,1)~=0
%
%	Both m and n are not integers, evaluate it numerically
%
%         p(i) = betainc(0.5*v,2*m+2,2*n+3)-quadl(@(x)(x.^m).*(max(0,1-v+x).^(n+1))/kk,max(0,v-1),0.25*v*v,1e-12);
          p(i) = betainc(0.5*v,2*m+3,2*n+2)+quadl(@(x)(x.^n).*(max(0,v-1+x).^(m+1))/kk1,max(0,1-v),u1,1e-12);

       elseif rem(m,1)~=0||(rem(n,1)==0&&m>n)
%
%	n is integer
%           
          x = cumprod(-(v1/u1)*[n+1:-1:1]./[m+2:m+n+2]);
          c = (v1^(m+1))*(u1^(n+1))/(m+1);
          y = c*(1+sum(x));
          if v>1
             y = y-((-1)^(n+1))*prod([1:n+1]./[m+2:m+n+2])*(v-1)^(m+n+2)/(m+1);
          end
          if y>1e-15		% May run into precision problem if y is too small
             p(i) = betainc(0.5*v,2*m+2,2*n+3)-y/kk;
          else
             p(i) = betainc(0.5*v,2*m+3,2*n+2)+quadl(@(x)(x.^n).*(max(0,v-1+x).^(m+1))/kk1,max(0,1-v),u1,1e-12);
          end
       else
%
%	m is integer
%
          x = cumprod(-(u1/v1)*[m+1:-1:1]./[n+2:m+n+2]);
          c = (v1^(m+1))*(u1^(n+1))/(n+1);
          y = c*(1+sum(x));
          if v<1
             y = y-((-1)^(m+1))*prod([1:m+1]./[n+2:m+n+2])*(1-v)^(m+n+2)/(n+1);
          end
          if y>1e-15
             p(i) = betainc(0.5*v,2*m+3,2*n+2)+y/kk1;
          else
             p(i) = betainc(0.5*v,2*m+2,2*n+3)-quadl(@(x)(x.^m).*(max(0,1-v+x).^(n+1))/kk,0,0.25*v*v,1e-12);
          end
       end
    end
    p(i) = min(1,max(0,p(i)));
end
