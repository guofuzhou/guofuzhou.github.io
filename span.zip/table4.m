%
%	Table4.m	Date: 11/02/99
%	This Matlab program uses simulation to obtain the size of the three 
% tests of spanning under the assumption that the residuals are
% multivariate t-distributed with 5 d.f.
%
nobs = 100000;
df = 5;
rand('state',100*sum(clock));
randn('state',100*sum(clock));
K = [2 5 10];
N = [1 2 5 10 25];
T = [60 120 240];
nK = length(K);
nN = length(N);
nT = length(T);
maxK = max(K);
maxT = max(T);
maxN = max(N);
p = 0.95;
fid = fopen('table4.out','W');
fprintf(fid,' Benchmark Returns are Normally Distributed\n');
fprintf(fid,' Degrees of Freedom of Multivariate-t Distrbution = %3.0f\n',df);
fprintf(fid,' Number of Simulations = %6.0f\n',nobs);
fprintf(fid,' Exact size of the test when asymptotic p-value is 5%%\n');
fprintf(fid,'   K     N     T      Wald    LR     LM\n');
%
%	Generate E to be multivariate-t with mean zero and variance I_N.
%	Generate X each time so the distribution is unconditional.
%
wald = zeros(nK,nN,nT,nobs);
lr = zeros(nK,nN,nT,nobs);
lm = zeros(nK,nN,nT,nobs);
for ii=1:nobs
    U = sqrt(chi2rnd(df,maxT,1)/(df-2));	% Set it to df-2 so Var[E]=I_N
    E = randn(maxT,maxN)./(U*ones(1,maxN));
    x = [ones(maxT,1) randn(maxT,maxK)];	% x is different each time
    for i=1:nK
        K1 = K(i);
        A = [1 zeros(1,K1); 0 -ones(1,K1)];
        for k=1:nT
            T1 = T(k);
            x1 = x(1:T1,1:K1+1);
            U = A*inv(x1'*x1)*x1';	% B = U'E under null hypothesis
            P1 = orth(U');		
            P3 = null(x1');
            E1 = E(1:T1,1:maxN);
            Y1 = P1'*E1;
            Y3 = P3'*E1;
            for j=1:nN
                N1 = N(j);
                Y1a = Y1(:,1:N1);
                Y3a = Y3(:,1:N1);
                ee = eig(Y1a*inv(Y3a'*Y3a)*Y1a');
                wald(i,j,k,ii) = T1*sum(ee);
                lr(i,j,k,ii) = T1*sum(log(1+ee));
                lm(i,j,k,ii) = T1*sum(ee./(1+ee));
            end
        end
    end
end
for i=1:nK
    K1 = K(i);
    for j=1:nN
        N1 = N(j);
        chi2cut = chi2inv(p,2*N1);
        for k=1:nT
            T1 = T(k);
            pwald = mean(wald(i,j,k,:)>chi2cut);
            plr = mean(lr(i,j,k,:)>chi2cut);
            plm = mean(lm(i,j,k,:)>chi2cut);
            fprintf(fid,' %5.0f %5.0f %5.0f  %6.3f %6.3f %6.3f\n',K1,N1,T1, ...
                    pwald,plr,plm);
        end
    end
end
fprintf(fid,'\n Exact size of the test when normal p-value is 5%%\n',df);
fprintf(fid,'   K     N     T      Wald    LR     LM\n');
for i=1:nK
    K1 = K(i)
    for j=1:nN
        N1 = N(j);
        df1 = 2*N1;
        df3 = N1;
        for k=1:nT
            T1 = T(k);
            if N1==1
               df2 = T1-K1-1;
               fcut = finv(p,df1,df2);
               u = 1/((df1/df2)*fcut+1);
               waldcut = T1*(1/u-1);
               lrcut = -T1*log(u);
               lmcut = T1*(1-u);               
               pwald = mean(wald(i,j,k,:)>waldcut);
               plr = mean(lr(i,j,k,:)>lrcut);
               plm = mean(lm(i,j,k,:)>lmcut);
            else
               df2 = 2*(T1-K1-N1);
               fcut = finv(p,df1,df2);
               u = 1/((df1/df2)*fcut+1)^2;
               lrcut = -T1*log(u);
               df4 = T1-N1-K1+1;
               waldcut = T1*waldinv(p,df3,df4);
               lmcut = T1*pillainv2(p,df3,df4);
               pwald = mean(wald(i,j,k,:)>waldcut);
               plr = mean(lr(i,j,k,:)>lrcut);
               plm = mean(lm(i,j,k,:)>lmcut);
            end
            fprintf(fid,' %5.0f %5.0f %5.0f  %6.3f %6.3f %6.3f\n',K1,N1,T1, ...
                    pwald,plr,plm);            
        end
    end
end
fclose(fid);
