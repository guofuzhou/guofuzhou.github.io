%
%	table7.m	Date: March 8, 2008
%	This Matlab program computes various asymptotic spanning tests 
%
load master.dat
US = master(:,2:3);
inter = master(:,4:10);
N = size(inter,2);
delete table7.out
diary table7.out
country = ['Australia';'Canada   ';'France   ';'Germany  ';'Italy    ';'Japan    ';'U.K.     '];
for ii=1:3
    if ii==1
       fprintf(' Period : 1970/1-2007/12\n')
       R1 = US;
       R2 = inter;
    end
    if ii==2
       fprintf('\n\n Period : 1970/1-1988/12\n')
       R1 = US(1:228,:);
       R2 = inter(1:228,:);
    end
    if ii==3
       fprintf('\n\n Period : 1989/1-2007/12\n')
       R1 = US(229:456,:);
       R2 = inter(229:456,:);
    end
    fprintf(' Country         W       W_e      W_a      J_1      J_2      J_3\n')
    for i=1:N
        [W,We,Wa,J1,J2,J3] = gmmspan(R1,R2(:,i));
        fprintf(' %9s    %6.3f   %6.3f   %6.3f   %6.3f   %6.3f   %6.3f\n', ...
             country(i,:),W,We,Wa,J1,J2,J3)
        fprintf('              %6.3f   %6.3f   %6.3f   %6.3f   %6.3f   %6.3f\n', ...
             1-chi2cdf([W We Wa J1 J2 J3],2))
    end
    [W,We,Wa,J1,J2,J3] = gmmspan(R1,R2);
    fprintf(' All          %6.3f   %6.3f   %6.3f   %6.3f   %6.3f   %6.3f\n', ...
             W,We,Wa,J1,J2,J3)
    fprintf('              %6.3f   %6.3f   %6.3f   %6.3f   %6.3f   %6.3f\n', ...
             1-chi2cdf([W We Wa J1 J2 J3],2*N))
end
diary off
