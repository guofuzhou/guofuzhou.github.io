%
%	First plot
%
for pp1=1:4
    if pp1==1    
       z = squeeze(zz(1,1,:,:));
       figure4b
       ylabel('$\omega_1^*$','FontSize',10)
       xlabel('$\omega_2^*$','FontSize',10)
       zlabel('Power','FontSize',10)
       title('$N=2,\;T-K=60$','FontSize',10)
    end
    if pp1==2    
       z = squeeze(zz(1,2,:,:));
       figure4b
       ylabel('$\omega_1^*$','FontSize',10)
       xlabel('$\omega_2^*$','FontSize',10)
       zlabel('Power','FontSize',10)
       title('$N=10,\;T-K=60$','FontSize',10)
    end
    if pp1==3    
       z = squeeze(zz(2,1,:,:));
       figure4b
       ylabel('$\omega_1^*$','FontSize',10)
       xlabel('$\omega_2^*$','FontSize',10)
       zlabel('Power','FontSize',10)
       title('$N=2,\;T-K=120$','FontSize',10)
    end
    if pp1==4    
       z = squeeze(zz(2,2,:,:));
       figure4b
       ylabel('$\omega_1^*$','FontSize',10)
       xlabel('$\omega_2^*$','FontSize',10)
       zlabel('Power','FontSize',10)
       title('$N=10,\;T-K=120$','FontSize',10)
    end
end
set(gcf,'PaperPosition',[0 0 7.5 5.5]);
