subplot(2,2,pp1)
surf(x2,x1,z)	% Reverse x and y since this is how surf works!
hold on
dz = diag(z);
fill3(zeros(2*n,1),[x1; x1(n:-1:1)],[zeros(n,1); z(n:-1:1,1)], ...
          [zeros(n,1); z(n:-1:1,1)]')
fill3([x2; x2(n:-1:1)],[x1; x1(n:-1:1)],[zeros(n,1); dz(n:-1:1)], ...
          [zeros(n,1); dz(n:-1:1)]')
for i=1:n-1
    fill3([x2(i) x2(i) x2(i+1)]',[x1(i) x1(i+1) x1(i+1)]', ...
          [z(i,i) z(i+1,i) z(i+1,i+1)]', ...
          [z(i,i) z(i+1,i) z(i+1,i+1)]')
end
axis([0 0.15 0 0.15 0 1])
plot3(x2,x1,dz)
plot3(zeros(n,1),x1,z(1,:))
plot3(x2,0.15*ones(n,1),z(:,n))
plot3([0 0],[0 0],[0 1-p])
plot3([0 0.15],[0 0.15],[0 0]);
set(gca,'box','off','TickDir','out','ZTick',[0:0.1:1],'FontSize',7,'Clim',[0 1])
