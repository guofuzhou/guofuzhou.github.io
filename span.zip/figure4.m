%
%	Figure4.m	Date: Oct 23, 1999
%	This Matlab program finds out the power function of spanning tests
%	when N=10
%
clear all
set(0,'DefaulttextInterpreter','latex')
rand('state',100*sum(clock));
randn('state',100*sum(clock));
nobs = 100000;
x1 = [0:0.005:0.15]';	  % omega_1^*
x2 = [0:0.005:0.15]';   % omega_2^*
n = length(x1);
T1 = [60 120];	% T1 is actually T-K
N1 = [2 10];
p = 0.95;
lr = zeros(length(T1),length(N1),n,n);
wald = zeros(length(T1),length(N1),n,n);
lm = zeros(length(T1),length(N1),n,n);
L = zeros(2);
Z = zeros(2);
for Ti=1:length(T1)
    T = T1(Ti);		% T is actually T-K
    for Nj=1:length(N1)
        N = N1(Nj);
        df1 = 2*N;
        df2 = 2*(T-N);
        df3 = T-N+1;
        fcut = 1+finv(p,df1,df2)*df1/df2;
        waldcut = waldinv(p,N,df3);
        lmcut = pillainv2(p,N,df3);
        for i=1:nobs
           if rem(i,1000)==0
              [Ti Nj i]
           end
%
%	Generate A and B
%
           L(1,1) = sqrt(chi2rnd(df3));
           L(2,2) = sqrt(chi2rnd(df3-1));
           L(2,1) = randn;
           B = L*L';
           H = zeros(2);
           if N>2
              H(1,1) = sqrt(chi2rnd(N-2));
              H(2,1) = randn;
           end
           if N>3
              H(2,2) = sqrt(chi2rnd(N-3));
           end
           S = H*H';
           Z = randn(2);
           for j=1:n
               w1 = sqrt((T-1)*x1(j));
               for k=1:n
                   if j>=k
                      w2 = sqrt((T-1)*x2(k));
                      Z1 = Z+diag([w1 w2]);
                      A = S+Z1'*Z1;	% A is a noncentral Wishart matrix
                      ee = eig(A*inv(B));
                      Ftest = sqrt(prod(1+ee));
                      waldtest = sum(ee);
                      lmtest = sum(ee./(1+ee));
                      lr(Ti,Nj,j,k) = lr(Ti,Nj,j,k)+(Ftest>fcut);
                      wald(Ti,Nj,j,k) = wald(Ti,Nj,j,k)+(waldtest>waldcut);
                      lm(Ti,Nj,j,k) = lm(Ti,Nj,j,k)+(lmtest>lmcut);
                   end
               end
           end
       end
       for j=1:n-1
           lr(Ti,Nj,j,j+1:n) = NaN;
           wald(Ti,Nj,j,j+1:n) = NaN;
           lm(Ti,Nj,j,j+1:n) = NaN;
       end
    end
end
lr = lr/nobs;
lr(:,:,1,1) = 1-p;
wald = wald/nobs;
wald(:,:,1,1) = 1-p;
lm = lm/nobs;
lm(:,:,1,1) = 1-p;
for pp=1:3
    if pp==1
       zz = lr;
       figure4a
       print -depsc figure4.eps
       !epstopdf figure4.eps
    end
    if pp==2
       zz = wald;
       figure4a
       print -depsc figure4a.eps
       !epstopdf figure4a.eps
    end
    if pp==3
       zz = lm;
       figure4a
       print -depsc figure4b.eps
       !epstopdf figure4b.eps
    end
end
save figure4 T1 N1 x1 x2 lr wald lm
