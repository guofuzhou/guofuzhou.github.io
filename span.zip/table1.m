%
%	Table1.m	Date: 11/02/99
%	This Matlab program computes the actual size of three asymptotic 
%	tests of spanning.
%
K = [2 5 10];
N = [1 2 5 10 25];
T = [60 120 240];
nK = length(K);
nN = length(N);
nT = length(T);
wald1 = zeros(nK,nN,nT);
lr = zeros(nK,nN,nT);
lm = zeros(nK,nN,nT);
wald1a = zeros(nK,nN,nT);
lra = zeros(nK,nN,nT);
lma = zeros(nK,nN,nT);
p = 0.95;
fid = fopen('table1.out','W');
fprintf(fid,' Exact size of the test when asymptotic p-value is 5%%\n');
fprintf(fid,'                                                 Modified\n');
fprintf(fid,'   K     N     T      Wald    LR     LM     Wald    LR     LM\n');
for i=1:nK,
    for j=1:nN;
        for k=1:nT;
            K1 = K(i);
            N1 = N(j);
            T1 = T(k);
            df1 = 2*N1;
            chi2cut = chi2inv(p,df1)/T1;
            adj1 = T1/(T1-K1-(N1+2)/2);
            adj2 = T1/(T1-K1-N1+1);
            adj3 = T1/(T1-K1+1);
            if N1==1
               df2 = T1-K1-1;               
               fcut = (exp(chi2cut)-1)*(df2/df1);
               lr(i,j,k) = 1-fcdf(fcut,df1,df2);
               waldcut = chi2cut*(df2/df1);
               wald1(i,j,k) = 1-fcdf(waldcut,df1,df2);
               lmcut = (chi2cut/(1-chi2cut))*(df2/df1);               
               lm(i,j,k) = 1-fcdf(lmcut,df1,df2);             
               fcut = (exp(chi2cut*adj1)-1)*(df2/df1);
               lra(i,j,k) = 1-fcdf(fcut,df1,df2);
               waldcut = chi2cut*adj2*(df2/df1);
               wald1a(i,j,k) = 1-fcdf(waldcut,df1,df2);
               lmcut = (chi2cut*adj3/(1-chi2cut*adj3))*(df2/df1);               
               lma(i,j,k) = 1-fcdf(lmcut,df1,df2);             
            else,
               df2 = 2*(T1-K1-N1);
               df3 = N1;
               df4 = T1-N1-K1+1;
               fcut = (exp(0.5*chi2cut)-1)*(df2/df1);
               lr(i,j,k) = 1-fcdf(fcut,df1,df2);
               wald1(i,j,k) = 1-wald(chi2cut,df3,df4);
               lm(i,j,k) = 1-pillai2(chi2cut,df3,df4);
               fcut = (exp(0.5*chi2cut*adj1)-1)*(df2/df1);
               lra(i,j,k) = 1-fcdf(fcut,df1,df2);
               wald1a(i,j,k) = 1-wald(chi2cut*adj2,df3,df4);
               lma(i,j,k) = 1-pillai2(chi2cut*adj3,df3,df4);
            end;
            fprintf(fid,' %5.0f %5.0f %5.0f  %6.3f %6.3f %6.3f  %6.3f %6.3f %6.3f\n',K1,N1,T1, ...
                    wald1(i,j,k),lr(i,j,k),lm(i,j,k),wald1a(i,j,k),lra(i,j,k),lma(i,j,k));
        end;
    end;
end;
fclose(fid);
