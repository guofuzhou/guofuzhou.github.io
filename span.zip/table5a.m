%
% Table5a.m	Date: 11/02/99
% This Matlab program compares the Wald tests with and without
% conditional heteroskedasticity adjustment when returns are
% multivariate t-distributed.
%
nobs = 100000;
df = 10;
rand('state',100*sum(clock));
randn('state',100*sum(clock));
load market.dat
r = market(:,2:3);
mu1 = mean(r)';
V11 = cov(r,1);
K = 2;
N = [1 2 5 10 25];
T = [60 120 240 360];
nN = length(N);
nT = length(T);
maxT = max(T);
maxN = max(N);
p = 0.95;
%
%	Create variance of R_t for each N
%
mu0 = zeros(maxN+K,nN);
V0 = zeros(maxN+K,maxN+K,nN);
for i=1:nN
    N1 = N(i);
    B = zeros(N1,K);
    B(:,1:K-1) = randn(N1,K-1);
    B(:,K) = ones(N1,1)-sum(B(:,1:K-1),2);
    mu0(1:N1+K,i) = [mu1; B*mu1];
    V0(1:N1+K,1:N1+K,i) = [V11 V11*B'; B*V11 eye(N1)+B*V11*B'];
end
%
%	Generate R to be multivariate-t with mean mu and variance V.
%
wald = zeros(nN,nT,nobs);
wald1 = zeros(nN,nT,nobs);
wald2 = zeros(nN,nT,nobs);
for ii=1:nobs
    for i=1:nN
        N1 = N(i);
        mu = squeeze(mu0(1:N1+K,i));       
        V = squeeze(V0(1:N1+K,1:N1+K,i));
        U = sqrt(chi2rnd(df,maxT,1)/(df-2));	% Set it to df-2 so Var[R]=V
        R = ones(maxT,1)*mu'+(randn(maxT,N1+K)*chol(V))./(U*ones(1,N1+K));
        for j=1:nT
            T1 = T(j);
            [wald(i,j,ii) wald2(i,j,ii) wald1(i,j,ii)] = gmmspan(R(1:T1,1:K),R(1:T1,K+1:N1+K));
        end
    end
end
ratio1 = mean(wald./wald1,3);
ratio2 = mean(wald./wald2,3);
%
%	Three different Wald tests
%
fid = fopen('table5a.out','W');
fprintf(fid,' Returns are Multivariate-t Distributed\n');
fprintf(fid,' Degrees of Freedom of Multivariate-t Distrbution = %3.0f\n',df);
fprintf(fid,' Number of Simulations = %6.0f\n',nobs);
fprintf(fid,' Size of the test is 5%%\n');
fprintf(fid,'                   Ratio              Hotelling               Chi-square\n');
fprintf(fid,'   N     T     W/W-a  W/W-ae    Small  Small-a Small-ae  Wald   Wald-a  Wald-ae\n');
for i=1:nN
    N1 = N(i);
    chi2cut = chi2inv(p,2*N1);
    for j=1:nT
        T1 = T(j);
        if N1==1
           waldcut = T1*finv(p,2,T1-K-1)*2/(T1-K-1);
        else
           waldcut = T1*waldinv(p,N1,T1-N1-K+1);
        end
        psmall = mean(wald(i,j,:)>waldcut);
        psmall1 = mean(wald1(i,j,:)>waldcut);
        psmall2 = mean(wald2(i,j,:)>waldcut);
        plarge = mean(wald(i,j,:)>chi2cut);
        plarge1 = mean(wald1(i,j,:)>chi2cut);
        plarge2 = mean(wald2(i,j,:)>chi2cut);
        fprintf(fid,'  %2.0f    %3.0f   %6.3f  %6.3f   %6.3f  %6.3f  %6.3f   %6.3f  %6.3f  %6.3f\n', ...
                N1,T1,ratio1(i,j),ratio2(i,j),psmall,psmall1,psmall2,plarge,plarge1,plarge2);
    end
end
fclose(fid);
