function x = waldinv(p,m,n)
OPTIONS = optimset('Display','off','TolX',1e-14);
x = fzero(@(x) wald(x,m,n)-p,chi2inv(p,n)/n,OPTIONS);
