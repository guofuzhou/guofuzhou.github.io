function y = kurt(X);
%
%	This function calculates the kurtosis parameter
%
[T,N] = size(X);
Vi = inv(chol(cov(X,1)));
X = (X-ones(T,1)*mean(X))*Vi;
y = mean(sum(X.*X,2).^2)/(N*(N+2));
