%
%	table3.m	Date: Oct 23, 1999
%	This Matlab program computes the power function of the
% step-down test of spanning.
%
randn('state',100*sum(clock));
load market.dat
r = market(:,2:3);
mu = mean(r)';
V = cov(r,1);
V1 = inv(V);
a1 = mu'*V1*mu;
b1 = ones(1,2)*V1*mu;
c1 = ones(1,2)*V1*ones(2,1);
d1 = a1*c1-b1*b1;
s1 = sqrt(d1/c1);
inter1 = b1/c1;
%
%	Test asset that improves the slope of the asymptote
%
da = 3*d1/c1;
a2 = a1+da;
b2 = b1;
c2 = c1;
o2a = da/(1+a1);
omega = da/(1+d1/c1);
o2b = omega-o2a;
[o2a o2b]
%
%	Test asset that improves the global minimum-variance portfolio
%
a3 = a1;	
b3 = b1;
c3 = 1/0.045^2;
dc = c3-c1;
o3a = 0;
omega = dc/c1+(dc*inter1*inter1)/(1+d1/c1);
o3b = omega-o3a;
[o3a o3b]
%
%	Different values of alpha2
%
p = 0.05;
alpha2 = [0 0.00001:0.00001:0.00005 0.0001:0.0001:0.001 0.01 min(roots([-1 2 -0.05])) p];
alpha2 = alpha2(length(alpha2):-1:1);
alpha1 = (p-alpha2)./(1-alpha2);
n = length(alpha2);
delete table3.out
diary table3.out
T1 = 60;
K = 2;
T = T1+K;
fprintf(' Power Function of Step-Down Tests:\n')
fprintf(' T-K = %3.0f\n',T1)
fprintf('  Alpha1   Alpha2    Case 1    Case 2\n')
nobs = 10000000;
X1 = (randn(nobs,1)+sqrt(T*o2a)).^2;
X2 = (randn(nobs,1)+sqrt(T*o2b)).^2;
for i=1:n
    p1 = alpha1(i);
    p2 = alpha2(i);
    fcut1 = finv(1-p1,1,T1-1);
    fcut2 = finv(1-p2,1,T1);
    p0 = zeros(nobs,1);
    if p1==0
       p3 = 1-dncfcdf(fcut2,1,T1,T*o2b,T*o2a);
       p4 = 1-ncfcdf(fcut2,1,T1-1,T*o3b);	% Since o3a = 0
    else
       if p2==0
          p3 = 1-ncfcdf(fcut1,1,T1,T*o2a);
          p4 = p1;
       else
          a = X1*((T1-1)/fcut1);
          p0mean = 0;
          for j=1:10
              index1 = (j-1)*(nobs/10)+1:j*(nobs/10);
              a1 = X1(index1)*((T1-1)/fcut1);
              b1 = X2(index1)*(T1/fcut2)-X1(index1);
              index = (a1<b1);
              p0mean = p0mean+sum(chi2cdf(b1(index),T1-1)-chi2cdf(a1(index),T1-1))/nobs;
          end
          p3 = 1-ncfcdf(fcut1,1,T1-1,T*o2a)+p0mean;
          p4 = 1-(1-p1)*ncfcdf(fcut2,1,T1,T*o3b);
       end
    end
    fprintf(' %8.5f  %8.5f   %8.5f  %8.5f\n',p1,p2,p3,p4)
end
diary off
