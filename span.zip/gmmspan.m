%
%   This Matlab program computes six GMM Wald tests 
%   Input:
%   R1: TxK matrix of returns on benchmark assets
%   R2: TxN matrix of returns on test assets
%   Output:
%   W: Wald test statistic under conditional
%      homoskedasticity assumption
%   We: Wald test statistic under the assumption
%       that returns are i.i.d. elliptically
%       distributed
%   Wa: Wald test statistic under the conditional
%       heteroskedasticity assumption
%   J1: Bekerart Urias spanning test (with the EIV adjustment)
%   J2: Bekerart Urias spanning test (without the EIV adjustment)
%   J3: DeSantis spanning test
%   All six tests have asymptotic chi-squared distribution
%   with 2N degrees of freedom
%
function [W,We,Wa,J1,J2,J3] = gmmspan(R1,R2)
[T,K] = size(R1);
N = size(R2,2);
mu1 = mean(R1)';
V11i = inv(cov(R1,1)); 
a1 = mu1'*V11i*mu1;
b1 = sum(V11i*mu1);
c1 = sum(sum(V11i));
G = [1+a1 b1; b1 c1];
%                        
%   Compute \hat\alpha and \hat\delta
%                        
A = [1 zeros(1,K); 0 -ones(1,K)];          
C = [zeros(1,N); -ones(1,N)];
X = [ones(T,1) R1];
B = X\R2;   
Theta = A*B-C;       
E = R2-X*B;           
Sigma = cov(E,1);
H = Theta*inv(Sigma)*Theta';
lam = eig(H*inv(G));
R = [R1 R2];
%
%   Compute the three regression based Wald test statistics
%
h = kurtf(R);		% Estimate of kurtosis parameter
G1 = h*G;
G1(1,1) = G1(1,1)+1-h;
W = T*trace(H*inv(G));
We = T*trace(H*inv(G1));
R1d = R1-ones(T,1)*mu1';
g = [(1-R1d*V11i*mu1)*ones(1,N).*E -sum(R1d*V11i,2)*ones(1,N).*E];
Sg = (g'*g)/T;
Theta1 = vec(Theta');
Wa = T*(Theta1'*inv(Sg)*Theta1);
%
%   Compute the three SDF based Wald test statistics
%
if nargout>3
   mu = mean(R)';
   Vi = inv(cov(R,1));
   QVi = Vi(K+1:end,:);
   b1 = sum(Vi,2);
   b2 = -Vi*mu;
   Rd = R-ones(T,1)*mu';
   m1 = Rd*b1;
   m2 = 1+Rd*b2;
%
%  Pick c1=0, c2=1.
%   
   h = [R*QVi'.*(m1*ones(1,N))-ones(T,1)*sum(QVi') R*QVi'.*(m2*ones(1,N))];
   bb = [b1(K+1:end); b2(K+1:end)];
   Q1 = inv((h'*h)/T);
   J2 = T*(bb'*Q1*bb);   % BU test
   QVimu = QVi*mu;
   h = h-[Rd*b1*QVimu' Rd*b2*QVimu'];
   Q1 = inv((h'*h)/T);
   J1 = T*(bb'*Q1*bb);   % BU test with EIV
   R = 1+R;   % Change R to total returns  
   Ui = inv((R'*R)/T);
   b1 = sum(Ui,2);
   b2 = -Ui*mu;
   m1 = R*b1;
   m2 = 1+R*b2;
   QUi = Ui(K+1:end,:);
   sQUi = sum(QUi');
   h = [R*QUi'.*(m1*ones(1,N))-ones(T,1)*sQUi R*QUi'.*(m2*ones(1,N))-ones(T,1)*sQUi];
   bb = [b1(K+1:end); b2(K+1:end)];
   Q1 = inv((h'*h)/T);
   J3 = T*(bb'*Q1*bb);   % DeSantis test
end
   
   
   
