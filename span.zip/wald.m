function p = wald(w,m,n)
%
%	This function finds out the P[l1+l2<w] where l1 and l2 are
%	two eigenvalues of A*inv(B) with A~W_2(m,I_2) and B~W_2(n,I_2).
%
p = zeros(size(w));
if any(w>0)
   index = w>0;
   w = w(index);
   d = w./(2+w);
   c = sqrt(pi)*exp(gammaln((m+n-1)/2)-gammaln(m/2)-gammaln(n/2));
   p(index) = betainc(d,m-1,n-1)-c*(1+w).^(-0.5*(n-1)).*betainc(d.*d,(m-1)/2,(n-1)/2);
end
