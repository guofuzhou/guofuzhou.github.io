This is a set of Matlab programs for my paper "Tests of Mean-Variance 
Spanning" (with Guofu Zhou).
If you have questions, comments, or bug reports, please send them to 
kan@chass.utoronto.ca

span.m: A Matlab program for computing the three finite sample
        tests of spanning.
stepdown.m: A Matlab program for computing the step-down test of
            spanning.
gmmspan.m: A Matlab program for computing six asymptotic Wald tests
           of spanning.  The first three are regression based tests,
           the last three are SDF based tests.

table1.m to table7.m: Matlab programs to create Tables 1 to 7 in the paper.
table2.m requires the output from Figure 4, which is generated using
figure4.m.

master.dat: return data of various international markets
Source: Global Financial Data
Col.1: Month (1970/1-2007/12, 456 monthly observations)
Col.2: US 30-year bond
Col.3: S&P500
Col.4: Austalia
Col.5: Canada
Col.6: France
Col.7: Germany
Col.8: Italy
Col.9: Japan
Col.10:U.K.

