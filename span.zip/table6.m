%
%	table6.m	Date: March 8, 2008
%	This Matlab program computes various spanning tests under normality assumption.
%
load master.dat
US = master(:,2:3);
inter = master(:,4:10);
N = size(inter,2);
delete table6.out
diary table6.out
country = ['Australia';'Canada   ';'France   ';'Germany  ';'Italy    ';'Japan    ';'U.K.     '];
for ii=1:3
    if ii==1
       fprintf(' Period : 1970/1-2007/12\n')
       R1 = US;
       R2 = inter;
    end
    if ii==2
       fprintf('\n\n Period : 1970/1-1988/12\n')
       R1 = US(1:228,:);
       R2 = inter(1:228,:);
    end
    if ii==3
       fprintf('\n\n Period : 1989/1-2007/12\n')
       R1 = US(229:456,:);
       R2 = inter(229:456,:);
    end
    fprintf(' Individual Country:\n')
    fprintf(' Country        Alpha     Delta    F-test   p-value    F-1    p-value    F-2    p-value  Joint-p\n')
    for i=1:N
        [Ftest,Ftest1,Ftest2,pval,pval1,pval2,alpha,delta] = stepdown(R1,R2(:,i));
        fprintf(' %9s    %8.5f   %7.5f   %6.3f    %5.3f   %6.3f    %5.3f   %6.3f    %5.3f    %5.3f\n', ...
             country(i,:),alpha,delta,Ftest,pval,Ftest1,pval1,Ftest2,pval2,pval1*pval2)
    end
    [Ftest,Ftest1,Ftest2,pval,pval1,pval2] = stepdown(R1,R2);
    fprintf(' All Countries:\n')
    fprintf('                                     Test   p-value    F-1    p-value    F-2    p-value  Joint-p\n')
    fprintf(' F                                 %6.3f    %5.3f   %6.3f    %5.3f   %6.3f    %5.3f    %5.3f\n',Ftest,pval,Ftest1,pval1,Ftest2,pval2,pval1*pval2)
    [W,LR,LM,pw,plr,plm] = span(R1,R2);
    fprintf(' Wald                              %6.3f    %5.3f\n',W,pw)
    fprintf(' LR                                %6.3f    %5.3f\n',LR,plr)
    fprintf(' LM                                %6.3f    %5.3f\n',LM,plm)
end
diary off
