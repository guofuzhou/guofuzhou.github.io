function x = pillainv2(p,m,n)
OPTIONS = optimset('Display','off','TolX',1e-14);
x = fzero(@(x) pillai2(x,m,n)-p,chi2inv(p,n)/n,OPTIONS);
