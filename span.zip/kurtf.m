function y = kurtf(X);
%
%	This function calculates the kurtosis parameter by using a 
%	robust bias-adjusted estimator.
%
[T,N] = size(X);
if N==1
   Vi = inv(chol(cov(X,1)));
   X = (X-ones(T,1)*mean(X))*Vi;
   X2 = sum(X.*X,2);
   y1 = mean(X2.^2)/(N*(N+2));
   y2 = 2*mean(X2.^3)/(N*(N+2))-(2*N+7)*y1*y1+3*y1-2;
   y = y1+y2/T;
else
   t1 = kurt(X);
   t2 = 0;
   t3 = 0;
   for i=1:N
       t2 = t2+kurt(X(:,i));
       X1 = X;
       X1(:,i) = [];
       t3 = t3+kurt(X1);
   end
   t2 = t2/N;
   t3 = t3/N;
   y = ((N+4)*(t2+t3)-(N+8)*t1)/N;
   y = y+(y^2+3*y-2)/T;
end
