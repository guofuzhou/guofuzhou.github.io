%% TSM with time-series and cross-asset information (Figure 3) %%

%% 1-month Cumulative %%
clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ret = Return(Return(:,1)>=198501,:);
Ns = 1; Ne = 55;
rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T=length(R);
R1x = Ret(:,2);
R3x = R(1:T-2).*R(2:T-1).*R(3:T) - rf(1:T-2).*rf(2:T-1).*rf(3:T); 
R3x = [nan(2,1); R3x]/3;
R6x = R(1:T-5).*R(2:T-4).*R(3:T-3).*R(4:T-2).*R(5:T-1).*R(6:T) -...
      rf(1:T-5).*rf(2:T-4).*rf(3:T-3).*rf(4:T-2).*rf(5:T-1).*rf(6:T);
R6x = [nan(5,1); R6x]/6; 
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf12 = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf12]/12;

Rx = R1x;
Ret = [Ret, Rx];
% Define time as the longest period: 1985 - 2015 %
tdate = Ret(Ret(:,6)==3,1);
stdate = 199912;

%% Commodity futures %%
Ret_x = Ret; 
Ret_Com = Ret(Ret(:,6)<=24,:);

norm1 = 0; cons1 = 1; ma1 = 12; 
norm2 = 0; cons2 = 1; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Com, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Com, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Com = [INS, OS];

%% Equity index futures %%
Ret_x = Ret;
Ret_Eqt = Ret(Ret(:,6)>=25 & Ret(:,6)<=33,:);

norm1 = 0; cons1 = 1; ma1 = 12; 
norm2 = 0; cons2 = 1; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Eqt, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Eqt, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Eqt = [INS, OS];

%% Bond futures %%
Ret_x = Ret;
Ret_Bnd = Ret(Ret(:,6)>=34 & Ret(:,6)<=46,:);
 
norm1 = 0; cons1 = 1; ma1 = 12; 
norm2 = 0; cons2 = 1; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Bnd, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Bnd, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Bnd = [INS, OS];

%% Currency forwards %%
Ret_x = Ret;
Ret_Cur = Ret(Ret(:,6)>=47 & Ret(:,6)<=55,:);

norm1 = 'z'; cons1 = 0; ma1 = 12; 
norm2 = 'z'; cons2 = 0; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Cur, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Cur, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Cur = [INS, OS];

R2_ins_oos = [PLS_Com; PLS_Eqt; PLS_Bnd; PLS_Cur];

save('E:\RESEARCH\TSMOM\Codes_new\Fig3_R2PLS1.mat','R2_ins_oos')

%% 3-month Cumulative %%
clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ret = Return(Return(:,1)>=198501,:);
Ns = 1; Ne = 55;
rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T=length(R);
R1x = Ret(:,2);
R3x = R(1:T-2).*R(2:T-1).*R(3:T) - rf(1:T-2).*rf(2:T-1).*rf(3:T); 
R3x = [nan(2,1); R3x]/3;
R6x = R(1:T-5).*R(2:T-4).*R(3:T-3).*R(4:T-2).*R(5:T-1).*R(6:T) -...
      rf(1:T-5).*rf(2:T-4).*rf(3:T-3).*rf(4:T-2).*rf(5:T-1).*rf(6:T);
R6x = [nan(5,1); R6x]/6; 
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf12 = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf12]/12;

Rx = R3x;
Ret = [Ret, Rx];

for n = Ns:Ne
    aa = find(Ret(:,6)==n);
    Ret(aa(1):aa(2),:) = [];
end

% Define time as the longest period: 1985 - 2015 %
tdate = Ret(Ret(:,6)==3,1);
stdate = 199912;

%% Commodity futures %%
Ret_x = Ret; 
Ret_Com = Ret(Ret(:,6)<=24,:);

norm1 = 0; cons1 = 1; ma1 = 12; 
norm2 = 0; cons2 = 1; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Com, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Com, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Com = [INS, OS];

%% Equity index futures %%
Ret_x = Ret;
Ret_Eqt = Ret(Ret(:,6)>=25 & Ret(:,6)<=33,:);

norm1 = 0; cons1 = 1; ma1 = 12; 
norm2 = 0; cons2 = 1; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Eqt, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Eqt, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Eqt = [INS, OS];

%% Bond futures %%
Ret_x = Ret;
Ret_Bnd = Ret(Ret(:,6)>=34 & Ret(:,6)<=46,:);
 
norm1 = 'z'; cons1 = 0; ma1 = 12; 
norm2 = 'z'; cons2 = 0; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Bnd, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Bnd, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Bnd = [INS, OS];

%% Currency forwards %%
Ret_x = Ret;
Ret_Cur = Ret(Ret(:,6)>=47 & Ret(:,6)<=55,:);

norm1 = 'z'; cons1 = 0; ma1 = 12; 
norm2 = 'z'; cons2 = 0; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Cur, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Cur, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Cur = [INS, OS];

R2_ins_oos = [PLS_Com; PLS_Eqt; PLS_Bnd; PLS_Cur];

save('E:\RESEARCH\TSMOM\Codes_new\Fig3_R2PLS3.mat','R2_ins_oos')

%% 6-month Cumulative %%
clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ret = Return(Return(:,1)>=198501,:);
Ns = 1; Ne = 55;
rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T=length(R);
R1x = Ret(:,2);
R3x = R(1:T-2).*R(2:T-1).*R(3:T) - rf(1:T-2).*rf(2:T-1).*rf(3:T); 
R3x = [nan(2,1); R3x]/3;
R6x = R(1:T-5).*R(2:T-4).*R(3:T-3).*R(4:T-2).*R(5:T-1).*R(6:T) -...
      rf(1:T-5).*rf(2:T-4).*rf(3:T-3).*rf(4:T-2).*rf(5:T-1).*rf(6:T);
R6x = [nan(5,1); R6x]/6; 
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf12 = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf12]/12;

Rx = R6x;
Ret = [Ret, Rx];

for n = Ns:Ne
    aa = find(Ret(:,6)==n);
    Ret(aa(1):aa(5),:) = [];
end

% Define time as the longest period: 1985 - 2015 %
tdate = Ret(Ret(:,6)==3,1);
stdate = 199912;

%% Commodity futures %%
Ret_x = Ret; 
Ret_Com = Ret(Ret(:,6)<=24,:);

norm1 = 0; cons1 = 1; ma1 = 12; 
norm2 = 0; cons2 = 1; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Com, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Com, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Com = [INS, OS];

%% Equity index futures %%
Ret_x = Ret;
Ret_Eqt = Ret(Ret(:,6)>=25 & Ret(:,6)<=33,:);

norm1 = 0; cons1 = 1; ma1 = 12; 
norm2 = 0; cons2 = 1; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Eqt, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Eqt, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Eqt = [INS, OS];

%% Bond futures %%
Ret_x = Ret;
Ret_Bnd = Ret(Ret(:,6)>=34 & Ret(:,6)<=46,:);
 
norm1 = 0; cons1 = 1; ma1 = 12; 
norm2 = 0; cons2 = 1; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Bnd, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Bnd, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Bnd = [INS, OS];

%% Currency forwards %%
Ret_x = Ret;
Ret_Cur = Ret(Ret(:,6)>=47 & Ret(:,6)<=55,:);

norm1 = 0; cons1 = 1; ma1 = 0; 
norm2 = 0; cons2 = 1; ma2 = 0; constraint = 0;
[INS] = Func_PLS_INS(Ret_Cur, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Cur, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Cur = [INS, OS];

R2_ins_oos = [PLS_Com; PLS_Eqt; PLS_Bnd; PLS_Cur];

save('E:\RESEARCH\TSMOM\Codes_new\Fig3_R2PLS6.mat','R2_ins_oos')

%% 12-month Cumulative %%
clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ret = Return(Return(:,1)>=198501,:);
Ns = 1; Ne = 55;
rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T=length(R);
R1x = Ret(:,2);
R3x = R(1:T-2).*R(2:T-1).*R(3:T) - rf(1:T-2).*rf(2:T-1).*rf(3:T); 
R3x = [nan(2,1); R3x]/3;
R6x = R(1:T-5).*R(2:T-4).*R(3:T-3).*R(4:T-2).*R(5:T-1).*R(6:T) -...
      rf(1:T-5).*rf(2:T-4).*rf(3:T-3).*rf(4:T-2).*rf(5:T-1).*rf(6:T);
R6x = [nan(5,1); R6x]/6; 
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf12 = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf12]/12;

Rx = R12x;
Ret = [Ret, Rx];

for n = Ns:Ne
    aa = find(Ret(:,6)==n);
    Ret(aa(1):aa(11),:) = [];
end

% Define the time as the longest period: 1985 - 2015 %
tdate = Ret(Ret(:,6)==3,1);
stdate = 199912;

%% Commodity futures %%
Ret_x = Ret; 
Ret_Com = Ret(Ret(:,6)<=24,:);

norm1 = 0; cons1 = 1; ma1 = 12; 
norm2 = 0; cons2 = 1; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Com, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Com, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Com = [INS, OS];

%% Equity index futures %%
Ret_x = Ret;
Ret_Eqt = Ret(Ret(:,6)>=25 & Ret(:,6)<=33,:);

norm1 = 0; cons1 = 1; ma1 = 0; 
norm2 = 0; cons2 = 1; ma2 = 0; constraint = 0;
[INS] = Func_PLS_INS(Ret_Eqt, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Eqt, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Eqt = [INS, OS];

%% Bond futures %%
Ret_x = Ret;
Ret_Bnd = Ret(Ret(:,6)>=34 & Ret(:,6)<=46,:);
 
norm1 = 0; cons1 = 1; ma1 = 0; 
norm2 = 0; cons2 = 1; ma2 = 0; constraint = 0;
[INS] = Func_PLS_INS(Ret_Bnd, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Bnd, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Bnd = [INS, OS];

%% Currency forwards %%
Ret_x = Ret;
Ret_Cur = Ret(Ret(:,6)>=47 & Ret(:,6)<=55,:);

norm1 = 0; cons1 = 1; ma1 = 12; 
norm2 = 0; cons2 = 1; ma2 = 12; constraint = 0;
[INS] = Func_PLS_INS(Ret_Cur, Ret_x, tdate, norm1, cons1, ma1);
[OS] = Func_PLS_OOS(Ret_Cur, Ret_x, tdate, stdate, norm2, cons2, ma2, constraint);
PLS_Cur = [INS, OS];

R2_ins_oos = [PLS_Com; PLS_Eqt; PLS_Bnd; PLS_Cur];

save('E:\RESEARCH\TSMOM\Codes_new\Fig3_R2PLS12.mat','R2_ins_oos')

