%% Different lag-based TSM with time-series regression (Figure 2) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

% Return = [1.year_month, 2.excess return, 3.volatility, 4.risk free, 5.NBER, 6.ID]
%% 1-month cumulative %%
Ns = 1; Ne = 55; lag = 2;
Ret = Return(Return(:,1)>=198501,:);
rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T = length(R);
R1x = Ret(:,2);
R3x = R(1:T-2).*R(2:T-1).*R(3:T) - rf(1:T-2).*rf(2:T-1).*rf(3:T); 
R3x = [nan(2,1); R3x]/3;
R6x = R(1:T-5).*R(2:T-4).*R(3:T-3).*R(4:T-2).*R(5:T-1).*R(6:T) -...
      rf(1:T-5).*rf(2:T-4).*rf(3:T-3).*rf(4:T-2).*rf(5:T-1).*rf(6:T);
R6x = [nan(5,1); R6x]/6;  
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf]/12;
Rx =R1x; Ret = [Ret, Rx];

res_ins = []; res_oos = [];
for s = Ns:Ne
    X_cum = Ret(Ret(:,6)==s,7);
    Y = Ret(Ret(:,6)==s,2)*100;
    tX = Ret(Ret(:,6)==s,1);
    rhv = [ones(size(Y)), zscore(X_cum)];
    
    % In-sample %
   [bv,sebv,R2v,R2vadj,v,F]=olsgmm(Y(2:end),rhv(1:end-1,:),lag,1);
   res_ins = [res_ins; [bv(2:end)', bv(2:end)'./sebv(2:end)', R2v*100]];
   
   % Out-of-sample %
   % Starting time 200001 %
   yhat = nan*Y; ybar = nan*Y;
   bb = find(tX(:)==199912);
   rhv = [ones(size(Y)), X_cum];
   for t = bb+1:length(Y)
        R = Y(2:t-1);
        E = rhv(1:t-2,:);
        b = regress(R,E);
        yhat(t) = rhv(t-1,:)*b;
        ybar(t) = mean(Y(1:t-1));
   end
yos = Y(bb+1:end); ybar = ybar(bb+1:end); yhat = yhat(bb+1:end); 
OS = R2oostest(yos,ybar,yhat,lag);
res_oos = [res_oos; OS(1:2)];
end

fprintf('\n\n1-month In-sample \n\n')
mean(res_ins(:,3))         
length(find(res_ins(:,2)>=1.64 | res_ins(:,2)<=-1.64))

fprintf('\n\n1-month Out-of-sample \n\n')
mean(res_oos(:,1)) 
length(find(res_oos(:,2)<=0.1))

save('E:\RESEARCH\TSMOM\Codes_new\Fig2_R2TSM1.mat','res_ins', 'res_oos')

%% 3-month cumulative %%
Ns = 1; Ne = 55; lag = 4;
Ret = Return(Return(:,1)>=198501,:);
rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T = length(R);
R1x = Ret(:,2);
R3x = R(1:T-2).*R(2:T-1).*R(3:T) - rf(1:T-2).*rf(2:T-1).*rf(3:T); 
R3x = [nan(2,1); R3x]/3;
R6x = R(1:T-5).*R(2:T-4).*R(3:T-3).*R(4:T-2).*R(5:T-1).*R(6:T) -...
      rf(1:T-5).*rf(2:T-4).*rf(3:T-3).*rf(4:T-2).*rf(5:T-1).*rf(6:T);
R6x = [nan(5,1); R6x]/6;  
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf]/12;
Rx =R3x; Ret = [Ret, Rx];

% Drop the first 2 observations for each asset %
for s = Ns:Ne
    aa = find(Ret(:,6)==s);
    Ret(aa(1):aa(2),:) = [];
end

res_ins = []; res_oos = [];
for s = Ns:Ne
    X_cum = Ret(Ret(:,6)==s,7);
    Y = Ret(Ret(:,6)==s,2)*100;
    tX = Ret(Ret(:,6)==s,1);
    rhv = [ones(size(Y)), zscore(X_cum)];
    
    % In-sample %
   [bv,sebv,R2v,R2vadj,v,F]=olsgmm(Y(2:end),rhv(1:end-1,:),lag,1);
   res_ins = [res_ins; [bv(2:end)', bv(2:end)'./sebv(2:end)', R2v*100]];
   
   % Out-of-sample %
   % Starting time 200001 %
   yhat = nan*Y; ybar = nan*Y;
   bb = find(tX(:)==199912);
   rhv = [ones(size(Y)), X_cum];
   for t = bb+1:length(Y)
        R = Y(2:t-1);
        E = rhv(1:t-2,:);
        b = regress(R,E);
        yhat(t) = rhv(t-1,:)*b;
        ybar(t) = mean(Y(1:t-1));
   end
yos = Y(bb+1:end); ybar = ybar(bb+1:end); yhat = yhat(bb+1:end); 
OS = R2oostest(yos,ybar,yhat,lag);
res_oos = [res_oos; OS(1:2)];
end

fprintf('\n\n3-month In-sample \n\n')
mean(res_ins(:,3))         
length(find(res_ins(:,2)>=1.64 | res_ins(:,2)<=-1.64))

fprintf('\n\n3-month Out-of-sample \n\n')
mean(res_oos(:,1)) 
length(find(res_oos(:,2)<=0.1))

save('E:\RESEARCH\TSMOM\Codes_new\Fig2_R2TSM3.mat','res_ins', 'res_oos')

%% 6-month cumulative %%
Ns = 1; Ne = 55; lag = 2;
Ret = Return(Return(:,1)>=198501,:);
rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T = length(R);
R1x = Ret(:,2);
R3x = R(1:T-2).*R(2:T-1).*R(3:T) - rf(1:T-2).*rf(2:T-1).*rf(3:T); 
R3x = [nan(2,1); R3x]/3;
R6x = R(1:T-5).*R(2:T-4).*R(3:T-3).*R(4:T-2).*R(5:T-1).*R(6:T) -...
      rf(1:T-5).*rf(2:T-4).*rf(3:T-3).*rf(4:T-2).*rf(5:T-1).*rf(6:T);
R6x = [nan(5,1); R6x]/6;  
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf]/12;
Rx =R6x; Ret = [Ret, Rx];

% Drop the first 5 observations for each asset %
for s = Ns:Ne
    aa = find(Ret(:,6)==s);
    Ret(aa(1):aa(5),:) = [];
end

res_ins = []; res_oos = [];
for s = Ns:Ne
    X_cum = Ret(Ret(:,6)==s,7);
    Y = Ret(Ret(:,6)==s,2)*100;
    tX = Ret(Ret(:,6)==s,1);
    rhv = [ones(size(Y)), zscore(X_cum)];
    
    % In-sample %
   [bv,sebv,R2v,R2vadj,v,F]=olsgmm(Y(2:end),rhv(1:end-1,:),lag,1);
   res_ins = [res_ins; [bv(2:end)', bv(2:end)'./sebv(2:end)', R2v*100]];
   
   % Out-of-sample %
   % Starting time 200001 %
   yhat = nan*Y; ybar = nan*Y;
   bb = find(tX(:)==199912);
   rhv = [ones(size(Y)), X_cum];
   for t = bb+1:length(Y)
        R = Y(2:t-1);
        E = rhv(1:t-2,:);
        b = regress(R,E);
        yhat(t) = rhv(t-1,:)*b;
        ybar(t) = mean(Y(1:t-1));
   end
yos = Y(bb+1:end); ybar = ybar(bb+1:end); yhat = yhat(bb+1:end); 
OS = R2oostest(yos,ybar,yhat,lag);
res_oos = [res_oos; OS(1:2)];
end

fprintf('\n\n6-month In-sample \n\n')
mean(res_ins(:,3))         
length(find(res_ins(:,2)>=1.64 | res_ins(:,2)<=-1.64))

fprintf('\n\n6-month Out-of-sample \n\n')
mean(res_oos(:,1)) 
length(find(res_oos(:,2)<=0.1))

save('E:\RESEARCH\TSMOM\Codes_new\Fig2_R2TSM6.mat','res_ins', 'res_oos')