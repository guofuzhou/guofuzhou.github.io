%% TSM with time-series regression (Figure 1) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

% Return = [1.year_month, 2.excess return, 3.volatility, 4.risk free, 5.NBER, 6.ID]
Ns = 1; Ne = 55;
Ret = Return(Return(:,1)>=198501,:);
rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T = length(R);
R1x = Ret(:,2);
R3x = R(1:T-2).*R(2:T-1).*R(3:T) - rf(1:T-2).*rf(2:T-1).*rf(3:T); 
R3x = [nan(2,1); R3x]/3;
R6x = R(1:T-5).*R(2:T-4).*R(3:T-3).*R(4:T-2).*R(5:T-1).*R(6:T) -...
      rf(1:T-5).*rf(2:T-4).*rf(3:T-3).*rf(4:T-2).*rf(5:T-1).*rf(6:T);
R6x = [nan(5,1); R6x]/6;  
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf]/12;
Rx =R12x; Ret = [Ret, Rx];

% Drop the first 11 observations for each asset %
for s = Ns:Ne
    aa = find(Ret(:,6)==s);
    Ret(aa(1):aa(11),:) = [];
end

res_ins = []; res_oos = [];
for s = Ns:Ne
    X_cum = Ret(Ret(:,6)==s,7);
    Y = Ret(Ret(:,6)==s,2)*100;
    tX = Ret(Ret(:,6)==s,1);
    rhv = [ones(size(Y)), zscore(X_cum)];
    
    % In-sample %
   [bv,sebv,R2v,R2vadj,v,F]=olsgmm(Y(2:end),rhv(1:end-1,:),12,1);
   res_ins = [res_ins; bv(2:end)', bv(2:end)'./sebv(2:end)', R2v*100];
   
   % Out-of-sample %
   % Starting time 200001 %
   yhat = nan*Y; ybar = nan*Y;
   bb = find(tX(:)==199912);
   rhv = [ones(size(Y)), X_cum];
   for t = bb+1:length(Y)
        R = Y(2:t-1);
        E = rhv(1:t-2,:);
        b = regress(R,E);
        yhat(t) = rhv(t-1,:)*b;
        ybar(t) = mean(Y(1:t-1));
   end
yos = Y(bb+1:end); ybar = ybar(bb+1:end); yhat = yhat(bb+1:end); 
%yhat = max(0,yhat);
OS = R2oostest(yos,ybar,yhat,4);
res_oos = [res_oos; OS(1:2)];
end

fprintf('\n\n In-sample \n\n')
mean(res_ins(:,3))         
fprintf('\n\n Out-of-sample \n\n')
mean(res_oos(:,1)) 

%% Plot figure 1 %%
Commodity_ins = res_ins(1:24,3);
Commodity_index = 1;
Commodity_ins = [Commodity_ins, repmat(Commodity_index,length(Commodity_ins),1)];
Commodity_oos = res_oos(1:24,1);
Commodity_oos = [Commodity_oos, repmat(Commodity_index,length(Commodity_oos),1)];

Equity_ins = res_ins(25:33,3);
Equity_index = 2;
Equity_ins = [Equity_ins, repmat(Equity_index,length(Equity_ins),1)];
Equity_oos = res_oos(25:33,1);
Equity_oos = [Equity_oos, repmat(Equity_index,length(Equity_oos),1)];

Bond_ins = res_ins(34:46,3);
Bond_index = 3;
Bond_ins = [Bond_ins, repmat(Bond_index,length(Bond_ins),1)];
Bond_oos = res_oos(34:46,1);
Bond_oos = [Bond_oos, repmat(Bond_index,length(Bond_oos),1)];

Currency_ins = res_ins(47:55,3);
Currency_index = 4;
Currency_ins = [Currency_ins, repmat(Currency_index,length(Currency_ins),1)];
Currency_oos = res_oos(47:55,1);
Currency_oos = [Currency_oos, repmat(Currency_index,length(Currency_oos),1)];

data_ins = [Commodity_ins; Equity_ins; Bond_ins; Currency_ins];
data_oos = [Commodity_oos; Equity_oos; Bond_oos; Currency_oos];

H_ins = data_ins(:,1);
H_oos = data_oos(:,1);
N_ins = numel(H_ins);
N_oos = numel(H_oos);

figure (1);
subplot(2,1,1);
R2l = -1; R2h = 6;
for i = 1:N_ins
    h_ins = bar(i,H_ins(i));
    if i <= N_ins 
       hold on 
    end
    if data_ins(i,2) == 1
       col_ins = rgb('DarkSlateGray');
    elseif data_ins(i,2) == 2
       col_ins = rgb('Maroon');
    elseif data_ins(i,2) == 3
       col_ins = rgb('DarkBlue');
    else
       col_ins = rgb('SaddleBrown');
    end 
    set(h_ins,'FaceColor',col_ins)
end

axis([0 Ne+1 R2l R2h]);
h=ylabel('$R^2$','FontSize', 8)
h1=text('Position',[5 5],'string','average $R^2 =0.39\%$','FontSize', 8)
h2=text('Position',[5 4.3],'string','\#(10\% significance) = 8','FontSize', 8)
h0 = title('Panel A: In-sample predictability with lagged returns','fontweight','normal','FontSize', 8)
h3 = xlabel('Asset','fontweight','normal','FontSize', 8)
set([h h1 h0 h2 h3],'Interpreter','latex');
set(gca,'ygrid','on') 
set(gca,'XTick',[1 10 20 30 40 50])

subplot(2,1,2);
R2l = -1; R2h = 3;
for i = 1:N_oos
    h_oos = bar(i,H_oos(i));
    if i <= N_oos 
       hold on 
    end
    if data_oos(i,2) == 1
       col_oos = rgb('DarkSlateGray');
    elseif data_oos(i,2) == 2
       col_oos = rgb('Maroon');
    elseif data_oos(i,2) == 3
       col_oos = rgb('DarkBlue');
    else
       col_oos = rgb('SaddleBrown');
    end 
    set(h_oos,'FaceColor',col_oos)
end

axis([0 Ne+1 R2l R2h]);
h=ylabel('$R^2_{OS}$','FontSize', 8)
h1=text('Position',[5 2.5],'string','average $R^2_{OS} = -0.67\%$','FontSize', 8)
h2=text('Position',[5 2.1],'string','\#(significant $R^2_{OS}) = 3$','FontSize', 8)
h0 = title('Panel B: Out-of-sample predictability with lagged returns','fontweight','normal','FontSize', 8)
h3 = xlabel('Asset','fontweight','normal','FontSize', 8)
set([h h1 h0 h2 h3],'Interpreter','latex');
set(gca,'ygrid','on') 
set(gca,'XTick',[1 10 20 30 40 50])

save2pdf('E:\RESEARCH\TSMOM\Codes_new\Fig1_R2TSM12',gcf,600)