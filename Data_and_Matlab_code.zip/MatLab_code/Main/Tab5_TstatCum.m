%% Pooled regression without volatility scaling using cumulative returns (t-stat for Tab 5, Panel B) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ns = 1; Ne = 55; 
Return = Return(Return(:,6)>=Ns & Return(:,6)<=Ne,:);

Rs = Return(:,2);
rf = Return(:,4)+1;
Rcum = Func_GenCum(rf, Rs);
z = [Rcum, Return(:,1), Return(:,6)];
  
res = []; res_sign = [];
for h = 1:12
    yy = [];
   for n = Ns:Ne
      tt = find(z(:,14) == n);                                                                       %    1 -12       13       14   
      a = z(tt,:);                                                                                             %    xcum        ym      ID
      yy = [yy; a(1+h:end,1), a(h:end-1,h), a(1+h:end,[13, 14])];     %    yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res = [res; b(1, [1, 3]), b(2, [1, 3])];
  
    b = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign = [res_sign; b(1, [1, 3]), b(2, [1, 3])];
end
save('E:\RESEARCH\TSMOM\Codes_new\Tab5_TstatCum_All.mat','res','res_sign')

