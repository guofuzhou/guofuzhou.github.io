%% TSM with pooled regression (Figure 5) %%
%% R2 with volatility scaling %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ns = 1; Ne = 55;
Ret = Return(Return(:,1)>=198501,:);
beta = []; R2 = []; 

rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T=length(R);
R3x = R(1:T-2).*R(2:T-1).*R(3:T) - rf(1:T-2).*rf(2:T-1).*rf(3:T); 
R3x = [nan(2,1); R3x]/3;
R6x = R(1:T-5).*R(2:T-4).*R(3:T-3).*R(4:T-2).*R(5:T-1).*R(6:T) -...
      rf(1:T-5).*rf(2:T-4).*rf(3:T-3).*rf(4:T-2).*rf(5:T-1).*rf(6:T);
R6x = [nan(5,1); R6x]/6; 
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf12 = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf12]/12;

Rx = R12x;
Ret = [Ret, Rx];

% Generate xr/vol %
z = [nan(1,2); Ret(2:end,[2, 7])./Ret(1:end-1,3)];
z = [Ret, z];
for s = Ns:Ne
    aa = find(z(:,6)==s);
    z(aa(1):aa(12),:) = [];
    bb = find(Ret(:,6)==s);
    Ret(bb(1):bb(12),:) = [];
end
z = z(:, [1, 2, 6, 3, 8, 9]);                                % [ym, xr, id, vol, xr/vol, xcum/vol]

% Match date with continuous numbers in order for recursive regression %
align = xlsread('E:\RESEARCH\TSMOM\Codes_new\Alignment.xlsx');
for i = 1:size(align,1)
     equal_lines = find(z(:,1)==align(i,1));
     z(equal_lines,7) = align(i,2);                   % Align dates with their identical number
end

% Pooled OLS for in-sample %
res = [];
for h = 1
    yy = [];
    for n = Ns:Ne 
        tt = find(z(:,3) == n);
        a = z(tt,:);                                                 % [ym, xr, id, vol, xr/vol, xcum/vol]
        yy = [yy; a(h+1:end,5), a(1:end-h,6), a(h+1:end,[1, 3])];    % yy = [xr/vol, xcum/vol,  ym, ID];
    end
  b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3)); % cluster by time
  res = [res; b(1, [1, 3]), b(2, [1, 3])];
end
beta = [res(1,1), res(1,3)];

% In-sample %
R2 = []; 
for s = Ns:Ne
   Y = Ret(Ret(:,6)==s,2);
   X_cum = Ret(Ret(:,6)==s,7);
   Exvol = Ret(Ret(:,6)==s,3);
   Xcum_vol = X_cum(2:end)./Exvol(1:end-1);
   yhat = [Xcum_vol(1:end-1), ones(length(Xcum_vol(1:end-1)),1)]*beta'.*Exvol(2:end-1);
   R2_s = var(yhat(:))/var(Y(3:end));
   R2 = [R2; R2_s*100];
end

clearvars -except z Ret Ns Ne align R2;
res = [];
% Out-of-sample %
bb = find(align(:,1)==199912);
cc = find(align(:,1)==201512);
beta = nan(cc,2);
for t = bb+1:cc
   st = find(z(:,7)<=t-1);                                  % Find the initial period which is before 199912 for all assets
   zz = z(st,:);
   for h = 1
      yy = [];
      for n = Ns:Ne 
         tt = find(zz(:,3) == n);
         a = zz(tt,:);                                               % [ym, xr, id, vol, xr/vol, xcum/vol, continuous time]      
         yy = [yy; a(h+1:end,5), a(1:end-h,6), a(h+1:end,[1, 3])];  % yy = [y, x,  ym, ID]; 
      end
         b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3)); % cluster by time
         res = [res; b(1, [1, 3]), b(2, [1, 3])];
    end
    beta(t-1,:) = [res(t-bb,1), res(t-bb,3)];
    t
end

R2oosvol = [];
for s = Ns:Ne
    yhat = nan(cc,1);
    ybar = nan(cc,1);
    X = z(z(:,3)==s,[6, 7]);                                % X = [xcum/vol,  contime]
    Y = z(z(:,3)==s,[2, 7]);                                % Y = [xr, contime]
    Exvol = z(z(:,3)==s,[4, 7]);                         % vol = [vol, contime]
    for t = bb+1:cc                                            % bb = 199912  cc = 201512
      xt = find(X(:,2)==t);
      yt = find(Y(:,2)==t);
      volt = find(Exvol(:,2)==t);
      rhv = [X(xt-1,1), 1]; 
      sigma = Exvol(volt-1,1);
      yhat(t) = rhv*beta(t-1,:)'*sigma;
      ybar(t)= mean(Y(1:yt-1,1));  
    end
    %yhat = max(0,yhat);
    yt_oos = find(Y(:,2)==bb);
    yos = Y(yt_oos+1:end,1); 
    ybar = ybar(bb+1:end); 
    yhat = yhat(bb+1:end);
    OS = R2oostest(yos,ybar,yhat,12);
    R2oosvol = [R2oosvol; OS(1:2)];   
    s
end
fprintf('\n\n R2 with vol scaling \n\n')
mean(R2oosvol(:,2))

save('E:\RESEARCH\TSMOM\Codes_new\Fig5_PoolR2vol.mat','R2oosvol')

%% R2 without volatility scaling %%
clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ns = 1; Ne = 55;
Ret = Return(Return(:,1)>=198501,:);
beta = []; R2 = []; 

rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T=length(R);
R3x = R(1:T-2).*R(2:T-1).*R(3:T) - rf(1:T-2).*rf(2:T-1).*rf(3:T); 
R3x = [nan(2,1); R3x]/3;
R6x = R(1:T-5).*R(2:T-4).*R(3:T-3).*R(4:T-2).*R(5:T-1).*R(6:T) -...
      rf(1:T-5).*rf(2:T-4).*rf(3:T-3).*rf(4:T-2).*rf(5:T-1).*rf(6:T);
R6x = [nan(5,1); R6x]/6; 
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf12 = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf12]/12;

Rx = R12x;
Ret = [Ret, Rx];
for s = Ns:Ne
    aa = find(Ret(:,6)==s);
    Ret(aa(1):aa(11),:) = [];
end
z = Ret(:, [1, 5, 6, 2, 7]);                                % [ym nber id xr xcum]
z = [z, NaN(size(z,1),1)];

% Match date with continuous numbers in order for recursive regression %
align = xlsread('E:\RESEARCH\TSMOM\Codes_new\Alignment.xlsx');

for i = 1:size(align,1)
     equal_lines = find(z(:,1)==align(i,1));
     z(equal_lines,6) = align(i,2);                   % Align dates with their identical number
end
res = [];
for h = 1
    yy = [];
    for n = Ns:Ne 
        tt = find(z(:,3) == n);
        a = z(tt,:);                                                 % ym nber id xr xcum  
        yy = [yy; a(h+1:end,4), a(1:end-h,5), a(h+1:end,[1, 3])];    % yy = [xr, xcum,  ym, ID];
    end
  b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));    % cluster by time
  res = [res; b(1, [1, 3]), b(2, [1, 3])];
end
beta = [res(1,1), res(1,3)];

% In-sample %
R2 = []; 
for s = Ns:Ne
   Y = Ret(Ret(:,6)==s,2);
   X_cum = Ret(Ret(:,6)==s,7);
   yhat = [X_cum(1:end-1), ones(length(X_cum(1:end-1)),1)]*beta';
   R2_s = var(yhat(:))/var(Y(2:end));
   R2 = [R2; R2_s*100];
end

clearvars -except z Ret Ns Ne align R2;
res = [];
% Out-of-sample %
bb = find(align(:,1)==199912);
cc = find(align(:,1)==201512);
beta = nan(cc,2);
for t = bb+1:cc
   st = find(z(:,6)<=t-1);                                  % Find the initial period which is before 199912 for all assets
   zz = z(st,:);
   for h = 1
      yy = [];
      for n = Ns:Ne 
         tt = find(zz(:,3) == n);
         a = zz(tt,:);                                              % [ym, nber, id, xr, xcum, continuous time]      
         yy = [yy; a(h+1:end,4), a(1:end-h,5), a(h+1:end,[1, 3])];  % yy = [y, x,  ym, ID]; 
      end
         b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));  % cluster by time
         res = [res; b(1, [1, 3]), b(2, [1, 3])];
   end
   beta(t-1,:) = [res(t-bb,1), res(t-bb,3)];
   t
end

R2oos = [];
for s = Ns:Ne
    yhat = nan(cc,1);
    ybar = nan(cc,1);
    X = z(z(:,3)==s,[5, 6]);                                % X = [xcum  contime]
    Y = z(z(:,3)==s,[4, 6]);                                % Y = [xr contime]
    for t = bb+1:cc                                            % bb = 199912  cc = 201512
      xt = find(X(:,2)==t);
      yt = find(Y(:,2)==t);
      rhv = [X(xt-1,1), 1]; 
      yhat(t) = rhv*beta(t-1,:)';
      ybar(t)= mean(Y(1:yt-1,1));  
    end
    %yhat = max(0,yhat);
    yt_oos = find(Y(:,2)==bb);
    yos = Y(yt_oos+1:end,1); 
    ybar = ybar(bb+1:end); 
    yhat = yhat(bb+1:end);
    OS = R2oostest(yos,ybar,yhat,12);
    R2oos = [R2oos; OS(1:2)];   
    s
end
fprintf('\n\n R2 with vol scaling \n\n')
mean(R2oos(:,1))

save('E:\RESEARCH\TSMOM\Codes_new\Fig5_PoolR2.mat','R2oos')