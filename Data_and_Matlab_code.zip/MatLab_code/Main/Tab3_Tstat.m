%% TSM with pooled regression (t-stat for Tab 3, Panel A) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

%% All asset classes %%
Ns = 1; Ne = 55;
Return = Return(Return(:,6)>=Ns & Return(:,6)<=Ne,:);
Return = Return(Return(:,1)>=198501,:);

% Generate xr/vol %
z = [nan; Return(2:end,2)./Return(1:end-1,3)];
z = [Return, z];
for s = Ns:Ne
    line1 = find(z(:,6)==s);
    z(line1(1):line1(12),:) = []; 
end
z = z(:, [1, 5, 6, 7]);                                         % [ym, NBER, ID, xr/vol]

res = []; res_sign = [];
for h = 1:12
    yy = [];
    for n = Ns:Ne 
        tt = find(z(:,3) == n);
        a = z(tt,:); 
        yy = [yy; a(h+1:end,4), a(1:end-h,4), a(h+1:end,[1, 3])];   % yy = [y, x,  ym, ID]; 
    end
  b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
  res = [res; b(1, [1, 3]), b(2, [1, 3])];
  
  b = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
  res_sign = [res_sign; b(1, [1, 3]), b(2, [1, 3])];
  
end
save('E:\RESEARCH\TSMOM\Codes_new\Tab3_TstatAll.mat','res','res_sign')

