%% Mean predictability test (Table 7) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ns = 1; Ne = 55;
Ret = Return(Return(:,1)>=198501 & Return(:,1)<=201512,:);
rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T = length(R);
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf];

Rx =R12x;  
Ret = [Ret, Rx];

for n = min(Ret(:,6)):max(Ret(:,6))
    aa = find(Ret(:,6)==n);
    Ret(aa(1):aa(11),:) = [];
end
tdate = Ret(Ret(:,6)==3,1);
T1 = length(tdate);

[Xall, Xcum_all] = Func_TRSTAlign(Ret, Ne, tdate);
EP_all = [];
for s = Ns:Ne
   Xcum_s = Xcum_all(:,s);
   Xcum_s = Xcum_s(~any(isnan(Xcum_s),2),:);
   X_s = Xall(:,s);
   X_s = X_s(~any(isnan(X_s),2),:);
   T_s = length(X_s);

   Ret_trst_s = nan(T_s,1);
   for t = 2:T_s
        Ret_trst_s(t) = sign(Xcum_s(t-1))*X_s(t); 
   end
   Ret_trst_s = Ret_trst_s(~any(isnan(Ret_trst_s),2),:);
   Atemp_s = mean(Ret_trst_s);
   
   Xcum_s = Xcum_s(1:end-1);
   X_s = X_s(2:end);
   Btemp_s = mean(sign(Xcum_s))*mean(X_s);
   
   T_s = length(X_s);
   p_s = 1/2*(1+mean(sign(Xcum_s)));
   Vep_s = 4*(T_s-1)/(T_s^2)*p_s*(1-p_s)*var(X_s);
   EP_s = (Atemp_s - Btemp_s)/sqrt(Vep_s);
   EP_all = [EP_all; EP_s];
end

EP_stat = EP_all;
Asset_Names = {'Aluminum','Brent Oil','Live Cattle','Cocoa','Coffee','Copper','Corn','Cotton','Crude Oil','Gas Oil','Gold','Heat Oil','Lean Hogs','Natural Gas',...
'Nickel','Platinum','Silver','Soybean','Soymeal','Soy Oil','Sugar','Unleaded','Wheat','Zinc','SPI 200','DAX','IBEX 35','CAC 40','FTSE/MIB',...
'TOPIX','AEX','FTSE 100','S&P 500','3-year AUS','10-year AUS','2-year EURO','5-year EURO','10-year EURO','30-year EURO','10-year CAN',...
'10-year JP','10-year UK','2-year US','5-year US','10-year US','30-year US','AUD/USD','EUR/USD','CAD/USD','JPY/USD','NOK/USD','NZD/USD','SEK/USD','CHF/USD','GBP/USD'};

Tab7 = table(EP_stat,'RowNames',Asset_Names)





