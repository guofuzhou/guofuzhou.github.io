%% Summary Statistics (Table 1) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;
warning off

Ns = 1; Ne = 55;
SumStat = [];
mean_r = []; Volatility = []; Autocor = [];
h_lq = []; p_lq = []; 
for s = Ns:Ne
   Ret_s = Return(Return(:,6)==s,2);
   mean_r = [mean_r; mean(Ret_s)];
   Volatility = [Volatility; std(Ret_s)];
   Autocor = [Autocor; autocorr(Ret_s,1)];
   [h_s1, p_s1] = lbqtest(Ret_s,'Lags',1);
   h_lq = [h_lq; h_s1];
   p_lq = [p_lq; p_s1];
end
Autocor(1:2:end) = [];
SumStat = [mean_r*100*12, Volatility*100*sqrt(12), Autocor];

Asset_Names = {'Aluminum','Brent Oil','Live Cattle','Cocoa','Coffee','Copper','Corn','Cotton','Crude Oil','Gas Oil','Gold','Heat Oil','Lean Hogs','Natural Gas',...
'Nickel','Platinum','Silver','Soybean','Soymeal','Soy Oil','Sugar','Unleaded','Wheat','Zinc','SPI 200','DAX','IBEX 35','CAC 40','FTSE/MIB',...
'TOPIX','AEX','FTSE 100','S&P 500','3-year AUS','10-year AUS','2-year EURO','5-year EURO','10-year EURO','30-year EURO','10-year CAN',...
'10-year JP','10-year UK','2-year US','5-year US','10-year US','30-year US','AUD/USD','EUR/USD','CAD/USD','JPY/USD','NOK/USD','NZD/USD','SEK/USD','CHF/USD','GBP/USD'};

Tab1 = table(SumStat,'RowNames',Asset_Names)
