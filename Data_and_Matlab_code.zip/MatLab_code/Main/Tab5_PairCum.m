%% Pair bootstrap without volatility scaling using cumulative returns (Table 5) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ns = 1; Ne = 55; 
Return = Return(Return(:,1)>=198501,:);

Rs = Return(:,2);
rf = Return(:,4)+1;
Rcum = Func_GenCum(rf, Rs);
Rcum = [Rcum, Return(:,6)];
% Align lagged cumulative returns %
Rcum1 = [nan; Rcum(1:end-1,1)];
Rcum2 = [nan; Rcum(1:end-1,2)];
Rcum3 = [nan; Rcum(1:end-1,3)];
Rcum4 = [nan; Rcum(1:end-1,4)];
Rcum5 = [nan; Rcum(1:end-1,5)];
Rcum6 = [nan; Rcum(1:end-1,6)];
Rcum7 = [nan; Rcum(1:end-1,7)];
Rcum8 = [nan; Rcum(1:end-1,8)];
Rcum9 = [nan; Rcum(1:end-1,9)];
Rcum10 = [nan; Rcum(1:end-1,10)];
Rcum11 = [nan; Rcum(1:end-1,11)];
Rcum12 = [nan; Rcum(1:end-1,12)];

Rcum_all = [Rcum(:,1), Rcum1, Rcum2, Rcum3, Rcum4, Rcum5, Rcum6,...
    Rcum7, Rcum8, Rcum9, Rcum10, Rcum11, Rcum12];

z0 = Return(:, [1, 6]);                                     %            1      2    3        4-15
z0 = [z0, Rcum_all];                                       % z0 =  [ym, id,  xret, xcum]

% Pair bootstrap for 1000 times %
B = 1000; 
beta_all = nan(B,12); tstat_all = nan(B,12);
beta_sign_all = nan(B,12); tstat_sign_all = nan(B,12);
for i = 1:B
    tic
    Boot_ret1 = []; Boot_ret2 = []; Boot_ret3 = []; Boot_ret4 = []; 
    Boot_ret5 = []; Boot_ret6 = []; Boot_ret7 = []; Boot_ret8 = []; 
    Boot_ret9 = []; Boot_ret10 = []; Boot_ret11 = []; Boot_ret12 = []; 
    for s = Ns:Ne
        rng(s*i);
        tY = z0(z0(:,2)==s,1);                             % z0 =  [ym, id,  xret, xcum]
        Rcum1 = z0(z0(:,2)==s,[1, 2, 3, 4]);
        Rcum1 = Rcum1(2:end,:);
        T = length(Rcum1);
        resample1 = Rcum1(ceil(T*rand(T+100,1)),:);      % randomly draw y and x together
        Boot_ret1 = [Boot_ret1; resample1(101:end,:)];
        
        Rcum2 = z0(z0(:,2)==s,[1, 2, 3, 5]);
        Rcum2 = Rcum2(3:end,:);
        T = length(Rcum2);
        resample2 = Rcum2(ceil(T*rand(T+100,1)),:);      
        Boot_ret2 = [Boot_ret2; resample2(101:end,:)];
        
        Rcum3 = z0(z0(:,2)==s,[1, 2, 3, 6]);
        Rcum3 = Rcum3(4:end,:);
        T = length(Rcum3);
        resample3 = Rcum3(ceil(T*rand(T+100,1)),:);      
        Boot_ret3 = [Boot_ret3; resample3(101:end,:)];
        
        Rcum4 = z0(z0(:,2)==s,[1, 2, 3, 7]);
        Rcum4 = Rcum4(5:end,:);
        T = length(Rcum4);
        resample4 = Rcum4(ceil(T*rand(T+100,1)),:);      
        Boot_ret4 = [Boot_ret4; resample4(101:end,:)];
        
        Rcum5 = z0(z0(:,2)==s,[1, 2, 3, 8]);
        Rcum5 = Rcum5(6:end,:);
        T = length(Rcum5);
        resample5 = Rcum5(ceil(T*rand(T+100,1)),:);      
        Boot_ret5 = [Boot_ret5; resample5(101:end,:)];
        
        Rcum6 = z0(z0(:,2)==s,[1, 2, 3, 9]);
        Rcum6 = Rcum6(7:end,:);
        T = length(Rcum6);
        resample6 = Rcum6(ceil(T*rand(T+100,1)),:);      
        Boot_ret6 = [Boot_ret6; resample6(101:end,:)];
        
        Rcum7 = z0(z0(:,2)==s,[1, 2, 3, 10]);
        Rcum7 = Rcum7(8:end,:);
        T = length(Rcum7);
        resample7 = Rcum7(ceil(T*rand(T+100,1)),:);      
        Boot_ret7 = [Boot_ret7; resample7(101:end,:)];
        
        Rcum8 = z0(z0(:,2)==s,[1, 2, 3, 11]);
        Rcum8 = Rcum8(9:end,:);
        T = length(Rcum8);
        resample8 = Rcum8(ceil(T*rand(T+100,1)),:);      
        Boot_ret8 = [Boot_ret8; resample8(101:end,:)];
        
        Rcum9 = z0(z0(:,2)==s,[1, 2, 3, 12]);
        Rcum9 = Rcum9(10:end,:);
        T = length(Rcum9);
        resample9 = Rcum9(ceil(T*rand(T+100,1)),:);      
        Boot_ret9 = [Boot_ret9; resample9(101:end,:)];
        
        Rcum10 = z0(z0(:,2)==s,[1, 2, 3, 13]);
        Rcum10 = Rcum10(11:end,:);
        T = length(Rcum10);
        resample10 = Rcum10(ceil(T*rand(T+100,1)),:);      
        Boot_ret10 = [Boot_ret10; resample10(101:end,:)];
        
        Rcum11 = z0(z0(:,2)==s,[1, 2, 3, 14]);
        Rcum11 = Rcum11(12:end,:);
        T = length(Rcum11);
        resample11 = Rcum11(ceil(T*rand(T+100,1)),:);      
        Boot_ret11 = [Boot_ret11; resample11(101:end,:)];
        
        Rcum12 = z0(z0(:,2)==s,[1, 2, 3, 15]);
        Rcum12 = Rcum12(13:end,:);
        T = length(Rcum12);
        resample12 = Rcum12(ceil(T*rand(T+100,1)),:);      
        Boot_ret12 = [Boot_ret12; resample12(101:end,:)];
    end
    res_i = []; res_sign_i = [];
    
    % 1 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret1(:,2) == n);                        %    1         2         3-14       
       a = Boot_ret1(tt,:);                                           %   [ym      ID       xcum]
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 2 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret2(:,2) == n);                        
       a = Boot_ret2(tt,:);                                           
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 3 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret3(:,2) == n);                       
       a = Boot_ret3(tt,:);                                         
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 4 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret4(:,2) == n);                  
       a = Boot_ret4(tt,:);                                    
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 5 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret5(:,2) == n);                   
       a = Boot_ret5(tt,:);                                        
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 6 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret6(:,2) == n);                    
       a = Boot_ret6(tt,:);                                   
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 7 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret7(:,2) == n);                    
       a = Boot_ret7(tt,:);                                      
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 8 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret8(:,2) == n);                     
       a = Boot_ret8(tt,:);                                        
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 9 month %
    yy = []; 
    for n = Ns:Ne
       tt = find(Boot_ret9(:,2) == n);                  
       a = Boot_ret9(tt,:);                                      
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 10 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret10(:,2) == n);                   
       a = Boot_ret10(tt,:);                                       
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 11 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret11(:,2) == n);                
       a = Boot_ret11(tt,:);                                    
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 12 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret12(:,2) == n);                 
       a = Boot_ret12(tt,:);                                  
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
   
    beta_all(i,:) = res_i(:,1)';
    tstat_all(i,:) = res_i(:,2)';
    beta_sign_all(i,:) = res_sign_i(:,1)';
    tstat_sign_all(i,:) = res_sign_i(:,2)';
    toc
    i
end

save('E:\RESEARCH\TSMOM\Codes_new\Tab5_PairCum.mat','beta_all', 'beta_sign_all', 'tstat_all', 'tstat_sign_all')
