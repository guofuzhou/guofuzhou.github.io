%% Pooled regression without volatility scaling (t-stat for Tab 5, Panel A) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ns = 1; Ne = 55; 
Return = Return(Return(:,6)>=Ns & Return(:,6)<=Ne,:);

z = Return(:, [1, 2, 6]);                                   % [ym, xret, id]

res = []; res_sign = [];
for h = 1:12
    yy = [];
    for n = Ns:Ne 
        tt = find(z(:,3) == n);
        a = z(tt,:);                                                 % [ym, xret, id]
        yy = [yy; a(h+1:end,2), a(1:end-h,2), a(h+1:end,[1, 3])];   % yy = [y, x,  ym, ID]; 
    end
  b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
  res = [res; b(1, [1, 3]), b(2, [1, 3])];
  
  b = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
  res_sign = [res_sign; b(1, [1, 3]), b(2, [1, 3])]; 
end

save('E:\RESEARCH\TSMOM\Codes_new\Tab5_TstatAll.mat','res','res_sign')

