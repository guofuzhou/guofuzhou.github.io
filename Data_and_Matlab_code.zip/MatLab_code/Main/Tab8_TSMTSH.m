%% TSM vs. TSH at the asset level (Table 8) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ns = 1; Ne = 55; 
Ret = Return(Return(:,1)>=198501,:);
rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T = length(R);
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf];                         

Rx =R12x;  
Ret = [Ret, Rx];
% Generate historical mean return %
Ret_mean = [];
for i = Ns:Ne
  Ret_i = Ret(Ret(:,6)==i,2);  
  T = length(Ret_i);
  mean_i = nan(T,1);
  for t = 1:T
     mean_i(t) = mean(Ret_i(1:t));
  end
  Ret_mean = [Ret_mean; mean_i];
end
Ret = [Ret, Ret_mean];

% Drop the first 11 ovservations for each asset %
for n = Ns:Ne
   aa = find(Ret(:,6)==n);
   Ret(aa(1):aa(11),:) = [];
end

% Define the longest time period %
tdate = Ret(Ret(:,6)==3,1);
% Calculate TSM and TSH strategy return series %
[aRet_tsm, annual_tsm, Ret_tsm] = Func_TSMTab8(Ret,Ne, tdate);
[aRet_tsh, annual_tsh, Ret_tsh] = Func_TSHTab8(Ret,Ne, tdate);

Diff_Ret = nan(55,1); pv_Ret = nan(55,1);
Diff_Sharpe = nan(55,1); pv_Share = nan(55,1);
IndRet_tsm = nan(55,1); IndRet_tsh = nan(55,1);
Sharpe_tsm = nan(55,1); Sharpe_tsh = nan(55,1);
z_Sharpe = nan(55,1);
for j = Ns:Ne
   Ret_tsm_j = Ret_tsm(:,j);
   Ret_tsm_j = Ret_tsm_j(~isnan(Ret_tsm_j));
   
   Ret_tsh_j = Ret_tsh(:,j);
   Ret_tsh_j = Ret_tsh_j(~isnan(Ret_tsh_j));
   
   IndRet_tsm(j) = mean(Ret_tsm_j)*100;
   IndRet_tsh(j) = mean(Ret_tsh_j)*100;
   
   Sharpe_tsm(j) = mean(Ret_tsm_j)/std(Ret_tsm_j);
   Sharpe_tsh(j) = mean(Ret_tsh_j)/std(Ret_tsh_j);
  
   Diff_Ret(j) = (IndRet_tsm(j) - IndRet_tsh(j));
   [h1, p1] = ttest(Ret_tsm_j-Ret_tsh_j);
   pv_Ret(j) = p1;
   
   Diff_Sharpe(j) = Sharpe_tsm(j) - Sharpe_tsh(j);
   T = length(Ret_tsm_j);
   mu_tsm = mean(Ret_tsm_j);
   mu_tsh = mean(Ret_tsh_j);
   sig_tsm = std(Ret_tsm_j);
   sig_tsh = std(Ret_tsh_j);
   covar_tsmtsh = cov(Ret_tsm_j, Ret_tsh_j);
   covar_tsmtsh = covar_tsmtsh(1,2);                      % covariance coefficient

   v_tsmtsh = 1/T*(2*sig_tsm^2*sig_tsh^2 - 2*sig_tsm*sig_tsh*covar_tsmtsh + 1/2*mu_tsm^2*sig_tsh^2 ...
   + 1/2*mu_tsh^2*sig_tsm^2 - (mu_tsm*mu_tsh/sig_tsm/sig_tsh*covar_tsmtsh^2));
   z_Sharpe(j) = (sig_tsh*mu_tsm-sig_tsm*mu_tsh)/sqrt(v_tsmtsh);   % z-stat should be convert to p-value
end

Asset_Names = {'Aluminum','Brentoil','Cattle','Cocoa','Coffee','Copper','Corn','Cotton','Crude','Gasoil','Gold','Heatoil','Hogs','Natgas',...
'Nickel','Platinum','Silver','Soybean','Soymeal','Soyoil','Sugar','Unleaded','Wheat','Zinc','SPI 200','DAX','IBEX 35','CAC 40','FTSE/MIB',...
'TOPIX','AEX','FTSE 100','S&P 500','3-year AUS','10-year AUS','2-year EURO','5-year EURO','10-year EURO','30-year EURO','10-year CAN',...
'10-year JP','10-year UK','2-year US','5-year US','10-year US','30-year US','AUD/USD','EUR/USD','CAD/USD','JPY/USD','NOK/USD','NZD/USD',...
'SEK/USD','CHF/USD','GBP/USD'};
Tab8 = table(IndRet_tsm, IndRet_tsh, Sharpe_tsm, Sharpe_tsh, Diff_Ret, pv_Ret, Diff_Sharpe, z_Sharpe, 'RowNames',Asset_Names)

