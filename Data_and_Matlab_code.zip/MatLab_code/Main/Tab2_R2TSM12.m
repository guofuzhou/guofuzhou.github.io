%% TSM with time-series regression (Table 2) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ns = 1; Ne = 55;
Ret = Return(Return(:,1)>=198501,:);
rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T = length(R);
R1x = Ret(:,2);
R3x = R(1:T-2).*R(2:T-1).*R(3:T) - rf(1:T-2).*rf(2:T-1).*rf(3:T); 
R3x = [nan(2,1); R3x]/3;
R6x = R(1:T-5).*R(2:T-4).*R(3:T-3).*R(4:T-2).*R(5:T-1).*R(6:T) -...
      rf(1:T-5).*rf(2:T-4).*rf(3:T-3).*rf(4:T-2).*rf(5:T-1).*rf(6:T);
R6x = [nan(5,1); R6x]/6;  
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf]/12;
Rx =R12x; Ret = [Ret, Rx];

for s = Ns:Ne
    aa = find(Ret(:,6)==s);
    Ret(aa(1):aa(11),:) = [];
end

res_ins = []; res_oos = [];
for s = Ns:Ne
    X_cum = Ret(Ret(:,6)==s,7);
    Y = Ret(Ret(:,6)==s,2)*100;
    tX = Ret(Ret(:,6)==s,1);
    rhv = [ones(size(Y)), zscore(X_cum)];
    
    % In-sample %
   [bv,sebv,R2v,R2vadj,v,F]=olsgmm(Y(2:end),rhv(1:end-1,:),12,1);
   res_ins = [res_ins; bv(2:end)', bv(2:end)'./sebv(2:end)', R2v*100];
   
   % Out-of-sample %
   % Starting time 200001 %
   yhat = nan*Y; ybar = nan*Y;
   bb = find(tX(:)==199912);
   rhv = [ones(size(Y)), X_cum];
   for t = bb+1:length(Y)
        R = Y(2:t-1);
        E = rhv(1:t-2,:);
        b = regress(R,E);
        yhat(t) = rhv(t-1,:)*b;
        ybar(t) = mean(Y(1:t-1));
   end
yos = Y(bb+1:end); ybar = ybar(bb+1:end); yhat = yhat(bb+1:end); 
%yhat = max(0,yhat);
OS = R2oostest(yos,ybar,yhat,4);
res_oos = [res_oos; OS(1:2)];
end

fprintf('\n\nIn-sample \n\n')
mean(res_ins(:,3))    
fprintf('\n\nOut-of-sample \n\n')
mean(res_oos(:,1)) 

beta = res_ins(:,1);
tstat = res_ins(:,2);
R2 = res_ins(:,3);
R2oos = res_oos(:,1);
CW = res_oos(:,2);

Asset_Names = {'Aluminum','Brent Oil','Live Cattle','Cocoa','Coffee','Copper','Corn','Cotton','Crude Oil','Gas Oil','Gold','Heat Oil','Lean Hogs','Natural Gas',...
'Nickel','Platinum','Silver','Soybean','Soymeal','Soy Oil','Sugar','Unleaded','Wheat','Zinc','SPI 200','DAX','IBEX 35','CAC 40','FTSE/MIB',...
'TOPIX','AEX','FTSE 100','S&P 500','3-year AUS','10-year AUS','2-year EURO','5-year EURO','10-year EURO','30-year EURO','10-year CAN',...
'10-year JP','10-year UK','2-year US','5-year US','10-year US','30-year US','AUD/USD','EUR/USD','CAD/USD','JPY/USD','NOK/USD','NZD/USD','SEK/USD','CHF/USD','GBP/USD'};

Tab2 = table(beta, tstat, R2, R2oos, CW,'RowNames',Asset_Names)




