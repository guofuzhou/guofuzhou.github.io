%% Pooled Regression with Cumulative Returns scaled by Volatility (t-stat for Table A1) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;
%% Commodity %%
Ns = 1; Ne = 24;
Return = Return(Return(:,6)>=Ns & Return(:,6)<=Ne,:);
Return = Return(Return(:,1)>=198501 & Return(:,1)<=200912,:);
Rs = Return(:,2);
rf = Return(:,4)+1;
Exvol = Return(:,3);
Rcum = Func_GenCum(rf, Rs);

Rcumvol = Rcum(2:end,:)./Exvol(1:end-1);
z = [nan(1,12); Rcumvol];
z = [z, Return(:,1), Return(:,6)];

for n = Ns:Ne
    line1 = find(z(:,14)==n);
    z(line1(1):line1(12),:) = [];
end

res_com = []; ressign_com = [];
for h = 1:12
   yy = [];
   for n = Ns:Ne 
       tt = find(z(:,14) == n);                                                                        %    1 -12             13       14   
       a = z(tt,:);                                                                                             %    xcum/exvol    ym      ID
       yy = [yy; a(2:end,1), a(1:end-1,h), a(2:end,[13, 14])];                %    yy = [y, x,  ym, ID]; 
   end
b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
res_com = [res_com; b(1, [1 3]), b(2, [1 3])];
b = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
ressign_com = [ressign_com; b(1, [1 3]), b(2, [1 3])];
end

save('E:\RESEARCH\TSMOM\Codes_new\TabA1_TstatCom2009.mat','res_com','ressign_com')

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;
%% Equity %%
Ns = 25; Ne = 33;
Return = Return(Return(:,6)>=Ns & Return(:,6)<=Ne,:);
Return = Return(Return(:,1)>=198501 & Return(:,1)<=200912,:);
Rs = Return(:,2);
rf = Return(:,4)+1;
Exvol = Return(:,3);
Rcum = Func_GenCum(rf, Rs);

Rcumvol = Rcum(2:end,:)./Exvol(1:end-1);
z = [nan(1,12); Rcumvol];
z = [z, Return(:,1), Return(:,6)];

for n = Ns:Ne
    line1 = find(z(:,14)==n);
    z(line1(1):line1(12),:) = [];
end

res_eqt = []; ressign_eqt = [];
for h = 1:12
   yy = [];
   for n = Ns:Ne 
       tt = find(z(:,14) == n);                                                                        %    1 -12             13       14   
       a = z(tt,:);                                                                                             %    xcum/exvol    ym      ID
       yy = [yy; a(2:end,1), a(1:end-1,h), a(2:end,[13, 14])];               %    yy = [y, x,  ym, ID]; 
   end
b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
res_eqt = [res_eqt; b(1, [1 3]), b(2, [1 3])];
b = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
ressign_eqt = [ressign_eqt; b(1, [1 3]), b(2, [1 3])];
end

save('E:\RESEARCH\TSMOM\Codes_new\TabA1_TstatEqt2009.mat','res_eqt','ressign_eqt')

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;
%% Bond %%
Ns = 34; Ne = 46;
Return = Return(Return(:,6)>=Ns & Return(:,6)<=Ne,:);
Return = Return(Return(:,1)>=198501 & Return(:,1)<=200912,:);
Rs = Return(:,2);
rf = Return(:,4)+1;
Exvol = Return(:,3);
Rcum = Func_GenCum(rf, Rs);

Rcumvol = Rcum(2:end,:)./Exvol(1:end-1);
z = [nan(1,12); Rcumvol];
z = [z, Return(:,1), Return(:,6)];

for n = Ns:Ne
    line1 = find(z(:,14)==n);
    z(line1(1):line1(12),:) = [];
end

res_bond = []; ressign_bond = [];
for h = 1:12
   yy = [];
   for n = Ns:Ne 
       tt = find(z(:,14) == n);                                                                        %    1 -12             13       14   
       a = z(tt,:);                                                                                             %    xcum/exvol    ym      ID
       yy = [yy; a(2:end,1), a(1:end-1,h), a(2:end,[13, 14])];               %    yy = [y, x,  ym, ID]; 
   end
b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
res_bond = [res_bond; b(1, [1 3]), b(2, [1 3])];
b = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
ressign_bond = [ressign_bond; b(1, [1 3]), b(2, [1 3])];
end

save('E:\RESEARCH\TSMOM\Codes_new\TabA1_TstatBnd2009.mat','res_bond','ressign_bond')

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;
%% Currency %%
Ns = 47; Ne = 55;
Return = Return(Return(:,6)>=Ns & Return(:,6)<=Ne,:);
Return = Return(Return(:,1)>=198501 & Return(:,1)<=200912,:);
Rs = Return(:,2);
rf = Return(:,4)+1;
Exvol = Return(:,3);
Rcum = Func_GenCum(rf, Rs);

Rcumvol = Rcum(2:end,:)./Exvol(1:end-1);
z = [nan(1,12); Rcumvol];
z = [z, Return(:,1), Return(:,6)];

for n = Ns:Ne
    line1 = find(z(:,14)==n);
    z(line1(1):line1(12),:) = [];
end

res_cur = []; ressign_cur = [];
for h = 1:12
   yy = [];
   for n = Ns:Ne 
       tt = find(z(:,14) == n);                                                                        %    1 -12             13       14   
       a = z(tt,:);                                                                                             %    xcum/exvol    ym      ID
       yy = [yy; a(2:end,1), a(1:end-1,h), a(2:end,[13, 14])];               %    yy = [y, x,  ym, ID]; 
   end
b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
res_cur = [res_cur; b(1, [1 3]), b(2, [1 3])];
b = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
ressign_cur = [ressign_cur; b(1, [1 3]), b(2, [1 3])];
end

save('E:\RESEARCH\TSMOM\Codes_new\TabA1_TstatCur2009.mat','res_cur','ressign_cur')
  