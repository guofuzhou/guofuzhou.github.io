%% Pair bootstrap with volatility scaling using cumulative returns (Table A1, 1985 - 2009) %%

%% Commodity %%
clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ns = 1; Ne = 24; 
Return = Return(Return(:,1)>=198501 & Return(:,1)<=200912,:);
Return = Return(Return(:,6)<=Ne,:);

Rs = Return(:,2);
rf = Return(:,4)+1;
exVol = Return(:,3);
Rcum = Func_GenCum(rf, Rs);
Rcumvol = Rcum(2:end,:)./exVol(1:end-1);
Rcumvol = [nan(1,12); Rcumvol];
Rcumvol = [Rcumvol, Return(:,6)];
% Drop first 12 observations in case of NaN %
for ss = Ns:Ne
  aa = find(Rcumvol(:,13)==ss);
  Rcumvol(aa(1):aa(12),:) = [];
  bb = find(Return(:,6)==ss);
  Return(bb(1):bb(12),:) = [];
end
% Align vol-scaled cumulative returns into one matrix %
Retvol1 = [nan; Rcumvol(1:end-1,1)];
Retvol2 = [nan; Rcumvol(1:end-1,2)];
Retvol3 = [nan; Rcumvol(1:end-1,3)];
Retvol4 = [nan; Rcumvol(1:end-1,4)];
Retvol5 = [nan; Rcumvol(1:end-1,5)];
Retvol6 = [nan; Rcumvol(1:end-1,6)];
Retvol7 = [nan; Rcumvol(1:end-1,7)];
Retvol8 = [nan; Rcumvol(1:end-1,8)];
Retvol9 = [nan; Rcumvol(1:end-1,9)];
Retvol10 = [nan; Rcumvol(1:end-1,10)];
Retvol11 = [nan; Rcumvol(1:end-1,11)];
Retvol12 = [nan; Rcumvol(1:end-1,12)];

Retvol_all = [Rcumvol(:,1), Retvol1, Retvol2, Retvol3, Retvol4, Retvol5, Retvol6,...
    Retvol7, Retvol8, Retvol9, Retvol10, Retvol11, Retvol12];

z0 = Return(:, [1, 6]);                                     %            1      2       3   4    5       6-17
z0 = [z0, Retvol_all];                                      % z0 =  [ym, xret, rf, id, vol, xcum/vol]

% Pair bootstrap for 1000 times %
B = 1000; 
beta_all = nan(B,12); tstat_all = nan(B,12);
beta_sign_all = nan(B,12); tstat_sign_all = nan(B,12);
for i = 1:B
    tic
    Boot_ret1 = []; Boot_ret2 = []; Boot_ret3 = []; Boot_ret4 = []; 
    Boot_ret5 = []; Boot_ret6 = []; Boot_ret7 = []; Boot_ret8 = []; 
    Boot_ret9 = []; Boot_ret10 = []; Boot_ret11 = []; Boot_ret12 = []; 
    for s = Ns:Ne
        rng(s*i);
        tY = z0(z0(:,2)==s,1);                             % z0 = [ym, xret, rf, id, vol, xcum/vol] 
        Retvol1 = z0(z0(:,2)==s,[1, 2, 3, 4]);
        Retvol1 = Retvol1(2:end,:);
        T = length(Retvol1);
        resample1 = Retvol1(ceil(T*rand(T+100,1)),:);      % randomly draw y and x together
        Boot_ret1 = [Boot_ret1; resample1(101:end,:)];
        
        Retvol2 = z0(z0(:,2)==s,[1, 2, 3, 5]);
        Retvol2 = Retvol2(2:end,:);
        T = length(Retvol2);
        resample2 = Retvol2(ceil(T*rand(T+100,1)),:);     
        Boot_ret2 = [Boot_ret2; resample2(101:end,:)];
        
        Retvol3 = z0(z0(:,2)==s,[1, 2, 3, 6]);
        Retvol3 = Retvol3(2:end,:);
        T = length(Retvol3);
        resample3 = Retvol3(ceil(T*rand(T+100,1)),:);      
        Boot_ret3 = [Boot_ret3; resample3(101:end,:)];
        
        Retvol4 = z0(z0(:,2)==s,[1, 2, 3, 7]);
        Retvol4 = Retvol4(2:end,:);
        T = length(Retvol4);
        resample4 = Retvol4(ceil(T*rand(T+100,1)),:);     
        Boot_ret4 = [Boot_ret4; resample4(101:end,:)];
        
        Retvol5 = z0(z0(:,2)==s,[1, 2, 3, 8]);
        Retvol5 = Retvol5(2:end,:);
        T = length(Retvol5);
        resample5 = Retvol5(ceil(T*rand(T+100,1)),:);     
        Boot_ret5 = [Boot_ret5; resample5(101:end,:)];
        
        Retvol6 = z0(z0(:,2)==s,[1, 2, 3, 9]);
        Retvol6 = Retvol6(2:end,:);
        T = length(Retvol6);
        resample6 = Retvol6(ceil(T*rand(T+100,1)),:);     
        Boot_ret6 = [Boot_ret6; resample6(101:end,:)];
        
        Retvol7 = z0(z0(:,2)==s,[1, 2, 3, 10]);
        Retvol7 = Retvol7(2:end,:);
        T = length(Retvol7);
        resample7 = Retvol7(ceil(T*rand(T+100,1)),:);     
        Boot_ret7 = [Boot_ret7; resample7(101:end,:)];
        
        Retvol8 = z0(z0(:,2)==s,[1, 2, 3, 11]);
        Retvol8 = Retvol8(2:end,:);
        T = length(Retvol8);
        resample8 = Retvol8(ceil(T*rand(T+100,1)),:);     
        Boot_ret8 = [Boot_ret8; resample8(101:end,:)];
        
        Retvol9 = z0(z0(:,2)==s,[1, 2, 3, 12]);
        Retvol9 = Retvol9(2:end,:);
        T = length(Retvol9);
        resample9 = Retvol9(ceil(T*rand(T+100,1)),:);     
        Boot_ret9 = [Boot_ret9; resample9(101:end,:)];
        
        Retvol10 = z0(z0(:,2)==s,[1, 2, 3, 13]);
        Retvol10 = Retvol10(2:end,:);
        T = length(Retvol10);
        resample10 = Retvol10(ceil(T*rand(T+100,1)),:);      
        Boot_ret10 = [Boot_ret10; resample10(101:end,:)];
        
        Retvol11 = z0(z0(:,2)==s,[1, 2, 3, 14]);
        Retvol11 = Retvol11(2:end,:);
        T = length(Retvol11);
        resample11 = Retvol11(ceil(T*rand(T+100,1)),:);      
        Boot_ret11 = [Boot_ret11; resample11(101:end,:)];
        
        Retvol12 = z0(z0(:,2)==s,[1, 2, 3, 15]);
        Retvol12 = Retvol12(2:end,:);
        T = length(Retvol12);
        resample12 = Retvol12(ceil(T*rand(T+100,1)),:);      
        Boot_ret12 = [Boot_ret12; resample12(101:end,:)];
    end
    res_i = []; res_sign_i = [];
    
    % 1 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret1(:,2) == n);                        %    1         2         3-14       
       a = Boot_ret1(tt,:);                                           %   ym      ID      xcum/vol  
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 2 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret2(:,2) == n);                       
       a = Boot_ret2(tt,:);                                          
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 3 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret3(:,2) == n);                        
       a = Boot_ret3(tt,:);                                           
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 4 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret4(:,2) == n);                        
       a = Boot_ret4(tt,:);                                          
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 5 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret5(:,2) == n);                      
       a = Boot_ret5(tt,:);                                         
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 6 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret6(:,2) == n);                     
       a = Boot_ret6(tt,:);                                         
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 7 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret7(:,2) == n);                   
       a = Boot_ret7(tt,:);                                     
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 8 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret8(:,2) == n);                
       a = Boot_ret8(tt,:);                                      
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 9 month %
    yy = []; 
    for n = Ns:Ne
       tt = find(Boot_ret9(:,2) == n);                 
       a = Boot_ret9(tt,:);                                      
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 10 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret10(:,2) == n);               
       a = Boot_ret10(tt,:);                                   
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 11 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret11(:,2) == n);              
       a = Boot_ret11(tt,:);                                   
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 12 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret12(:,2) == n);               
       a = Boot_ret12(tt,:);                                 
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
   
    beta_all(i,:) = res_i(:,1)';
    tstat_all(i,:) = res_i(:,2)';
    beta_sign_all(i,:) = res_sign_i(:,1)';
    tstat_sign_all(i,:) = res_sign_i(:,2)';
    toc
    i
end

save('E:\RESEARCH\TSMOM\Codes_new\TabA1_PairCom2009.mat','beta_all','beta_sign_all', 'tstat_all', 'tstat_sign_all')

%% Equity %%
clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ns = 25; Ne = 33; 
Return = Return(Return(:,1)>=198501 & Return(:,1)<=200912,:);
Return = Return(Return(:,6)>=Ns & Return(:,6)<=Ne,:);

Rs = Return(:,2);
rf = Return(:,4)+1;
exVol = Return(:,3);
Rcum = Func_GenCum(rf, Rs);
Rcumvol = Rcum(2:end,:)./exVol(1:end-1);
Rcumvol = [nan(1,12); Rcumvol];
Rcumvol = [Rcumvol, Return(:,6)];
% Drop first 12 observations in case of NaN %
for ss = Ns:Ne
  aa = find(Rcumvol(:,13)==ss);
  Rcumvol(aa(1):aa(12),:) = [];
  bb = find(Return(:,6)==ss);
  Return(bb(1):bb(12),:) = [];
end
% Align vol-scaled cumulative returns into one matrix %
Retvol1 = [nan; Rcumvol(1:end-1,1)];
Retvol2 = [nan; Rcumvol(1:end-1,2)];
Retvol3 = [nan; Rcumvol(1:end-1,3)];
Retvol4 = [nan; Rcumvol(1:end-1,4)];
Retvol5 = [nan; Rcumvol(1:end-1,5)];
Retvol6 = [nan; Rcumvol(1:end-1,6)];
Retvol7 = [nan; Rcumvol(1:end-1,7)];
Retvol8 = [nan; Rcumvol(1:end-1,8)];
Retvol9 = [nan; Rcumvol(1:end-1,9)];
Retvol10 = [nan; Rcumvol(1:end-1,10)];
Retvol11 = [nan; Rcumvol(1:end-1,11)];
Retvol12 = [nan; Rcumvol(1:end-1,12)];

Retvol_all = [Rcumvol(:,1), Retvol1, Retvol2, Retvol3, Retvol4, Retvol5, Retvol6,...
    Retvol7, Retvol8, Retvol9, Retvol10, Retvol11, Retvol12];

z0 = Return(:, [1, 6]);                                     %            1      2       3   4    5       6-17
z0 = [z0, Retvol_all];                                      % z0 =  [ym, xret, rf, id, vol, xcum/vol]

% Pair bootstrap for 1000 times %
B = 1000; 
beta_all = nan(B,12); tstat_all = nan(B,12);
beta_sign_all = nan(B,12); tstat_sign_all = nan(B,12);
for i = 1:B
    tic
    Boot_ret1 = []; Boot_ret2 = []; Boot_ret3 = []; Boot_ret4 = []; 
    Boot_ret5 = []; Boot_ret6 = []; Boot_ret7 = []; Boot_ret8 = []; 
    Boot_ret9 = []; Boot_ret10 = []; Boot_ret11 = []; Boot_ret12 = []; 
    for s = Ns:Ne
        rng(s*i);
        tY = z0(z0(:,2)==s,1);                             % z0 = [ym, xret, rf, id, vol, xcum/vol] 
        Retvol1 = z0(z0(:,2)==s,[1, 2, 3, 4]);
        Retvol1 = Retvol1(2:end,:);
        T = length(Retvol1);
        resample1 = Retvol1(ceil(T*rand(T+100,1)),:);      % randomly draw y and x together
        Boot_ret1 = [Boot_ret1; resample1(101:end,:)];
        
        Retvol2 = z0(z0(:,2)==s,[1, 2, 3, 5]);
        Retvol2 = Retvol2(2:end,:);
        T = length(Retvol2);
        resample2 = Retvol2(ceil(T*rand(T+100,1)),:);     
        Boot_ret2 = [Boot_ret2; resample2(101:end,:)];
        
        Retvol3 = z0(z0(:,2)==s,[1, 2, 3, 6]);
        Retvol3 = Retvol3(2:end,:);
        T = length(Retvol3);
        resample3 = Retvol3(ceil(T*rand(T+100,1)),:);      
        Boot_ret3 = [Boot_ret3; resample3(101:end,:)];
        
        Retvol4 = z0(z0(:,2)==s,[1, 2, 3, 7]);
        Retvol4 = Retvol4(2:end,:);
        T = length(Retvol4);
        resample4 = Retvol4(ceil(T*rand(T+100,1)),:);     
        Boot_ret4 = [Boot_ret4; resample4(101:end,:)];
        
        Retvol5 = z0(z0(:,2)==s,[1, 2, 3, 8]);
        Retvol5 = Retvol5(2:end,:);
        T = length(Retvol5);
        resample5 = Retvol5(ceil(T*rand(T+100,1)),:);     
        Boot_ret5 = [Boot_ret5; resample5(101:end,:)];
        
        Retvol6 = z0(z0(:,2)==s,[1, 2, 3, 9]);
        Retvol6 = Retvol6(2:end,:);
        T = length(Retvol6);
        resample6 = Retvol6(ceil(T*rand(T+100,1)),:);     
        Boot_ret6 = [Boot_ret6; resample6(101:end,:)];
        
        Retvol7 = z0(z0(:,2)==s,[1, 2, 3, 10]);
        Retvol7 = Retvol7(2:end,:);
        T = length(Retvol7);
        resample7 = Retvol7(ceil(T*rand(T+100,1)),:);     
        Boot_ret7 = [Boot_ret7; resample7(101:end,:)];
        
        Retvol8 = z0(z0(:,2)==s,[1, 2, 3, 11]);
        Retvol8 = Retvol8(2:end,:);
        T = length(Retvol8);
        resample8 = Retvol8(ceil(T*rand(T+100,1)),:);     
        Boot_ret8 = [Boot_ret8; resample8(101:end,:)];
        
        Retvol9 = z0(z0(:,2)==s,[1, 2, 3, 12]);
        Retvol9 = Retvol9(2:end,:);
        T = length(Retvol9);
        resample9 = Retvol9(ceil(T*rand(T+100,1)),:);     
        Boot_ret9 = [Boot_ret9; resample9(101:end,:)];
        
        Retvol10 = z0(z0(:,2)==s,[1, 2, 3, 13]);
        Retvol10 = Retvol10(2:end,:);
        T = length(Retvol10);
        resample10 = Retvol10(ceil(T*rand(T+100,1)),:);      
        Boot_ret10 = [Boot_ret10; resample10(101:end,:)];
        
        Retvol11 = z0(z0(:,2)==s,[1, 2, 3, 14]);
        Retvol11 = Retvol11(2:end,:);
        T = length(Retvol11);
        resample11 = Retvol11(ceil(T*rand(T+100,1)),:);      
        Boot_ret11 = [Boot_ret11; resample11(101:end,:)];
        
        Retvol12 = z0(z0(:,2)==s,[1, 2, 3, 15]);
        Retvol12 = Retvol12(2:end,:);
        T = length(Retvol12);
        resample12 = Retvol12(ceil(T*rand(T+100,1)),:);      
        Boot_ret12 = [Boot_ret12; resample12(101:end,:)];
    end
    res_i = []; res_sign_i = [];
    
    % 1 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret1(:,2) == n);                        %    1         2         3-14       
       a = Boot_ret1(tt,:);                                           %   ym      ID      xcum/vol  
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 2 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret2(:,2) == n);                       
       a = Boot_ret2(tt,:);                                          
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 3 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret3(:,2) == n);                        
       a = Boot_ret3(tt,:);                                           
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 4 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret4(:,2) == n);                        
       a = Boot_ret4(tt,:);                                          
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 5 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret5(:,2) == n);                      
       a = Boot_ret5(tt,:);                                         
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 6 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret6(:,2) == n);                     
       a = Boot_ret6(tt,:);                                         
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 7 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret7(:,2) == n);                   
       a = Boot_ret7(tt,:);                                     
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 8 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret8(:,2) == n);                
       a = Boot_ret8(tt,:);                                      
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 9 month %
    yy = []; 
    for n = Ns:Ne
       tt = find(Boot_ret9(:,2) == n);                 
       a = Boot_ret9(tt,:);                                      
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 10 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret10(:,2) == n);               
       a = Boot_ret10(tt,:);                                   
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 11 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret11(:,2) == n);              
       a = Boot_ret11(tt,:);                                   
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 12 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret12(:,2) == n);               
       a = Boot_ret12(tt,:);                                 
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
   
    beta_all(i,:) = res_i(:,1)';
    tstat_all(i,:) = res_i(:,2)';
    beta_sign_all(i,:) = res_sign_i(:,1)';
    tstat_sign_all(i,:) = res_sign_i(:,2)';
    toc
    i
end

save('E:\RESEARCH\TSMOM\Codes_new\TabA1_PairEqt2009.mat','beta_all','beta_sign_all', 'tstat_all', 'tstat_sign_all')

%% Bond %%
clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ns = 34; Ne = 46; 
Return = Return(Return(:,1)>=198501 & Return(:,1)<=200912,:);
Return = Return(Return(:,6)>=Ns & Return(:,6)<=Ne,:);

Rs = Return(:,2);
rf = Return(:,4)+1;
exVol = Return(:,3);
Rcum = Func_GenCum(rf, Rs);
Rcumvol = Rcum(2:end,:)./exVol(1:end-1);
Rcumvol = [nan(1,12); Rcumvol];
Rcumvol = [Rcumvol, Return(:,6)];
% Drop first 12 observations in case of NaN %
for ss = Ns:Ne
  aa = find(Rcumvol(:,13)==ss);
  Rcumvol(aa(1):aa(12),:) = [];
  bb = find(Return(:,6)==ss);
  Return(bb(1):bb(12),:) = [];
end
% Align vol-scaled cumulative returns into one matrix %
Retvol1 = [nan; Rcumvol(1:end-1,1)];
Retvol2 = [nan; Rcumvol(1:end-1,2)];
Retvol3 = [nan; Rcumvol(1:end-1,3)];
Retvol4 = [nan; Rcumvol(1:end-1,4)];
Retvol5 = [nan; Rcumvol(1:end-1,5)];
Retvol6 = [nan; Rcumvol(1:end-1,6)];
Retvol7 = [nan; Rcumvol(1:end-1,7)];
Retvol8 = [nan; Rcumvol(1:end-1,8)];
Retvol9 = [nan; Rcumvol(1:end-1,9)];
Retvol10 = [nan; Rcumvol(1:end-1,10)];
Retvol11 = [nan; Rcumvol(1:end-1,11)];
Retvol12 = [nan; Rcumvol(1:end-1,12)];

Retvol_all = [Rcumvol(:,1), Retvol1, Retvol2, Retvol3, Retvol4, Retvol5, Retvol6,...
    Retvol7, Retvol8, Retvol9, Retvol10, Retvol11, Retvol12];

z0 = Return(:, [1, 6]);                                     %            1      2       3   4    5       6-17
z0 = [z0, Retvol_all];                                      % z0 =  [ym, xret, rf, id, vol, xcum/vol]

% Pair bootstrap for 1000 times %
B = 1000; 
beta_all = nan(B,12); tstat_all = nan(B,12);
beta_sign_all = nan(B,12); tstat_sign_all = nan(B,12);
for i = 1:B
    tic
    Boot_ret1 = []; Boot_ret2 = []; Boot_ret3 = []; Boot_ret4 = []; 
    Boot_ret5 = []; Boot_ret6 = []; Boot_ret7 = []; Boot_ret8 = []; 
    Boot_ret9 = []; Boot_ret10 = []; Boot_ret11 = []; Boot_ret12 = []; 
    for s = Ns:Ne
        rng(s*i);
        tY = z0(z0(:,2)==s,1);                             % z0 = [ym, xret, rf, id, vol, xcum/vol] 
        Retvol1 = z0(z0(:,2)==s,[1, 2, 3, 4]);
        Retvol1 = Retvol1(2:end,:);
        T = length(Retvol1);
        resample1 = Retvol1(ceil(T*rand(T+100,1)),:);      % randomly draw y and x together
        Boot_ret1 = [Boot_ret1; resample1(101:end,:)];
        
        Retvol2 = z0(z0(:,2)==s,[1, 2, 3, 5]);
        Retvol2 = Retvol2(2:end,:);
        T = length(Retvol2);
        resample2 = Retvol2(ceil(T*rand(T+100,1)),:);     
        Boot_ret2 = [Boot_ret2; resample2(101:end,:)];
        
        Retvol3 = z0(z0(:,2)==s,[1, 2, 3, 6]);
        Retvol3 = Retvol3(2:end,:);
        T = length(Retvol3);
        resample3 = Retvol3(ceil(T*rand(T+100,1)),:);      
        Boot_ret3 = [Boot_ret3; resample3(101:end,:)];
        
        Retvol4 = z0(z0(:,2)==s,[1, 2, 3, 7]);
        Retvol4 = Retvol4(2:end,:);
        T = length(Retvol4);
        resample4 = Retvol4(ceil(T*rand(T+100,1)),:);     
        Boot_ret4 = [Boot_ret4; resample4(101:end,:)];
        
        Retvol5 = z0(z0(:,2)==s,[1, 2, 3, 8]);
        Retvol5 = Retvol5(2:end,:);
        T = length(Retvol5);
        resample5 = Retvol5(ceil(T*rand(T+100,1)),:);     
        Boot_ret5 = [Boot_ret5; resample5(101:end,:)];
        
        Retvol6 = z0(z0(:,2)==s,[1, 2, 3, 9]);
        Retvol6 = Retvol6(2:end,:);
        T = length(Retvol6);
        resample6 = Retvol6(ceil(T*rand(T+100,1)),:);     
        Boot_ret6 = [Boot_ret6; resample6(101:end,:)];
        
        Retvol7 = z0(z0(:,2)==s,[1, 2, 3, 10]);
        Retvol7 = Retvol7(2:end,:);
        T = length(Retvol7);
        resample7 = Retvol7(ceil(T*rand(T+100,1)),:);     
        Boot_ret7 = [Boot_ret7; resample7(101:end,:)];
        
        Retvol8 = z0(z0(:,2)==s,[1, 2, 3, 11]);
        Retvol8 = Retvol8(2:end,:);
        T = length(Retvol8);
        resample8 = Retvol8(ceil(T*rand(T+100,1)),:);     
        Boot_ret8 = [Boot_ret8; resample8(101:end,:)];
        
        Retvol9 = z0(z0(:,2)==s,[1, 2, 3, 12]);
        Retvol9 = Retvol9(2:end,:);
        T = length(Retvol9);
        resample9 = Retvol9(ceil(T*rand(T+100,1)),:);     
        Boot_ret9 = [Boot_ret9; resample9(101:end,:)];
        
        Retvol10 = z0(z0(:,2)==s,[1, 2, 3, 13]);
        Retvol10 = Retvol10(2:end,:);
        T = length(Retvol10);
        resample10 = Retvol10(ceil(T*rand(T+100,1)),:);      
        Boot_ret10 = [Boot_ret10; resample10(101:end,:)];
        
        Retvol11 = z0(z0(:,2)==s,[1, 2, 3, 14]);
        Retvol11 = Retvol11(2:end,:);
        T = length(Retvol11);
        resample11 = Retvol11(ceil(T*rand(T+100,1)),:);      
        Boot_ret11 = [Boot_ret11; resample11(101:end,:)];
        
        Retvol12 = z0(z0(:,2)==s,[1, 2, 3, 15]);
        Retvol12 = Retvol12(2:end,:);
        T = length(Retvol12);
        resample12 = Retvol12(ceil(T*rand(T+100,1)),:);      
        Boot_ret12 = [Boot_ret12; resample12(101:end,:)];
    end
    res_i = []; res_sign_i = [];
    
    % 1 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret1(:,2) == n);                        %    1         2         3-14       
       a = Boot_ret1(tt,:);                                           %   ym      ID      xcum/vol  
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 2 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret2(:,2) == n);                       
       a = Boot_ret2(tt,:);                                          
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 3 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret3(:,2) == n);                        
       a = Boot_ret3(tt,:);                                           
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 4 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret4(:,2) == n);                        
       a = Boot_ret4(tt,:);                                          
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 5 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret5(:,2) == n);                      
       a = Boot_ret5(tt,:);                                         
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 6 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret6(:,2) == n);                     
       a = Boot_ret6(tt,:);                                         
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 7 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret7(:,2) == n);                   
       a = Boot_ret7(tt,:);                                     
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 8 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret8(:,2) == n);                
       a = Boot_ret8(tt,:);                                      
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 9 month %
    yy = []; 
    for n = Ns:Ne
       tt = find(Boot_ret9(:,2) == n);                 
       a = Boot_ret9(tt,:);                                      
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 10 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret10(:,2) == n);               
       a = Boot_ret10(tt,:);                                   
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 11 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret11(:,2) == n);              
       a = Boot_ret11(tt,:);                                   
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 12 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret12(:,2) == n);               
       a = Boot_ret12(tt,:);                                 
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
   
    beta_all(i,:) = res_i(:,1)';
    tstat_all(i,:) = res_i(:,2)';
    beta_sign_all(i,:) = res_sign_i(:,1)';
    tstat_sign_all(i,:) = res_sign_i(:,2)';
    toc
    i
end

save('E:\RESEARCH\TSMOM\Codes_new\TabA1_PairBnd2009.mat','beta_all','beta_sign_all', 'tstat_all', 'tstat_sign_all')

%% Currency %%
clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new';
addpath 'E:\Dropbox\My toolbox';
load Return.mat;

Ns = 47; Ne = 55; 
Return = Return(Return(:,1)>=198501 & Return(:,1)<=200912,:);
Return = Return(Return(:,6)>=Ns & Return(:,6)<=Ne,:);

Rs = Return(:,2);
rf = Return(:,4)+1;
exVol = Return(:,3);
Rcum = Func_GenCum(rf, Rs);
Rcumvol = Rcum(2:end,:)./exVol(1:end-1);
Rcumvol = [nan(1,12); Rcumvol];
Rcumvol = [Rcumvol, Return(:,6)];
% Drop first 12 observations in case of NaN %
for ss = Ns:Ne
  aa = find(Rcumvol(:,13)==ss);
  Rcumvol(aa(1):aa(12),:) = [];
  bb = find(Return(:,6)==ss);
  Return(bb(1):bb(12),:) = [];
end
% Align vol-scaled cumulative returns into one matrix %
Retvol1 = [nan; Rcumvol(1:end-1,1)];
Retvol2 = [nan; Rcumvol(1:end-1,2)];
Retvol3 = [nan; Rcumvol(1:end-1,3)];
Retvol4 = [nan; Rcumvol(1:end-1,4)];
Retvol5 = [nan; Rcumvol(1:end-1,5)];
Retvol6 = [nan; Rcumvol(1:end-1,6)];
Retvol7 = [nan; Rcumvol(1:end-1,7)];
Retvol8 = [nan; Rcumvol(1:end-1,8)];
Retvol9 = [nan; Rcumvol(1:end-1,9)];
Retvol10 = [nan; Rcumvol(1:end-1,10)];
Retvol11 = [nan; Rcumvol(1:end-1,11)];
Retvol12 = [nan; Rcumvol(1:end-1,12)];

Retvol_all = [Rcumvol(:,1), Retvol1, Retvol2, Retvol3, Retvol4, Retvol5, Retvol6,...
    Retvol7, Retvol8, Retvol9, Retvol10, Retvol11, Retvol12];

z0 = Return(:, [1, 6]);                                     %            1      2       3   4    5       6-17
z0 = [z0, Retvol_all];                                      % z0 =  [ym, xret, rf, id, vol, xcum/vol]

% Pair bootstrap for 1000 times %
B = 1000; 
beta_all = nan(B,12); tstat_all = nan(B,12);
beta_sign_all = nan(B,12); tstat_sign_all = nan(B,12);
for i = 1:B
    tic
    Boot_ret1 = []; Boot_ret2 = []; Boot_ret3 = []; Boot_ret4 = []; 
    Boot_ret5 = []; Boot_ret6 = []; Boot_ret7 = []; Boot_ret8 = []; 
    Boot_ret9 = []; Boot_ret10 = []; Boot_ret11 = []; Boot_ret12 = []; 
    for s = Ns:Ne
        rng(s*i);
        tY = z0(z0(:,2)==s,1);                             % z0 = [ym, xret, rf, id, vol, xcum/vol] 
        Retvol1 = z0(z0(:,2)==s,[1, 2, 3, 4]);
        Retvol1 = Retvol1(2:end,:);
        T = length(Retvol1);
        resample1 = Retvol1(ceil(T*rand(T+100,1)),:);      % randomly draw y and x together
        Boot_ret1 = [Boot_ret1; resample1(101:end,:)];
        
        Retvol2 = z0(z0(:,2)==s,[1, 2, 3, 5]);
        Retvol2 = Retvol2(2:end,:);
        T = length(Retvol2);
        resample2 = Retvol2(ceil(T*rand(T+100,1)),:);     
        Boot_ret2 = [Boot_ret2; resample2(101:end,:)];
        
        Retvol3 = z0(z0(:,2)==s,[1, 2, 3, 6]);
        Retvol3 = Retvol3(2:end,:);
        T = length(Retvol3);
        resample3 = Retvol3(ceil(T*rand(T+100,1)),:);      
        Boot_ret3 = [Boot_ret3; resample3(101:end,:)];
        
        Retvol4 = z0(z0(:,2)==s,[1, 2, 3, 7]);
        Retvol4 = Retvol4(2:end,:);
        T = length(Retvol4);
        resample4 = Retvol4(ceil(T*rand(T+100,1)),:);     
        Boot_ret4 = [Boot_ret4; resample4(101:end,:)];
        
        Retvol5 = z0(z0(:,2)==s,[1, 2, 3, 8]);
        Retvol5 = Retvol5(2:end,:);
        T = length(Retvol5);
        resample5 = Retvol5(ceil(T*rand(T+100,1)),:);     
        Boot_ret5 = [Boot_ret5; resample5(101:end,:)];
        
        Retvol6 = z0(z0(:,2)==s,[1, 2, 3, 9]);
        Retvol6 = Retvol6(2:end,:);
        T = length(Retvol6);
        resample6 = Retvol6(ceil(T*rand(T+100,1)),:);     
        Boot_ret6 = [Boot_ret6; resample6(101:end,:)];
        
        Retvol7 = z0(z0(:,2)==s,[1, 2, 3, 10]);
        Retvol7 = Retvol7(2:end,:);
        T = length(Retvol7);
        resample7 = Retvol7(ceil(T*rand(T+100,1)),:);     
        Boot_ret7 = [Boot_ret7; resample7(101:end,:)];
        
        Retvol8 = z0(z0(:,2)==s,[1, 2, 3, 11]);
        Retvol8 = Retvol8(2:end,:);
        T = length(Retvol8);
        resample8 = Retvol8(ceil(T*rand(T+100,1)),:);     
        Boot_ret8 = [Boot_ret8; resample8(101:end,:)];
        
        Retvol9 = z0(z0(:,2)==s,[1, 2, 3, 12]);
        Retvol9 = Retvol9(2:end,:);
        T = length(Retvol9);
        resample9 = Retvol9(ceil(T*rand(T+100,1)),:);     
        Boot_ret9 = [Boot_ret9; resample9(101:end,:)];
        
        Retvol10 = z0(z0(:,2)==s,[1, 2, 3, 13]);
        Retvol10 = Retvol10(2:end,:);
        T = length(Retvol10);
        resample10 = Retvol10(ceil(T*rand(T+100,1)),:);      
        Boot_ret10 = [Boot_ret10; resample10(101:end,:)];
        
        Retvol11 = z0(z0(:,2)==s,[1, 2, 3, 14]);
        Retvol11 = Retvol11(2:end,:);
        T = length(Retvol11);
        resample11 = Retvol11(ceil(T*rand(T+100,1)),:);      
        Boot_ret11 = [Boot_ret11; resample11(101:end,:)];
        
        Retvol12 = z0(z0(:,2)==s,[1, 2, 3, 15]);
        Retvol12 = Retvol12(2:end,:);
        T = length(Retvol12);
        resample12 = Retvol12(ceil(T*rand(T+100,1)),:);      
        Boot_ret12 = [Boot_ret12; resample12(101:end,:)];
    end
    res_i = []; res_sign_i = [];
    
    % 1 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret1(:,2) == n);                        %    1         2         3-14       
       a = Boot_ret1(tt,:);                                           %   ym      ID      xcum/vol  
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 2 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret2(:,2) == n);                       
       a = Boot_ret2(tt,:);                                          
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 3 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret3(:,2) == n);                        
       a = Boot_ret3(tt,:);                                           
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 4 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret4(:,2) == n);                        
       a = Boot_ret4(tt,:);                                          
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 5 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret5(:,2) == n);                      
       a = Boot_ret5(tt,:);                                         
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 6 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret6(:,2) == n);                     
       a = Boot_ret6(tt,:);                                         
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 7 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret7(:,2) == n);                   
       a = Boot_ret7(tt,:);                                     
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 8 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret8(:,2) == n);                
       a = Boot_ret8(tt,:);                                      
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 9 month %
    yy = []; 
    for n = Ns:Ne
       tt = find(Boot_ret9(:,2) == n);                 
       a = Boot_ret9(tt,:);                                      
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 10 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret10(:,2) == n);               
       a = Boot_ret10(tt,:);                                   
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 11 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret11(:,2) == n);              
       a = Boot_ret11(tt,:);                                   
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
    
    % 12 month %
    yy = []; 
    for n = Ns:Ne 
       tt = find(Boot_ret12(:,2) == n);               
       a = Boot_ret12(tt,:);                                 
       yy = [yy; a(1:end,3), a(1:end,4), a(1:end,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    bsign = clusterreg(yy(:,1), [sign(yy(:,2)), ones(size(yy(:,2)))], yy(:,3));
    res_sign_i = [res_sign_i; bsign(1, [1, 3]), bsign(2, [1, 3])];
   
    beta_all(i,:) = res_i(:,1)';
    tstat_all(i,:) = res_i(:,2)';
    beta_sign_all(i,:) = res_sign_i(:,1)';
    tstat_sign_all(i,:) = res_sign_i(:,2)';
    toc
    i
end

save('E:\RESEARCH\TSMOM\Codes_new\TabA1_PairCur2009.mat','beta_all','beta_sign_all', 'tstat_all', 'tstat_sign_all')