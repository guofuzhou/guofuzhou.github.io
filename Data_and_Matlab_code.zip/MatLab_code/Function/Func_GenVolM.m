function [Vol] = Func_GenVolM(XR)
% XR: T by 1 vector of monthly excess return
T = length(XR);
Vol = nan(T,1);
for t = 12:T
    Vol(t) =  sqrt(pi/2)*sqrt(1/12)*sum(abs(XR(t-11:t)));
end
