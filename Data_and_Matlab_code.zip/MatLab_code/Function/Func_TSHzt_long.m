function[tsh_long, anntsh_long, Ret_tsh_long] = Func_TSHzt_long(Ret,N, tdate)
         
T = length(tdate);
Xall = []; Xmean_all = []; Rf_all = [];

for s = 1:N
    X_s = nan*tdate; 
    Xmean_s = nan*tdate; 
    Rf_s = nan*tdate;
    
    tX = Ret(Ret(:,6)==s,1);
    X = Ret(Ret(:,6)==s,2);
    Rf = Ret(Ret(:,6)==s,4);
    Xmean = Ret(Ret(:,6)==s,8);
    
    % Date alignment %
    a = find(tdate(:)==tX(1));
    b = find(tdate(:)==tX(end));
    
    % Single out the positions %
    X_s(a:b) = X(1:end);
    Xmean_s(a:b) = Xmean(1:end);
    Rf_s(a:b) = Rf(1:end);
    
    % Put them together into one matrix %
    Xall = [Xall, X_s];
    Xmean_all = [Xmean_all, Xmean_s];
    Rf_all = [Rf_all, Rf_s];
end

Ret_tsh_long = []; 
for s = 1:N
    Ret_tsh_s = nan(T,1); 
    for t = 2:T
        Xmean_all_t = Xmean_all(t-1,:)';
        Xmean_all_t = Xmean_all_t(~isnan(Xmean_all_t));
        
        pp = find(Xmean_all_t>=0); 
        if Xmean_all(t-1,s)>=0
          Ret_tsh_s(t) = 1/length(pp)*Xall(t,s); 
        end
    end
    Ret_tsh_long = [Ret_tsh_long, Ret_tsh_s];
end

% Generate aggregate time series return %
tsh_long = []; 
for t = 2:T
    Ret_tsh_t = Ret_tsh_long(t,:)';
    Ret_tsh_t = Ret_tsh_t(~isnan(Ret_tsh_t));
    aRet = sum(Ret_tsh_t);
    tsh_long = [tsh_long;aRet];  
end

% Generate annualized return %
anntsh_long = mean(tsh_long)*1200;

% Generate annualized sharpe ratio %
sharpe_tsh_long = mean(tsh_long)/std(tsh_long)*sqrt(12);
end
