function[tsh_short, anntsh_short, Ret_tsh_short] = Func_TSHvol_short(Ret,N, tdate,cons)
         
T = length(tdate);
Xall = []; sigma_all = []; Xmean_all = []; Rf_all = [];

for s = 1:N
    X_s = nan*tdate; 
    Xmean_s = nan*tdate; 
    Rf_s = nan*tdate;
    sigma_s = nan*tdate;
    
    tX = Ret(Ret(:,6)==s,1);
    X = Ret(Ret(:,6)==s,2);
    sigma = Ret(Ret(:,6)==s,3);
    Rf = Ret(Ret(:,6)==s,4);
    Xmean = Ret(Ret(:,6)==s,8);
    
    % Date alignment %
    a = find(tdate(:)==tX(1));
    b = find(tdate(:)==tX(end));
    
    % Single out the positions %
    X_s(a:b) = X(1:end);
    sigma_s(a:b) = sigma(1:end);
    Rf_s(a:b) = Rf(1:end);
    Xmean_s(a:b) = Xmean(1:end);
    
    % Put them together into one matrix %
    Xall = [Xall, X_s];
    sigma_all = [sigma_all, sigma_s];
    Rf_all = [Rf_all, Rf_s];
    Xmean_all = [Xmean_all, Xmean_s];
end

Ret_tsh_short = []; 
for s = 1:N
    Ret_tsh_s = nan(T,1); 
    for t = 2:T
       Xmean_all_t = Xmean_all(t-1,:)';
       Xmean_all_t = Xmean_all_t(~isnan(Xmean_all_t));
       Nw = length(Xmean_all_t);
       if Xmean_all(t-1,s)<0
         Ret_tsh_s(t) = 1/Nw*cons/sigma_all(t-1,s)*Xall(t,s); 
       end
    end
    Ret_tsh_short = [Ret_tsh_short, Ret_tsh_s];
end

% Generate aggregate time series return %
tsh_short = []; 
for t = 2:T
    Ret_tsh_t = Ret_tsh_short(t,:)';
    Ret_tsh_t = Ret_tsh_t(~isnan(Ret_tsh_t));
    aRet = sum(Ret_tsh_t);
    tsh_short = [tsh_short;aRet];  
end

% Generate annualized return %
anntsh_short = mean(tsh_short)*1200;

% Generate annualized sharpe ratio %
sharpe_tsh_short = mean(tsh_short)/std(tsh_short)*sqrt(12);
end
