function [ExVol] = Func_GenVolD(XR)
% XR: T by 1 vector of daily excess return
delta = 60/61;
exsig = nan(length(XR),1);
xbar = nan(length(XR),1);
for t = 2:length(XR)
    sigmat = nan(length(XR),1);
    xbart = nan(length(XR),1);
    for n = 1:t
        xbart(n) = (1-delta)*delta^(n-1)*XR(t-n+1);      % Compute exponentially weighted average return
    end
    xbar(t) = sum(xbart(1:t));
    for i = 1:t-1
        sigmat(i) = (1-delta)*delta^(i-1)*(XR(t-i) - xbar(t))^2;
    end
    exsig(t) = 261*sum(sigmat(1:t-1));
end
ExVol = sqrt(exsig);
end