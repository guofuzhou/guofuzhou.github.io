function[tsm_short, anntsm_short, Ret_tsm_short] = Func_TSMzt_short(Ret, N, tdate)
          
T = length(tdate);
Xall = []; Xcum_all = []; Rf_all = [];

for s = 1:N
    X_s = nan*tdate; 
    Xcum_s = nan*tdate; 
    Rf_s = nan*tdate;
    
    tX = Ret(Ret(:,6)==s,1);
    X = Ret(Ret(:,6)==s,2);
    Rf = Ret(Ret(:,6)==s,4);
    Xcum = Ret(Ret(:,6)==s,7);
    
    % Date alignment %
    a = find(tdate(:)==tX(1));
    b = find(tdate(:)==tX(end));
    
    % Single out the positions %
    X_s(a:b) = X(1:end);
    Xcum_s(a:b) = Xcum(1:end);
    Rf_s(a:b) = Rf(1:end);
    
    % Put them together into one matrix %
    Xall = [Xall, X_s];
    Xcum_all = [Xcum_all, Xcum_s];
    Rf_all = [Rf_all, Rf_s];
end

Ret_tsm_short = [];     
for s = 1:N
    Ret_tsm_s = nan(T,1); 
    for t = 2:T
       Xcum_all_t = Xcum_all(t-1,:)';
       Xcum_all_t = Xcum_all_t(~isnan(Xcum_all_t));
       nn = find(Xcum_all(t-1,:)<0);
       if Xcum_all(t-1,s)<0 
         Ret_tsm_s(t) = 1/length(nn)*Xall(t,s);
       end
    end
    Ret_tsm_short = [Ret_tsm_short, Ret_tsm_s];
    end
    
% Generate aggregate time series return %
tsm_short = []; 
for t = 2:T
    Ret_tsm_t = Ret_tsm_short(t,:)';
    Ret_tsm_t = Ret_tsm_t(~isnan(Ret_tsm_t));
    aRet = sum(Ret_tsm_t);
    tsm_short = [tsm_short;aRet];  
end

% Generate annualized return %
% annual_short = mean(aRet_short(~isnan(aRet_short),:))*1200;
anntsm_short = mean(tsm_short)*1200;

% Generate annualized sharpe ratio %
sharpe_tsm_short = mean(tsm_short)/std(tsm_short)*sqrt(12);
end
