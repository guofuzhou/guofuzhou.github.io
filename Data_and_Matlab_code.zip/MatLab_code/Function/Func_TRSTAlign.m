function[Xall, Xcum_all] = Func_TRSTAlign(Ret, N, tdate)

T = length(tdate);
Xall = []; Xcum_all = []; Rf_all = [];

for s = 1:N
    X_s = nan*tdate; 
    Xcum_s = nan*tdate; 
    Rf_s = nan*tdate;
    
    tX = Ret(Ret(:,6)==s,1);
    X = Ret(Ret(:,6)==s,2);
    Xcum = Ret(Ret(:,6)==s,7);
    Rf = Ret(Ret(:,6)==s,4);
    
    % Date alignment %
    a = find(tdate(:)==tX(1));
    b = find(tdate(:)==tX(end));
    
    % Single out the positions %
    X_s(a:b) = X(1:end);
    Xcum_s(a:b) = Xcum(1:end);
    Rf_s(a:b) = Rf(1:end);
    
    % Put them together into one matrix %
    Xall = [Xall, X_s];
    Xcum_all = [Xcum_all, Xcum_s];
    Rf_all = [Rf_all, Rf_s];
end

end
