function[aRet_tsm, annual_tsm, Ret_tsm] = Func_TSMTab8(Ret, N, tdate)
             
T = length(tdate);
Xall = []; sigma_all = []; Xcum_all = []; Rf_all = [];

for s = 1:N
    X_s = nan*tdate; 
    sigma_s = nan*tdate; 
    Xcum_s = nan*tdate; 
    Rf_s = nan*tdate;tX = Ret(Ret(:,6)==s,1);
    X = Ret(Ret(:,6)==s,2);
    sigma = Ret(Ret(:,6)==s,3);
    Rf = Ret(Ret(:,6)==s,4);
    Xcum = Ret(Ret(:,6)==s,7);
    
    % Date alignment %
    a = find(tdate(:)==tX(1));
    b = find(tdate(:)==tX(end));
    
    % Single out the positions %
    X_s(a:b) = X(1:end);
    sigma_s(a:b) = sigma(1:end);
    Xcum_s(a:b) = Xcum(1:end);
    Rf_s(a:b) = Rf(1:end);
    
    % Put them together into one matrix %
    Xall = [Xall, X_s];
    sigma_all = [sigma_all, sigma_s];
    Xcum_all = [Xcum_all, Xcum_s];
    Rf_all = [Rf_all, Rf_s];
end

% Calculate strategy returns for each asset %
Ret_tsm= []; 
for s = 1:N
    Ret_tsm_s = nan(T,1);  
    for t = 2:T
        Ret_tsm_s(t) = sign(Xcum_all(t-1,s))*Xall(t,s); 
    end
        Ret_tsm = [Ret_tsm, Ret_tsm_s];
end
    
% Generate aggregate time series return %
aRet_tsm = []; 
for t = 2:T
    Ret_tsm_t = Ret_tsm(t,:)';
    Ret_tsm_t = Ret_tsm_t(~isnan(Ret_tsm_t),:);
    aRet = mean(Ret_tsm_t);
    aRet_tsm = [aRet_tsm;aRet];  
end

% Generate annualized return %
annual_tsm = mean(aRet_tsm(~isnan(aRet_tsm),:))*1200;

% Generate annualized sharpe ratio %
sharpe_tsm = mean(aRet_tsm)/std(aRet_tsm)*sqrt(12);
end
