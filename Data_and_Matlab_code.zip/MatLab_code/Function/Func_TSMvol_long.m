function[tsm_long, anntsm_long, Ret_tsm_long] = Func_TSMvol_long(Ret, N, tdate, cons)
             
T = length(tdate);
Xall = []; sigma_all = []; Xcum_all = []; Rf_all = [];

for s = 1:N
    X_s = nan*tdate; 
    sigma_s = nan*tdate; 
    Xcum_s = nan*tdate; 
    Rf_s = nan*tdate;
    
    tX = Ret(Ret(:,6)==s,1);
    X = Ret(Ret(:,6)==s,2);
    sigma = Ret(Ret(:,6)==s,3);
    Rf = Ret(Ret(:,6)==s,4);
    Xcum = Ret(Ret(:,6)==s,7);
    
    % Date alignment %
    a = find(tdate(:)==tX(1));
    b = find(tdate(:)==tX(end));
    
    % Single out the positions %
    X_s(a:b) = X(1:end);
    sigma_s(a:b) = sigma(1:end);
    Xcum_s(a:b) = Xcum(1:end);
    Rf_s(a:b) = Rf(1:end);
    
    % Put them together into one matrix %
    Xall = [Xall, X_s];
    sigma_all = [sigma_all, sigma_s];
    Xcum_all = [Xcum_all, Xcum_s];
    Rf_all = [Rf_all, Rf_s];
end

Ret_tsm_long= []; 
for s = 1:N
    Ret_tsm_s = nan(T,1);  
    for t = 2:T
        Xcum_all_t = Xcum_all(t-1,:)';
        Xcum_all_t = Xcum_all_t(~isnan(Xcum_all_t));
        Nw = length(Xcum_all_t);
        if Xcum_all(t-1,s)>=0
            Ret_tsm_s(t) = 1/Nw*cons/sigma_all(t-1,s)*Xall(t,s); 
        end
    end
        Ret_tsm_long = [Ret_tsm_long, Ret_tsm_s];
end
    
% Generate aggregate time series return %
tsm_long = []; 
for t = 2:T
    Ret_tsm_t = Ret_tsm_long(t,:)';
    Ret_tsm_t = Ret_tsm_t(~isnan(Ret_tsm_t));
    aRet = sum(Ret_tsm_t);
    tsm_long = [tsm_long;aRet];  
end

% Generate annualized return %
% annual_long = mean(aRet_long(~isnan(aRet_long),:))*1200;
anntsm_long = mean(tsm_long)*1200;
% Generate annualized sharpe ratio %
sharpe_tsm_long = mean(tsm_long)/std(tsm_long)*sqrt(12);
end
