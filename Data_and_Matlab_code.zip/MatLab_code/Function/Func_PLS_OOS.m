function [OS] = Func_PLS_OOS(Ret_ac, Ret_x, tdate, stdate, zsc2, cons2, ma2, lg0ret)
% tdate: longest time period (1985 - 2015)
% stdate: out-of-sample starting time
% cons: 0=no intercept in the 2nd step, 1=with intercept 
% ma: 0=no moving average in the 3rd step, 12=12-month moving average
% zsc2: z = normalization in 1st step, otherwise no zscore (out-of-sample)
% lg0ret: 1 = restrict expected return to be nonnegative, 0 = no contraint

OS = []; 
for s = min(Ret_ac(:,6)):max(Ret_ac(:,6))
    Ret_s = Ret_ac(Ret_ac(:,6)==s,:);
    Y = Ret_s(:,2);
    tY = Ret_s(:,1);
    bb = find(tY(:)==stdate);
    yhat = nan*Y; 
    ybar = nan*Y;
 
for j = bb+1:length(tY)
   Pi_s = [];
   RetN = [];
   for i = min(Ret_x(:,6)):max(Ret_x(:,6))
     x_i  = nan*tdate;                                        %% Construct a big matrix
     Ret_i = Ret_x(Ret_x(:,6)==i,:);
     X = Ret_i(:,7);     
     tX = Ret_i(:,1);
                                                                                    
    if tY(1)<=tX(1)  && tY(j-1)<tX(end)  && tY(j-1)>tX(1)              
       tt = find(tX(:)==tY(j-1));
       td = find(tY(:)==tX(1));
        if zsc2 == 'z'
           X_oos = zscore(X(1:tt));
           Y_oos = Y(1:j-1)-mean(Y(1:j-1));
       else
           X_oos = X(1:tt);
           Y_oos = Y(1:j-1);
       end
       rh = Y_oos(td+1:j-1);
       lh = X_oos(1:tt-1);     
       Pi_s = [Pi_s, olsnw(lh,rh)];
          
       St = find(tdate(:)==tX(1));                                    
       Ed = find(tdate(:)==tX(tt));
       x_i(St:Ed) = X_oos(1:tt);                      
       RetN = [RetN, x_i(1:Ed)];  
          
   elseif tY(1)>tX(1) && tY(j-1)<tX(end)                                
         tb = find(tX(:)==tY(j-1));
         ta = find(tX(:)==tY(1));
         if zsc2 == 'z'
           X_oos = zscore(X(1:tb));
           Y_oos = Y(1:j-1)-mean(Y(1:j-1));
         else
            X_oos = X(1:tb);
            Y_oos = Y(1:j-1);
         end
         rh = Y_oos(1:j-1);
         lh = X_oos(ta-1:tb-1);
         Pi_s = [Pi_s, olsnw(lh,rh)];
            
         St = find(tdate(:)==tX(1));
         Ed = find(tdate(:)==tX(tb));
         x_i(St:Ed)= X_oos(1:tb);
         RetN = [RetN, x_i(1:Ed)];
    end
  end
  dq = nan(j-1,1);
    if cons2 == 0
    for t = 1:j-1
      RetN_t = RetN(t,:)';
      aa = find(~isnan(RetN_t));
      Rt = RetN_t(~isnan(RetN_t),:);                              
      Pi_sT = Pi_s(2,:)';                                              
      rhv = Pi_sT(aa);
      bv = olsnw(Rt,rhv,0);
      dq(t,1) = bv(1);
    end
    else
    for t = 1:j-1
       RetN_t = RetN(t,:)';
       aa = find(~isnan(RetN_t));
       Rt = RetN_t(~isnan(RetN_t),:);                              
       Pi_sT = Pi_s(2,:)';                                              
       rhv = Pi_sT(aa);
       bv = olsnw(Rt, rhv);
       dq(t,1) = bv(2);
    end
    end
    if ma2 == 0
       R = Y(2:j-1);
       E = [ones(size(dq(1:j-2))), dq(1:j-2)];  %% no moving average
       beta_oos = olsgmm(R,E,12,1);
       yhat(j) = [1, dq(j-1)]*beta_oos;
       ybar(j)= mean(Y(1:j-1));  
    else 
       R = Y(13:j-1);                                                                       
       ma_dq = tsmovavg(dq, 'm', 12, 1);                 %% 12-month moving average                
       E = [ones(size(ma_dq(12:j-2))),  ma_dq(12:j-2)]; % normalize predictor
       beta_oos = olsgmm(R,E,12,1);
       yhat(j) = [1, ma_dq(j-1)]*beta_oos;
       ybar(j)= mean(Y(1:j-1));  
    end
end
yos = Y(bb+1:end);
ybar = ybar(bb+1:end);
% yhat = yhat(bb+1:end);
% yhat = max(0,yhat);
yhat = lg0ret*max(0,yhat(bb+1:end)) + (1-lg0ret)*yhat(bb+1:end);
OS_s = R2oostest(yos, ybar, yhat, 12);
OS = [OS; OS_s(1:2)];
s
OS_s(1:2)
end
end