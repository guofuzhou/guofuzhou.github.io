%% Plot Figure 4 %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new\Mat';
addpath 'E:\Dropbox\My toolbox';
load Fig4_TstatAll.mat;
load Fig4_TstatCom.mat;
load Fig4_TstatEqt.mat;
load Fig4_TstatBnd.mat;
load Fig4_TstatCur.mat;

figure (1);
R2l = -3; R2h = 6; H = 60;
subplot(3,2,1);
bar(1:H,res(:,2));
axis([0 H+1 R2l R2h]);
h=ylabel('$t$-stat','FontSize',8)
h0 = title('Panel A: All asset classes','fontweight','normal','FontSize',8)
h2 = xlabel('Month lag','fontweight','normal','FontSize', 8)
set([h h0 h2],'Interpreter','latex');
set(gca,'ygrid','on') 
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',8)

R2l = -3; R2h = 6; H = 60;
subplot(3,2,2);
bar(1:H,res_sign(:,2));
axis([0 H+1 R2l R2h]);
h=ylabel('$t$-stat','FontSize',8)
h0 = title('Panel B: Signs of all asset classes','fontweight','normal','FontSize',8)
h2 = xlabel('Month lag','fontweight','normal','FontSize', 8)
set([h h0 h2],'Interpreter','latex');
set(gca,'ygrid','on')
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',8)

R2l = -2; R2h = 4; H = 60;
subplot(3,2,3);
bar(1:H,ressign_com(:,2));
axis([0 H+1 R2l R2h]);
h=ylabel('$t$-stat','FontSize',8)
h0 = title('Panel C: Commodity futures','fontweight','normal','FontSize',8)
h2 = xlabel('Month lag','fontweight','normal','FontSize', 8)
set([h h0 h2],'Interpreter','latex');
set(gca,'ygrid','on')
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',8)

R2l = -3; R2h = 3; H = 60;
subplot(3,2,4);
bar(1:H,ressign_eqt(:,2));
axis([0 H+1 R2l R2h]);
h=ylabel('$t$-stat','FontSize',8)
h0 = title('Panel D: Equity index futures','fontweight','normal','FontSize',8)
h2 = xlabel('Month lag','fontweight','normal','FontSize', 8)
set([h h0 h2],'Interpreter','latex');
set(gca,'ygrid','on')
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',8)

R2l = -2; R2h = 4; H = 60;
subplot(3,2,5);
bar(1:H,ressign_bnd(:,2));
axis([0 H+1 R2l R2h]);
h=ylabel('$t$-stat','FontSize',8)
h0 = title('Panel E: Government bond futures','fontweight','normal','FontSize',8)
h1 = xlabel('Month lag','fontweight','normal','FontSize', 8)
set([h h0 h1],'Interpreter','latex');
set(gca,'ygrid','on')
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',8)

R2l = -3; R2h = 4; H = 60;
subplot(3,2,6);
bar(1:H,ressign_cur(:,2));
axis([0 H+1 R2l R2h]);
h=ylabel('$t$-stat','FontSize',8)
h0 = title('Panel F: Currency forwards','fontweight','normal','FontSize',8)
h1 = xlabel('Month lag','fontweight','normal','FontSize', 8)
set([h h0 h1],'Interpreter','latex');
set(gca,'ygrid','on')
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',8)

 save2pdf('E:\RESEARCH\TSMOM\Codes_new\Fig4_PoolTstat',gcf,600)