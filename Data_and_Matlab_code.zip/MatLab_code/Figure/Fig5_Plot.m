%% Plot Figure 5 %%

clear;clc
clf;
addpath 'E:\RESEARCH\TSMOM\Codes_new\Mat';
addpath 'E:\Dropbox\My toolbox';

load Fig5_PoolR2vol.mat;
load Fig5_PoolR2.mat;
N = 55;
Commodity_oos = R2oos(1:24,1);
Commodity_index = 1;
Commodity_oos = [Commodity_oos, repmat(Commodity_index,length(Commodity_oos),1)];
Commodity_vol = R2oosvol(1:24,1);
Commodity_vol = [Commodity_vol, repmat(Commodity_index,length(Commodity_vol),1)];

Equity_oos = R2oos(25:33,1);
Equity_index = 2;
Equity_oos = [Equity_oos, repmat(Equity_index,length(Equity_oos),1)];
Equity_vol = R2oosvol(25:33,1);
Equity_vol = [Equity_vol, repmat(Equity_index,length(Equity_vol),1)];

Bond_oos = R2oos(34:46,1);
Bond_index = 3;
Bond_oos = [Bond_oos, repmat(Bond_index,length(Bond_oos),1)];
Bond_vol = R2oosvol(34:46,1);
Bond_vol = [Bond_vol, repmat(Bond_index,length(Bond_vol),1)];

Currency_oos = R2oos(47:55,1);
Currency_index = 4;
Currency_oos = [Currency_oos, repmat(Currency_index,length(Currency_oos),1)];
Currency_vol = R2oosvol(47:55,1);
Currency_vol = [Currency_vol, repmat(Currency_index,length(Currency_vol),1)];

data_oos = [Commodity_oos; Equity_oos; Bond_oos; Currency_oos];
data_vol = [Commodity_vol; Equity_vol; Bond_vol; Currency_vol];

H_oos = data_oos(:,1);
H_vol = data_vol(:,1);

N_oos = numel(H_oos);
N_vol = numel(H_vol);

figure (1);
R2l = -1; R2h = 6;
subplot(2,1,1);

for i = 1:N_vol
    h_vol = bar(i,H_vol(i));
    if i <= N_vol 
       hold on 
    end
    if data_vol(i,2) == 1
       col_vol = rgb('DarkSlateGray');
    elseif data_vol(i,2) == 2
       col_vol = rgb('Maroon');
    elseif data_vol(i,2) == 3
       col_vol = rgb('DarkBlue');
    else
       col_vol = rgb('SaddleBrown');
    end 
    set(h_vol,'FaceColor',col_vol)
end

axis([0 N+1 R2l R2h]);
h=ylabel('$R^2_{OS}$','FontSize', 8)
h1=text('Position',[5 5],'string','average $R^2_{OS} = -0.06\%$','FontSize', 8)
h2=text('Position',[5 4.3],'string','\#(significant $R^2_{OS}) = 11$','FontSize', 8)
h0 = title('Panel A: $R^2_{OS}$ with volatility scaling in pooled regression','fontweight','normal','FontSize', 8)
h3 = xlabel('Asset','fontweight','normal','FontSize', 8)
set([h h0 h1 h2 h3],'Interpreter','latex');
set(gca,'ygrid','on') 
set(gca,'XTick',[1 10 20 30 40 50])

hold on

R2l = -1; R2h = 6;
subplot(2,1,2);

for i = 1:N_oos
    h_oos = bar(i,H_oos(i));
    if i <= N_oos 
       hold on 
    end
    if data_oos(i,2) == 1
       col_oos = rgb('DarkSlateGray');
    elseif data_oos(i,2) == 2
       col_oos = rgb('Maroon');
    elseif data_oos(i,2) == 3
       col_oos = rgb('DarkBlue');
    else
       col_oos = rgb('SaddleBrown');
    end 
    set(h_oos,'FaceColor',col_oos)
end

axis([0 N+1 R2l R2h]);
h=ylabel('$R^2_{OS}$','FontSize', 8)
h1=text('Position',[5 5],'string','average $R^2_{OS} = -0.35\%$','FontSize', 8)
h2=text('Position',[5 4.3],'string','\#(significant $R^2_{OS}) = 10$','FontSize', 8)
h0 = title('Panel B: $R^2_{OS}$ without volatility scaling in pooled regression','fontweight','normal','FontSize', 8)
h3 = xlabel('Asset','fontweight','normal','FontSize', 8)
set([h h0 h1 h2 h3],'Interpreter','latex');
set(gca,'ygrid','on') 
set(gca,'XTick',[1 10 20 30 40 50])

save2pdf('E:\RESEARCH\TSMOM\Codes_new\Fig5_PoolR2oos',gcf,600)




