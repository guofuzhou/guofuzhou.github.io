%% Plot Figure 3 %%

clear;clc
clf;
addpath 'E:\RESEARCH\TSMOM\Codes_new\Mat';
addpath 'E:\Dropbox\My toolbox';

load Fig3_R2PLS1.mat;
res_ins1 = R2_ins_oos(:,3);
res_oos1 = R2_ins_oos(:,4);
load Fig3_R2PLS3.mat;
res_ins3 = R2_ins_oos(:,3);
res_oos3 = R2_ins_oos(:,4);
load Fig3_R2PLS6.mat;
res_ins6 = R2_ins_oos(:,3);
res_oos6 = R2_ins_oos(:,4);
load Fig3_R2PLS12.mat;
res_ins12 = R2_ins_oos(:,3);
res_oos12 = R2_ins_oos(:,4);

N = 55;
%% 1 month cumulative %%
Commodity_ins1 = res_ins1(1:24,:);
Commodity_index = 1;
Commodity_ins1 = [Commodity_ins1, repmat(Commodity_index,length(Commodity_ins1),1)];
Commodity_oos1 = res_oos1(1:24,:);
Commodity_oos1 = [Commodity_oos1, repmat(Commodity_index,length(Commodity_oos1),1)];

Equity_ins1 = res_ins1(25:33,:);
Equity_index = 2;
Equity_ins1 = [Equity_ins1, repmat(Equity_index,length(Equity_ins1),1)];
Equity_oos1 = res_oos1(25:33,:);
Equity_oos1 = [Equity_oos1, repmat(Equity_index,length(Equity_oos1),1)];

Bond_ins1 = res_ins1(34:46,:);
Bond_index = 3;
Bond_ins1 = [Bond_ins1, repmat(Bond_index,length(Bond_ins1),1)];
Bond_oos1 = res_oos1(34:46,:);
Bond_oos1 = [Bond_oos1, repmat(Bond_index,length(Bond_oos1),1)];

Currency_ins1 = res_ins1(47:55,:);
Currency_index = 4;
Currency_ins1 = [Currency_ins1, repmat(Currency_index,length(Currency_ins1),1)];
Currency_oos1 = res_oos1(47:55,:);
Currency_oos1 = [Currency_oos1, repmat(Currency_index,length(Currency_oos1),1)];

data_ins1 = [Commodity_ins1; Equity_ins1; Bond_ins1; Currency_ins1];
data_oos1 = [Commodity_oos1; Equity_oos1; Bond_oos1; Currency_oos1];

H_ins1 = data_ins1(:,1);
H_oos1 = data_oos1(:,1);
N_ins1 = numel(H_ins1);
N_oos1 = numel(H_oos1);

%% 3 month cumulative %%
Commodity_ins3 = res_ins3(1:24,:);
Commodity_index = 1;
Commodity_ins3 = [Commodity_ins3, repmat(Commodity_index,length(Commodity_ins3),1)];
Commodity_oos3 = res_oos3(1:24,:);
Commodity_oos3 = [Commodity_oos3, repmat(Commodity_index,length(Commodity_oos3),1)];

Equity_ins3 = res_ins3(25:33,:);
Equity_index = 2;
Equity_ins3 = [Equity_ins3, repmat(Equity_index,length(Equity_ins3),1)];
Equity_oos3 = res_oos3(25:33,:);
Equity_oos3 = [Equity_oos3, repmat(Equity_index,length(Equity_oos3),1)];

Bond_ins3 = res_ins3(34:46,:);
Bond_index = 3;
Bond_ins3 = [Bond_ins3, repmat(Bond_index,length(Bond_ins3),1)];
Bond_oos3 = res_oos3(34:46,:);
Bond_oos3 = [Bond_oos3, repmat(Bond_index,length(Bond_oos3),1)];

Currency_ins3 = res_ins3(47:55,:);
Currency_index = 4;
Currency_ins3 = [Currency_ins3, repmat(Currency_index,length(Currency_ins3),1)];
Currency_oos3 = res_oos3(47:55,:);
Currency_oos3 = [Currency_oos3, repmat(Currency_index,length(Currency_oos3),1)];

data_ins3 = [Commodity_ins3; Equity_ins3; Bond_ins3; Currency_ins3];
data_oos3 = [Commodity_oos3; Equity_oos3; Bond_oos3; Currency_oos3];

H_ins3 = data_ins3(:,1);
H_oos3 = data_oos3(:,1);
N_ins3 = numel(H_ins3);
N_oos3 = numel(H_oos3);

%% 6 month cumulative %%
Commodity_ins6 = res_ins6(1:24,:);
Commodity_index = 1;
Commodity_ins6 = [Commodity_ins6, repmat(Commodity_index,length(Commodity_ins6),1)];
Commodity_oos6 = res_oos6(1:24,:);
Commodity_oos6 = [Commodity_oos6, repmat(Commodity_index,length(Commodity_oos6),1)];

Equity_ins6 = res_ins6(25:33,:);
Equity_index = 2;
Equity_ins6 = [Equity_ins6, repmat(Equity_index,length(Equity_ins6),1)];
Equity_oos6 = res_oos6(25:33,:);
Equity_oos6 = [Equity_oos6, repmat(Equity_index,length(Equity_oos6),1)];

Bond_ins6 = res_ins6(34:46,:);
Bond_index = 3;
Bond_ins6 = [Bond_ins6, repmat(Bond_index,length(Bond_ins6),1)];
Bond_oos6 = res_oos6(34:46,:);
Bond_oos6 = [Bond_oos6, repmat(Bond_index,length(Bond_oos6),1)];

Currency_ins6 = res_ins6(47:55,:);
Currency_index = 4;
Currency_ins6 = [Currency_ins6, repmat(Currency_index,length(Currency_ins6),1)];
Currency_oos6 = res_oos6(47:55,:);
Currency_oos6 = [Currency_oos6, repmat(Currency_index,length(Currency_oos6),1)];

data_ins6 = [Commodity_ins6; Equity_ins6; Bond_ins6; Currency_ins6];
data_oos6 = [Commodity_oos6; Equity_oos6; Bond_oos6; Currency_oos6];

H_ins6 = data_ins6(:,1);
H_oos6 = data_oos6(:,1);
N_ins6 = numel(H_ins6);
N_oos6 = numel(H_oos6);

%% 12 month cumulative %%
Commodity_ins12 = res_ins12(1:24,:);
Commodity_index = 1;
Commodity_ins12 = [Commodity_ins12, repmat(Commodity_index,length(Commodity_ins12),1)];
Commodity_oos12 = res_oos12(1:24,:);
Commodity_oos12 = [Commodity_oos12, repmat(Commodity_index,length(Commodity_oos12),1)];

Equity_ins12 = res_ins12(25:33,:);
Equity_index = 2;
Equity_ins12 = [Equity_ins12, repmat(Equity_index,length(Equity_ins12),1)];
Equity_oos12 = res_oos12(25:33,:);
Equity_oos12 = [Equity_oos12, repmat(Equity_index,length(Equity_oos12),1)];

Bond_ins12 = res_ins12(34:46,:);
Bond_index = 3;
Bond_ins12 = [Bond_ins12, repmat(Bond_index,length(Bond_ins12),1)];
Bond_oos12 = res_oos12(34:46,:);
Bond_oos12 = [Bond_oos12, repmat(Bond_index,length(Bond_oos12),1)];

Currency_ins12 = res_ins12(47:55,:);
Currency_index = 4;
Currency_ins12 = [Currency_ins12, repmat(Currency_index,length(Currency_ins12),1)];
Currency_oos12 = res_oos12(47:55,:);
Currency_oos12 = [Currency_oos12, repmat(Currency_index,length(Currency_oos12),1)];

data_ins12 = [Commodity_ins12; Equity_ins12; Bond_ins12; Currency_ins12];
data_oos12 = [Commodity_oos12; Equity_oos12; Bond_oos12; Currency_oos12];

H_ins12 = data_ins12(:,1);
H_oos12 = data_oos12(:,1);
N_ins12 = numel(H_ins12);
N_oos12 = numel(H_oos12);

R2l = -1; R2h = 7;
figure (1);
subplot(4,2,1);

for i = 1:N_ins1
    h_ins1 = bar(i,H_ins1(i));
    if i <= N_ins1
       hold on 
    end
    if data_ins1(i,2) == 1
       col_ins1 = rgb('DarkSlateGray');
    elseif data_ins1(i,2) == 2
       col_ins1 = rgb('Maroon');
    elseif data_ins1(i,2) == 3
       col_ins1 = rgb('DarkBlue');
    else
       col_ins1 = rgb('SaddleBrown');
    end 
    set(h_ins1,'FaceColor',col_ins1)
end

axis([0 N+1 R2l R2h]);
h=ylabel('$R^2$','FontSize',7)
h0 = title('Forecast with 1-month cross-asset lagged returns','fontweight','normal','FontSize',7)
h1=text('Position',[2 6],'string','average $R^2 =2.16\%$','FontSize',6)
h2 = xlabel('Asset','fontweight','normal','FontSize', 7)
set([h h0 h1 h2],'Interpreter','latex');
set(gca,'ygrid','on') 
set(gca,'XTick',[1 10 20 30 40 50])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',6)

hold on

R2l = -1; R2h = 3;
subplot(4,2,2);

for i = 1:N_oos1
    h_oos1 = bar(i,H_oos1(i));
    if i <= N_oos1
       hold on 
    end
    if data_oos1(i,2) == 1
       col_oos1 = rgb('DarkSlateGray');
    elseif data_oos1(i,2) == 2
       col_oos1 = rgb('Maroon');
    elseif data_oos1(i,2) == 3
       col_oos1 = rgb('DarkBlue');
    else
       col_oos1 = rgb('SaddleBrown');
    end 
    set(h_oos1,'FaceColor',col_oos1)
end

axis([0 N+1 R2l R2h]);
h=ylabel('$R^2_{OS}$','FontSize',7)
h0 = title('Forecast with 1-month cross-asset lagged returns','fontweight','normal','FontSize',7)
h1=text('Position',[2 2.5],'string','average $R^2_{OS} =-0.90\%$','FontSize',6)
h2 = xlabel('Asset','fontweight','normal','FontSize', 7)
set([h h0 h1 h2],'Interpreter','latex');
set(gca,'ygrid','on')
set(gca,'XTick',[1 10 20 30 40 50])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',6)

hold on

R2l = -1; R2h = 7;
subplot(4,2,3);

for i = 1:N_ins3
    h_ins3 = bar(i,H_ins3(i));
    if i <= N_ins3
       hold on 
    end
    if data_ins3(i,2) == 1
       col_ins3 = rgb('DarkSlateGray');
    elseif data_ins3(i,2) == 2
       col_ins3 = rgb('Maroon');
    elseif data_ins3(i,2) == 3
       col_ins3 = rgb('DarkBlue');
    else
       col_ins3 = rgb('SaddleBrown');
    end 
    set(h_ins3,'FaceColor',col_ins3)
end

axis([0 N+1 R2l R2h]);
h=ylabel('$R^2$','FontSize',7)
h0 = title('Forecast with 3-month cross-asset lagged returns','fontweight','normal','FontSize',7)
h1=text('Position',[2 6],'string','average $R^2 =2.12\%$','FontSize',6)
h2 = xlabel('Asset','fontweight','normal','FontSize', 7)
set([h h0 h1 h2],'Interpreter','latex');
set(gca,'ygrid','on')
set(gca,'XTick',[1 10 20 30 40 50])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',6)

hold on

R2l = -1; R2h = 3;
subplot(4,2,4);

for i = 1:N_oos3
    h_oos3 = bar(i,H_oos3(i));
    if i <= N_oos3 
       hold on 
    end
    if data_oos3(i,2) == 1
       col_oos3 = rgb('DarkSlateGray');
    elseif data_oos3(i,2) == 2
       col_oos3 = rgb('Maroon');
    elseif data_oos3(i,2) == 3
       col_oos3 = rgb('DarkBlue');
    else
       col_oos3 = rgb('SaddleBrown');
    end 
    set(h_oos3,'FaceColor',col_oos3)
end

axis([0 N+1 R2l R2h]);
h=ylabel('$R^2_{OS}$','FontSize',7)
h0 = title('Forecast with 3-month cross-asset lagged returns','fontweight','normal','FontSize',7)
h1=text('Position',[1 2.5],'string','average $R^2_{OS} =-0.94\%$','FontSize',6)
h2 = xlabel('Asset','fontweight','normal','FontSize', 7)
set([h h0 h1 h2],'Interpreter','latex');
set(gca,'ygrid','on')
set(gca,'XTick',[1 10 20 30 40 50])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',6)

hold on

R2l = -1; R2h = 7;
subplot(4,2,5);

for i = 1:N_ins6
    h_ins6 = bar(i,H_ins6(i));
    if i <= N_ins6
       hold on 
    end
    if data_ins6(i,2) == 1
       col_ins6 = rgb('DarkSlateGray');
    elseif data_ins6(i,2) == 2
       col_ins6 = rgb('Maroon');
    elseif data_ins6(i,2) == 3
       col_ins6 = rgb('DarkBlue');
    else
       col_ins6 = rgb('SaddleBrown');
    end 
    set(h_ins6,'FaceColor',col_ins6)
end

axis([0 N+1 R2l R2h]);
h=ylabel('$R^2$','FontSize',7)
h0 = title('Forecast with 6-month cross-asset lagged returns','fontweight','normal','FontSize',7)
h1=text('Position',[2 6],'string','average $R^2 =3.08\%$','FontSize',6)
h2 = xlabel('Asset','fontweight','normal','FontSize', 7)
set([h h0 h1 h2],'Interpreter','latex');
set(gca,'ygrid','on')
set(gca,'XTick',[1 10 20 30 40 50])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',6)

hold on

R2l = -1; R2h = 3;
subplot(4,2,6);

for i = 1:N_oos6
    h_oos6 = bar(i,H_oos6(i));
    if i <= N_oos6 
       hold on 
    end
    if data_oos6(i,2) == 1
       col_oos6 = rgb('DarkSlateGray');
    elseif data_oos6(i,2) == 2
       col_oos6 = rgb('Maroon');
    elseif data_oos6(i,2) == 3
       col_oos6 = rgb('DarkBlue');
    else
       col_oos6 = rgb('SaddleBrown');
    end 
    set(h_oos6,'FaceColor',col_oos6)
end

axis([0 N+1 R2l R2h]);
h=ylabel('$R^2_{OS}$','FontSize',7)
h0 = title('Forecast with 6-month cross-asset lagged returns','fontweight','normal','FontSize',7)
h1=text('Position',[1 2.5],'string','average $R^2_{OS} =-1.47\%$','FontSize',6)
h2 = xlabel('Asset','fontweight','normal','FontSize', 7)
set([h h0 h1 h2],'Interpreter','latex');
set(gca,'ygrid','on')
set(gca,'XTick',[1 10 20 30 40 50])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',6)

hold on
subplot(4,2,7);
R2l = -1; R2h = 7;
for i = 1:N_ins12
    h_ins12 = bar(i,H_ins12(i));
    if i <= N_ins12
       hold on 
    end
    if data_ins12(i,2) == 1
       col_ins12 = rgb('DarkSlateGray');
    elseif data_ins12(i,2) == 2
       col_ins12 = rgb('Maroon');
    elseif data_ins12(i,2) == 3
       col_ins12 = rgb('DarkBlue');
    else
       col_ins12 = rgb('SaddleBrown');
    end 
    set(h_ins12,'FaceColor',col_ins12)
end

axis([0 N+1 R2l R2h]);
h=ylabel('$R^2$','FontSize',4)
h0 = title('Forecast with 12-month cross-asset lagged returns','fontweight','normal','FontSize',4)
h1=text('Position',[2 6],'string','average $R^2 = 3.20\%$','FontSize',6)
h2 = xlabel('Asset','fontweight','normal','FontSize', 4)
set([h h0 h1 h2],'Interpreter','latex');
set(gca,'ygrid','on')
set(gca,'XTick',[1 10 20 30 40 50])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',6)

hold on
subplot(4,2,8);
R2l = -1; R2h = 3;
for i = 1:N_oos12
    h_oos12 = bar(i,H_oos12(i));
    if i <= N_oos12 
       hold on 
    end
    if data_oos12(i,2) == 1
       col_oos12 = rgb('DarkSlateGray');
    elseif data_oos12(i,2) == 2
       col_oos12 = rgb('Maroon');
    elseif data_oos12(i,2) == 3
       col_oos12 = rgb('DarkBlue');
    else
       col_oos12 = rgb('SaddleBrown');
    end 
    set(h_oos12,'FaceColor',col_oos12)
end

axis([0 N+1 R2l R2h]);
h=ylabel('$R^2_{OS}$','FontSize',4)
h0 = title('Forecast with 12-month cross-asset lagged returns','fontweight','normal','FontSize',4)
h1=text('Position',[1 2.5],'string','average $R^2_{OS} = -1.10\%$','FontSize',6)
h2 = xlabel('Asset','fontweight','normal','FontSize', 4)
set([h h0 h1 h2],'Interpreter','latex');
set(gca,'ygrid','on')
set(gca,'XTick',[1 10 20 30 40 50])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',6)

save2pdf('E:\RESEARCH\TSMOM\Codes_new\Fig3_R2PLS',gcf,600)
