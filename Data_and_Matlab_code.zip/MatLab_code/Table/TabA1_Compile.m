%% Compile bootstrap results (Tab A1) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new\MAT';
addpath 'E:\Dropbox\My toolbox';

%% Commodity %%
load TabA1_TstatCom2009.mat
tstat = res_com([1, 3, 6, 12],2);
tstat_sign = ressign_com([1, 3, 6, 12],2);
load TabA1_WildCom2009.mat
tstat_wild = tstat_all;
tstat_sign_wild = tstat_sign_all;
load TabA1_PairCom2009.mat
tstat_pair = tstat_all;
tstat_sign_pair = tstat_sign_all;
load TabA1_FixCom2009.mat
tstat_fix = tstat_all;
tstat_sign_fix = tstat_sign_all;

wild = []; wild_sign = [];
pair = []; pair_sign = [];
fix = []; fix_sign = [];
for j = [1, 3, 6, 12]
   wild_j = tstat_wild(:,j);
   wild_sign_j = tstat_sign_wild(:,j);
   pair_j = tstat_pair(:,j);
   pair_sign_j = tstat_sign_pair(:,j);
   fix_j = tstat_fix(:,j);
   fix_sign_j = tstat_sign_fix(:,j);
   
   wild = [wild; prctile(wild_j, 97.5)];
   wild_sign = [wild_sign; prctile(wild_sign_j, 97.5)];
   pair = [pair; prctile(pair_j, 97.5)];
   pair_sign = [pair_sign; prctile(pair_sign_j, 97.5)];
   fix = [fix; prctile(fix_j, 97.5)];
   fix_sign = [fix_sign; prctile(fix_sign_j, 97.5)];
end
TabA1A = table(tstat, wild, pair, fix, tstat_sign, wild_sign, pair_sign, fix_sign);

%% Equity %%
load TabA1_TstatEqt2009.mat
tstat = res_eqt([1, 3, 6, 12],2);
tstat_sign = ressign_eqt([1, 3, 6, 12],2);
load TabA1_WildEqt2009.mat
tstat_wild = tstat_all;
tstat_sign_wild = tstat_sign_all;
load TabA1_PairEqt2009.mat
tstat_pair = tstat_all;
tstat_sign_pair = tstat_sign_all;
load TabA1_FixEqt2009.mat
tstat_fix = tstat_all;
tstat_sign_fix = tstat_sign_all;

wild = []; wild_sign = [];
pair = []; pair_sign = [];
fix = []; fix_sign = [];
for j = [1, 3, 6, 12]
   wild_j = tstat_wild(:,j);
   wild_sign_j = tstat_sign_wild(:,j);
   pair_j = tstat_pair(:,j);
   pair_sign_j = tstat_sign_pair(:,j);
   fix_j = tstat_fix(:,j);
   fix_sign_j = tstat_sign_fix(:,j);
   
   wild = [wild; prctile(wild_j, 97.5)];
   wild_sign = [wild_sign; prctile(wild_sign_j, 97.5)];
   pair = [pair; prctile(pair_j, 97.5)];
   pair_sign = [pair_sign; prctile(pair_sign_j, 97.5)];
   fix = [fix; prctile(fix_j, 97.5)];
   fix_sign = [fix_sign; prctile(fix_sign_j, 97.5)];
end
TabA1B = table(tstat, wild, pair, fix, tstat_sign, wild_sign, pair_sign, fix_sign);

%% Bond %%
load TabA1_TstatBnd2009.mat
tstat = res_bond([1, 3, 6, 12],2);
tstat_sign = ressign_bond([1, 3, 6, 12],2);
load TabA1_WildBnd2009.mat
tstat_wild = tstat_all;
tstat_sign_wild = tstat_sign_all;
load TabA1_PairBnd2009.mat
tstat_pair = tstat_all;
tstat_sign_pair = tstat_sign_all;
load TabA1_FixBnd2009.mat
tstat_fix = tstat_all;
tstat_sign_fix = tstat_sign_all;

wild = []; wild_sign = [];
pair = []; pair_sign = [];
fix = []; fix_sign = [];
for j = [1, 3, 6, 12]
   wild_j = tstat_wild(:,j);
   wild_sign_j = tstat_sign_wild(:,j);
   pair_j = tstat_pair(:,j);
   pair_sign_j = tstat_sign_pair(:,j);
   fix_j = tstat_fix(:,j);
   fix_sign_j = tstat_sign_fix(:,j);
   
   wild = [wild; prctile(wild_j, 97.5)];
   wild_sign = [wild_sign; prctile(wild_sign_j, 97.5)];
   pair = [pair; prctile(pair_j, 97.5)];
   pair_sign = [pair_sign; prctile(pair_sign_j, 97.5)];
   fix = [fix; prctile(fix_j, 97.5)];
   fix_sign = [fix_sign; prctile(fix_sign_j, 97.5)];
end
TabA1C = table(tstat, wild, pair, fix, tstat_sign, wild_sign, pair_sign, fix_sign);

%% Currency %%
load TabA1_TstatCur2009.mat
tstat = res_cur([1, 3, 6, 12],2);
tstat_sign = ressign_cur([1, 3, 6, 12],2);
load TabA1_WildCur2009.mat
tstat_wild = tstat_all;
tstat_sign_wild = tstat_sign_all;
load TabA1_PairCur2009.mat
tstat_pair = tstat_all;
tstat_sign_pair = tstat_sign_all;
load TabA1_FixCur2009.mat
tstat_fix = tstat_all;
tstat_sign_fix = tstat_sign_all;

wild = []; wild_sign = [];
pair = []; pair_sign = [];
fix = []; fix_sign = [];
for j = [1, 3, 6, 12]
   wild_j = tstat_wild(:,j);
   wild_sign_j = tstat_sign_wild(:,j);
   pair_j = tstat_pair(:,j);
   pair_sign_j = tstat_sign_pair(:,j);
   fix_j = tstat_fix(:,j);
   fix_sign_j = tstat_sign_fix(:,j);
   
   wild = [wild; prctile(wild_j, 97.5)];
   wild_sign = [wild_sign; prctile(wild_sign_j, 97.5)];
   pair = [pair; prctile(pair_j, 97.5)];
   pair_sign = [pair_sign; prctile(pair_sign_j, 97.5)];
   fix = [fix; prctile(fix_j, 97.5)];
   fix_sign = [fix_sign; prctile(fix_sign_j, 97.5)];
end
TabA1D = table(tstat, wild, pair, fix, tstat_sign, wild_sign, pair_sign, fix_sign);