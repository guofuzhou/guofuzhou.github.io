%% Compile bootstrap results (Tab 4) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new\MAT';
addpath 'E:\Dropbox\My toolbox';

%% Commodity %%
load Tab4_TstatCom.mat
tstat = res_com([1, 3, 6, 12],2);
tstat_sign = ressign_com([1, 3, 6, 12],2);
load Tab4_WildCom.mat
tstat_wild = tstat_all;
tstat_sign_wild = tstat_sign_all;
load Tab4_PairCom.mat
tstat_pair = tstat_all;
tstat_sign_pair = tstat_sign_all;
load Tab4_FixCom.mat
tstat_fix = tstat_all;
tstat_sign_fix = tstat_sign_all;

wild = []; wild_sign = [];
pair = []; pair_sign = [];
fix = []; fix_sign = [];
for j = [1, 3, 6, 12]
   wild_j = tstat_wild(:,j);
   wild_sign_j = tstat_sign_wild(:,j);
   pair_j = tstat_pair(:,j);
   pair_sign_j = tstat_sign_pair(:,j);
   fix_j = tstat_fix(:,j);
   fix_sign_j = tstat_sign_fix(:,j);
   
   wild = [wild; prctile(wild_j, 97.5)];
   wild_sign = [wild_sign; prctile(wild_sign_j, 97.5)];
   pair = [pair; prctile(pair_j, 97.5)];
   pair_sign = [pair_sign; prctile(pair_sign_j, 97.5)];
   fix = [fix; prctile(fix_j, 97.5)];
   fix_sign = [fix_sign; prctile(fix_sign_j, 97.5)];
end
Tab4A = table(tstat, wild, pair, fix, tstat_sign, wild_sign, pair_sign, fix_sign);

%% Equity %%
load Tab4_TstatEqt.mat
tstat = res_eqt([1, 3, 6, 12],2);
tstat_sign = ressign_eqt([1, 3, 6, 12],2);
load Tab4_WildEqt.mat
tstat_wild = tstat_all;
tstat_sign_wild = tstat_sign_all;
load Tab4_PairEqt.mat
tstat_pair = tstat_all;
tstat_sign_pair = tstat_sign_all;
load Tab4_FixEqt.mat
tstat_fix = tstat_all;
tstat_sign_fix = tstat_sign_all;

wild = []; wild_sign = [];
pair = []; pair_sign = [];
fix = []; fix_sign = [];
for j = [1, 3, 6, 12]
   wild_j = tstat_wild(:,j);
   wild_sign_j = tstat_sign_wild(:,j);
   pair_j = tstat_pair(:,j);
   pair_sign_j = tstat_sign_pair(:,j);
   fix_j = tstat_fix(:,j);
   fix_sign_j = tstat_sign_fix(:,j);
   
   wild = [wild; prctile(wild_j, 97.5)];
   wild_sign = [wild_sign; prctile(wild_sign_j, 97.5)];
   pair = [pair; prctile(pair_j, 97.5)];
   pair_sign = [pair_sign; prctile(pair_sign_j, 97.5)];
   fix = [fix; prctile(fix_j, 97.5)];
   fix_sign = [fix_sign; prctile(fix_sign_j, 97.5)];
end
Tab4B = table(tstat, wild, pair, fix, tstat_sign, wild_sign, pair_sign, fix_sign);

%% Bond %%
load Tab4_TstatBnd.mat
tstat = res_bond([1, 3, 6, 12],2);
tstat_sign = ressign_bond([1, 3, 6, 12],2);
load Tab4_WildBnd.mat
tstat_wild = tstat_all;
tstat_sign_wild = tstat_sign_all;
load Tab4_PairBnd.mat
tstat_pair = tstat_all;
tstat_sign_pair = tstat_sign_all;
load Tab4_FixBnd.mat
tstat_fix = tstat_all;
tstat_sign_fix = tstat_sign_all;

wild = []; wild_sign = [];
pair = []; pair_sign = [];
fix = []; fix_sign = [];
for j = [1, 3, 6, 12]
   wild_j = tstat_wild(:,j);
   wild_sign_j = tstat_sign_wild(:,j);
   pair_j = tstat_pair(:,j);
   pair_sign_j = tstat_sign_pair(:,j);
   fix_j = tstat_fix(:,j);
   fix_sign_j = tstat_sign_fix(:,j);
   
   wild = [wild; prctile(wild_j, 97.5)];
   wild_sign = [wild_sign; prctile(wild_sign_j, 97.5)];
   pair = [pair; prctile(pair_j, 97.5)];
   pair_sign = [pair_sign; prctile(pair_sign_j, 97.5)];
   fix = [fix; prctile(fix_j, 97.5)];
   fix_sign = [fix_sign; prctile(fix_sign_j, 97.5)];
end
Tab4C = table(tstat, wild, pair, fix, tstat_sign, wild_sign, pair_sign, fix_sign);

%% Currency %%
load Tab4_TstatCur.mat
tstat = res_cur([1, 3, 6, 12],2);
tstat_sign = ressign_cur([1, 3, 6, 12],2);
load Tab4_WildCur.mat
tstat_wild = tstat_all;
tstat_sign_wild = tstat_sign_all;
load Tab4_PairCur.mat
tstat_pair = tstat_all;
tstat_sign_pair = tstat_sign_all;
load Tab4_FixCur.mat
tstat_fix = tstat_all;
tstat_sign_fix = tstat_sign_all;

wild = []; wild_sign = [];
pair = []; pair_sign = [];
fix = []; fix_sign = [];
for j = [1, 3, 6, 12]
   wild_j = tstat_wild(:,j);
   wild_sign_j = tstat_sign_wild(:,j);
   pair_j = tstat_pair(:,j);
   pair_sign_j = tstat_sign_pair(:,j);
   fix_j = tstat_fix(:,j);
   fix_sign_j = tstat_sign_fix(:,j);
   
   wild = [wild; prctile(wild_j, 97.5)];
   wild_sign = [wild_sign; prctile(wild_sign_j, 97.5)];
   pair = [pair; prctile(pair_j, 97.5)];
   pair_sign = [pair_sign; prctile(pair_sign_j, 97.5)];
   fix = [fix; prctile(fix_j, 97.5)];
   fix_sign = [fix_sign; prctile(fix_sign_j, 97.5)];
end
Tab4D = table(tstat, wild, pair, fix, tstat_sign, wild_sign, pair_sign, fix_sign);