%% Compile bootstrap results (Tab 6) %%

clear;clc
addpath 'E:\RESEARCH\TSMOM\Codes_new\MAT';
addpath 'E:\Dropbox\My toolbox';

load Tab6_TstatAll2009.mat
tstat = res(1:12,2);
tstat_sign = res_sign(1:12,2);
load Tab6_WildVol2009.mat
tstat_wild = tstat_all;
tstat_sign_wild = tstat_sign_all;
load Tab6_PairVol2009.mat
tstat_pair = tstat_all;
tstat_sign_pair = tstat_sign_all;
load Tab6_FixVol2009.mat
tstat_fix = tstat_all;
tstat_sign_fix = tstat_sign_all;
load Tab6_TstatCum_All2009.mat
tstat_cum = res(1:12,2);
tstat_sign_cum = res_sign(1:12,2);
load Tab6_WildVolCum2009.mat
tstat_cum_wild = tstat_all;
tstat_sign_cum_wild = tstat_sign_all;
load Tab6_PairVolCum2009.mat
tstat_cum_pair = tstat_all;
tstat_sign_cum_pair = tstat_sign_all;
load Tab6_FixVolCum2009.mat
tstat_cum_fix = tstat_all;
tstat_sign_cum_fix = tstat_sign_all;

wild = []; wild_sign = [];
pair = []; pair_sign = [];
fix = []; fix_sign = [];
wild_cum = []; wild_sign_cum = [];
pair_cum = []; pair_sign_cum = [];
fix_cum = []; fix_sign_cum = [];
for j = 1:12
   wild_j = tstat_wild(:,j);
   wild_sign_j = tstat_sign_wild(:,j);
   pair_j = tstat_pair(:,j);
   pair_sign_j = tstat_sign_pair(:,j);
   fix_j = tstat_fix(:,j);
   fix_sign_j = tstat_sign_fix(:,j);
   
   wild_cum_j = tstat_cum_wild(:,j);
   wild_sign_cum_j = tstat_sign_cum_wild(:,j);
   pair_cum_j = tstat_cum_pair(:,j);
   pair_sign_cum_j = tstat_sign_cum_pair(:,j);
   fix_cum_j = tstat_cum_fix(:,j);
   fix_sign_cum_j = tstat_sign_cum_fix(:,j);
    
   wild = [wild; prctile(wild_j, 97.5)];
   wild_sign = [wild_sign; prctile(wild_sign_j, 97.5)];
   pair = [pair; prctile(pair_j, 97.5)];
   pair_sign = [pair_sign; prctile(pair_sign_j, 97.5)];
   fix = [fix; prctile(fix_j, 97.5)];
   fix_sign = [fix_sign; prctile(fix_sign_j, 97.5)];
   
   wild_cum = [wild_cum; prctile(wild_cum_j, 97.5)];
   wild_sign_cum = [wild_sign_cum; prctile(wild_sign_cum_j, 97.5)];
   pair_cum = [pair_cum; prctile(pair_cum_j, 97.5)];
   pair_sign_cum = [pair_sign_cum; prctile(pair_sign_cum_j, 97.5)];
   fix_cum = [fix_cum; prctile(fix_cum_j, 97.5)];
   fix_sign_cum = [fix_sign_cum; prctile(fix_sign_cum_j, 97.5)];
end

Tab6A = table(tstat, wild, pair, fix, tstat_sign, wild_sign, pair_sign, fix_sign);
Tab6B = table(tstat_cum, wild_cum, pair_cum, fix_cum, tstat_sign_cum, wild_sign_cum, pair_sign_cum, fix_sign_cum);



