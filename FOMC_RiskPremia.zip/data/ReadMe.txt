The dataset contains the FOMC risk premium estimated following Liu, Tang, and Zhou (2021). The FOMC risk premium is estimated for each scheduled meeting from 1996 to 2019.

Variable 'opt_ind' indicates if the estimation is based on real option prices (opt_ind=1) or IV surface extrapolation (opt_ind=0).

Variable 'date' is the date that the option prices are observed. Option prices observed on this date is used for direct estimation (opt_ind=1), or for IV surface extrapolation (opt_ind=0).

Variable 'exdate' is the expiration date of the options used for the estimation. Note that this variable is available only when real option prices are used. Otherwise, the extrapolation methodology generates synthetic option prices that mature on the FOMC announcement day.

Variable 'fomcdate' is the announcement date.

FOMC risk premium is estimated based on gamma=7.5 (rp_7.5) and gamma=10 (rp_10).

We are working on the full replication package. It will be posted once it is ready.