import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
# Regression
import statsmodels.formula.api as smf
# Save data
import os
import seaborn as sns; sns.set(color_codes=True)
import statsmodels.api as sm
import functools
plt.rcParams['text.usetex'] = True
from statsmodels.formula.api import ols

#%% Read data
current_directory = os.getcwd()
data_folder = os.path.join(current_directory, 'data')
df = pd.read_csv(os.path.join(data_folder,'FactorsDiffK.csv'),encoding_errors='ignore',on_bad_lines='skip')
df = df.set_index('date')

#%%
rslt_all = []
F_test = []
for K in [1, 2, 3, 4, 5, 6, 8, 10, 15, 20]:
    reg2 = smf.ols('stock_mom ~ 1+mkt_rf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    reg3 = smf.ols(f'stock_mom ~ 1+fmom{K}+mkt_rf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    reg4 = smf.ols(f'stock_mom ~ 1+fmom{K}+BAS{K}+mkt_rf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})

    # Fit the full model (including BAS)
    full_model = ols(f'stock_mom ~ fmom{K}+BAS{K}+mkt_rf+smb+hml+rmw+cma', data=df).fit()
    
    # Fit the restricted model (excluding BAS)
    restricted_model = ols(f'stock_mom ~ fmom{K}+mkt_rf+smb+hml+rmw+cma', data=df).fit()
    
    # Perform an F-test
    f_test = full_model.compare_f_test(restricted_model)

    (t_value, p_value, _) = f_test
        
    #****** bias
    corr_ = df[['stock_mom',f'fmom{K}',f'BAS{K}']].corr()
    corr_mom = corr_[f'BAS{K}']['stock_mom']
    corr_fmom = corr_[f'BAS{K}'][f'fmom{K}']
    
    #reg_temp = smf.ols('BAS ~ 1+fmom',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    #delta_ = reg_temp.params[1]
    #bias1 = reg4.params[2] * delta_ * df['fmom'].mean()

    bias1 = (reg4.params[1] - reg3.params[1]) * df[f'fmom{K}'].mean()
    bias2 = reg4.params[2] * df[f'BAS{K}'].mean()

    rslt_all.append(pd.Series({
                           'alpha_fmom':reg3.params[0], 'tstat1':reg3.tvalues[0],
                           'beta_fmom1':reg3.params[1], 'b_tstat1':reg3.tvalues[1],
                           'r21':reg3.rsquared_adj*100,
                           'alpha_fmom_bas':reg4.params[0], 'tstat2':reg4.tvalues[0],
                           'beta_fmom2':reg4.params[1], 'b_tstat2':reg4.tvalues[1],
                           'beta_bas':reg4.params[2], 'b_bas_tstat':reg4.tvalues[2],
                           'r22':reg4.rsquared_adj*100,
                           't_value':t_value, 'p_value':p_value,
                           #'corr_mom':corr_mom, 'corr_fmom':corr_fmom,
                           'bias1':bias1,'bias2':bias2},name=K))

rslt_all = pd.concat(rslt_all, axis=1)

#%%
K = 10 # or K = 20
restricted_model = smf.ols(f'stock_mom ~ 1+fmom{K}+mkt_rf+smb+hml+rmw+cma', data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
# Get residuals from the restricted model
df['residuals'] = restricted_model.resid
# drop outlier
df_ = df.loc[(df[f'BAS{K}'].abs()<10) & (df['residuals'].abs()<20)]
# plot
sns.set_theme(style='white')
plt.figure(figsize=(9, 8))
ax = sns.regplot(x=df_[f'BAS{K}'], y=df_['residuals'], ci=95, truncate=False, scatter_kws={"s": 60}, line_kws={"linewidth": 5}, marker='o')
ax.tick_params(axis='both', which='major', labelsize=16)

plt.xlabel(r"Betting Against Systematic Factor", fontsize=18)
plt.ylabel(r"Residual", fontsize=18)
ylim = ax.get_ylim()
plt.tight_layout()
plt.xlim([-10, 10])
plt.ylim([-20, 20])
plt.grid(linestyle='--', color='0.8')
sns.despine(top=True, right=True, left=False, bottom=False)

reg = smf.ols(f'residuals ~ 1+BAS{K}', data=df_).fit(cov_type='HAC',cov_kwds={'maxlags':5})
coef = reg.params[1]
tt = reg.tvalues[1]
R2 = reg.rsquared_adj*100
reg.summary()
