# -*- coding: utf-8 -*-
"""
Created on Wed Dec 11 11:43:53 2024

@author: peixu
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
# Regression
import statsmodels.formula.api as smf
# Save data
import os
import seaborn as sns; sns.set(color_codes=True)
import statsmodels.api as sm
import functools
plt.rcParams['text.usetex'] = True
from statsmodels.formula.api import ols

#%% Read data
current_directory = os.getcwd()
data_folder = os.path.join(current_directory, 'data')
df = pd.read_csv(os.path.join(data_folder,'FactorsDiffK.csv'),encoding_errors='ignore',on_bad_lines='skip')
df = df.set_index('date')

#%%
K = 10 # or K = 20
restricted_model = smf.ols(f'stock_mom ~ 1+fmom{K}+mkt_rf+smb+hml+rmw+cma', data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
# Get residuals from the restricted model
df['residuals'] = restricted_model.resid
# drop outlier
df_ = df.loc[(df[f'BAS{K}'].abs()<10) & (df['residuals'].abs()<20)]
# plot
sns.set_theme(style='white')
plt.figure(figsize=(9, 8))
ax = sns.regplot(x=df_[f'BAS{K}'], y=df_['residuals'], ci=95, truncate=False, scatter_kws={"s": 60}, line_kws={"linewidth": 5}, marker='o')
ax.tick_params(axis='both', which='major', labelsize=16)

plt.xlabel(r"Betting Against Systematic Factor", fontsize=18)
plt.ylabel(r"Residual", fontsize=18)
ylim = ax.get_ylim()
plt.tight_layout()
plt.xlim([-10, 10])
plt.ylim([-20, 20])
plt.grid(linestyle='--', color='0.8')
sns.despine(top=True, right=True, left=False, bottom=False)

reg = smf.ols(f'residuals ~ 1+BAS{K}', data=df_).fit(cov_type='HAC',cov_kwds={'maxlags':5})
coef = reg.params[1]
tt = reg.tvalues[1]
R2 = reg.rsquared_adj*100
reg.summary()
