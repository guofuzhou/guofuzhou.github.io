Replication code for "Momentum and Factor Momentum: A Re-examination" 
Authors: CHENG GAO, SOPHIA ZHENGZI LI, PEIXUAN YUAN, and GUOFU ZHOU

************************************ Data ****************************************

The "data" folder includes the following files:

1. Factors.csv
   - p1-p10, returns on decile portfolios sorted on momentum
   - H_L, individual stock momentum, high decile minus low decile
   - BAS, betting-against-systematic factor
   - BAS_oos, out-of-sample BAS factor
   - resmom, stock residual momentum
   - fmom{K}, momentum in the top K PC factors

2. FactorsDiffK.csv
   - fmom{K}, momentum in the top K PC factors
   - BAS{K}, betting-against-systematic factor constructed based on K-factor IPCA specification

3. EL2022Factors.csv
   - factors data from Ehsani and Linnainmaa (2022),
     accessible at https://onlinelibrary.wiley.com/doi/abs/10.1111/jofi.13131


************************************ Code ****************************************

==================================================================================
                                     Table 
==================================================================================

1. Table I.py
   - produce the results in Table I

2. Table II.py
   - produce the results in Table II

3. EL2022_TableIV.py
   - replicate the results in Table IV in Ehsani and Linnainmaa (2022)

4. Table IA.V.py
   - produce the results in Table IA.V in the Internet Appendix
   - this table replicates Table I using out-of-sample BAS factor

==================================================================================
                                     Figure
==================================================================================

1. Figure I.py
   - generate Figure I

