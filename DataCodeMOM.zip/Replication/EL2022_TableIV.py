import numpy as np
import pandas as pd
# Regression
import statsmodels.formula.api as smf
# Save data
import os
import functools
from scipy.stats import f

def grs_test(resid: np.ndarray, alpha: np.ndarray, factors: np.ndarray) -> tuple:
    """ Perform the Gibbons, Ross and Shaken (1989) test.
        :param resid: Matrix of residuals from the OLS of size TxK.
        :param alpha: Vector of alphas from the OLS of size Kx1.
        :param factors: Matrix of factor returns of size TxJ.
        :return Test statistic and pValue of the test statistic.
        The functions expects:

    A TxK np.array of residuals from an OLS of assets on common risk factors,
    A Kx1 np.array of intercepts from an OLS of assets on common risk factors,
    A TxJ np.array of risk factors.

    T: The time series dimension, K: Assets, J: Risk Factors.
    """
    # Determine the time series and assets
    iT, iK = resid.shape

    # Determine the amount of risk factors
    iJ = factors.shape[1]

    # Input size checks
    assert alpha.shape == (iK, 1)
    assert factors.shape == (iT, iJ)

    # Covariance of the residuals, variables are in columns.
    mCov = np.cov(resid, rowvar=False)

    # Mean of excess returns of the risk factors
    vMuRF = np.nanmean(factors, axis=0)

    try:
        assert vMuRF.shape == (1, iJ)
    except AssertionError:
        vMuRF = vMuRF.reshape(1, iJ)

    # Duplicate this series for T timestamps
    mMuRF = np.repeat(vMuRF, iT, axis=0)

    # Test statistic
    mCovRF = (factors - mMuRF).T @ (factors - mMuRF) / (iT - 1)
    dTestStat = (iT / iK) * ((iT - iK - iJ) / (iT - iJ - 1)) * \
                (alpha.T @ (np.linalg.inv(mCov) @ alpha)) / \
                (1 + (vMuRF @ (np.linalg.inv(mCovRF) @ vMuRF.T)))

    pVal = 1 - f.cdf(dTestStat, iK, iT-iK-iJ)

    return dTestStat, pVal

#%% Read data
current_directory = os.getcwd()
data_folder = os.path.join(current_directory, 'data')
df = pd.read_csv(os.path.join(data_folder,'EL2022Factors.csv'),encoding_errors='ignore',on_bad_lines='skip')
df = df.set_index('date')

#%% Panel A
# Pricing Decile Portfolios Sorted on Past Returns

cols = ['ExcessP1', 'ExcessP2', 'ExcessP3', 'ExcessP4', 'ExcessP5', 'ExcessP6',
'ExcessP7', 'ExcessP8', 'ExcessP9', 'ExcessP10', 'ExcessP11']
rslt = []
for ii in cols:
    reg = smf.ols(f'{ii} ~ 1+mktrf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    reg1 = smf.ols(f'{ii} ~ 1+TSMom+mktrf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    reg2 = smf.ols(f'{ii} ~ 1+pctsmom1+mktrf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    reg3 = smf.ols(f'{ii} ~ 1+TSMom+BAS+mktrf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    reg4 = smf.ols(f'{ii} ~ 1+pctsmom1+BAS+mktrf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})

    ret1 = pd.Series({'FF5':reg.params[0], 
                      'TSMom':reg1.params[0], 'beta_fmom1':reg1.params[1],
                      'pctsmom1':reg2.params[0], 'beta_fmom2':reg2.params[1],
                      'TSMom_BAS':reg3.params[0], 'beta_fmom3':reg3.params[1], 'beta_bas1':reg3.params[2], 
                      'pctsmom1_BAS':reg4.params[0], 'beta_fmom4':reg4.params[1], 'beta_bas2':reg4.params[2]},name=ii)
    t1 = pd.Series({'FF5':reg.tvalues[0], 
                      'TSMom':reg1.tvalues[0], 'beta_fmom1':reg1.tvalues[1],
                      'pctsmom1':reg2.tvalues[0], 'beta_fmom2':reg2.tvalues[1],
                      'TSMom_BAS':reg3.tvalues[0], 'beta_fmom3':reg3.tvalues[1], 'beta_bas1':reg3.tvalues[2], 
                      'pctsmom1_BAS':reg4.tvalues[0], 'beta_fmom4':reg4.tvalues[1], 'beta_bas2':reg4.tvalues[2]},name=ii)
    temp = pd.concat([ret1,t1],axis=1).T
    rslt.append(temp)
        
rslt_ret = pd.concat(rslt, axis=0)

#************************************ GRS ************************
fmodels = {}
fmodels[0] = ['mktrf','smb','hml','rmw','cma']
fmodels[1] = ['mktrf','smb','hml','rmw','cma','TSMom']
fmodels[2] = ['mktrf','smb','hml','rmw','cma','pctsmom1']
fmodels[3] = ['mktrf','smb','hml','rmw','cma','BAS','TSMom']
fmodels[4] = ['mktrf','smb','hml','rmw','cma','BAS','pctsmom1']

resid_all = {}
alphas_all = {}
cols = ['ExcessP1', 'ExcessP2', 'ExcessP3', 'ExcessP4', 'ExcessP5', 'ExcessP6',
'ExcessP7', 'ExcessP8', 'ExcessP9', 'ExcessP10']

for ii, fmodel in fmodels.items():
    rslt = []
    resid = []
    alp = []
    for col in cols:
        lst = functools.reduce(lambda a,b : '{}+{}'.format(a,b),fmodel)
        lst = '1 + '+lst# all together
        df_ = df.dropna()
        reg = smf.ols('{} ~ {}'.format(col, lst),data=df_).fit(cov_type='HAC',cov_kwds={'maxlags':5})
        pred = reg.fittedvalues.mean() - reg.params[0]
        act = df[col].mean()
        resid.append(reg.resid)
        alp.append(reg.params[0])
    resid = pd.concat(resid, axis=1)
    resid_all[ii] = resid
    alphas_all[ii] = alp

df_ = df.dropna()
rslt_grs = []
for num, fmodel in fmodels.items():
    grs_t, grs_p = grs_test(resid_all[num].values, np.reshape(np.array(alphas_all[num]), (len(cols), 1)), df_[fmodels[num]].values)
    grs_t = grs_t[0][0]
    grs_p = grs_p[0][0]*100
    abs_alpa = np.mean(np.abs(alphas_all[num]))
    rslt_grs.append(pd.Series({'abs_alpa':abs_alpa, 'grs_t':grs_t,
                           'grs_p':grs_p},name=num))

    print(abs_alpa, grs_t, grs_p)
rslt_grs = pd.concat(rslt_grs, axis=1)

#%% Panel B
# Pricing UMD with Momentum in Subsets of PC Factors

scols = ['pctsmom1', 'pctsmom2', 'pctsmom3', 'pctsmom4', 'pctsmom5']
rslt = []
for ii in scols:
    reg = smf.ols(f'umd ~ 1+{ii}+mktrf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    reg1 = smf.ols(f'umd ~ 1+{ii}+BAS+mktrf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    
    ret1 = pd.Series({'fmom':reg.params[0], 'beta_fmom':reg.params[1], 'r21':reg.rsquared_adj*100,
                      'fmom_bas':reg1.params[0], 'beta_fmom2':reg1.params[1], 
                      'beta_bas':reg1.params[2], 'r22':reg1.rsquared_adj*100},name=ii)
    t1 = pd.Series({'fmom':reg.tvalues[0], 'beta_fmom':reg.tvalues[1], 'r21':np.nan,
                      'fmom_bas':reg1.tvalues[0], 'beta_fmom2':reg1.tvalues[1], 
                      'beta_bas':reg1.tvalues[2], 'r22':np.nan},name=ii)
    temp = pd.concat([ret1,t1],axis=1).T
    rslt.append(temp)

rslt = pd.concat(rslt, axis=0)

# FF5 Model
reg_umd = smf.ols('umd ~ 1+mktrf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
rslt_ff5 = {reg_umd.params[0], reg_umd.tvalues[0], reg_umd.rsquared_adj*100}
