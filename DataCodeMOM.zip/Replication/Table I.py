import numpy as np
import pandas as pd
# Regression
import statsmodels.formula.api as smf
# Save data
import os
import functools
from scipy.stats import f

def grs_test(resid: np.ndarray, alpha: np.ndarray, factors: np.ndarray) -> tuple:
    """ Perform the Gibbons, Ross and Shaken (1989) test.
        :param resid: Matrix of residuals from the OLS of size TxK.
        :param alpha: Vector of alphas from the OLS of size Kx1.
        :param factors: Matrix of factor returns of size TxJ.
        :return Test statistic and pValue of the test statistic.
        The functions expects:

    A TxK np.array of residuals from an OLS of assets on common risk factors,
    A Kx1 np.array of intercepts from an OLS of assets on common risk factors,
    A TxJ np.array of risk factors.

    T: The time series dimension, K: Assets, J: Risk Factors.
    """
    # Determine the time series and assets
    iT, iK = resid.shape

    # Determine the amount of risk factors
    iJ = factors.shape[1]

    # Input size checks
    assert alpha.shape == (iK, 1)
    assert factors.shape == (iT, iJ)

    # Covariance of the residuals, variables are in columns.
    mCov = np.cov(resid, rowvar=False)

    # Mean of excess returns of the risk factors
    vMuRF = np.nanmean(factors, axis=0)

    try:
        assert vMuRF.shape == (1, iJ)
    except AssertionError:
        vMuRF = vMuRF.reshape(1, iJ)

    # Duplicate this series for T timestamps
    mMuRF = np.repeat(vMuRF, iT, axis=0)

    # Test statistic
    mCovRF = (factors - mMuRF).T @ (factors - mMuRF) / (iT - 1)
    dTestStat = (iT / iK) * ((iT - iK - iJ) / (iT - iJ - 1)) * \
                (alpha.T @ (np.linalg.inv(mCov) @ alpha)) / \
                (1 + (vMuRF @ (np.linalg.inv(mCovRF) @ vMuRF.T)))

    pVal = 1 - f.cdf(dTestStat, iK, iT-iK-iJ)

    return dTestStat, pVal

#%% Read data
current_directory = os.getcwd()
data_folder = os.path.join(current_directory, 'data')
df = pd.read_csv(os.path.join(data_folder,'Factors.csv'),encoding_errors='ignore',on_bad_lines='skip')
df = df.set_index('date')

#%% Table I
cols = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10', 'H_L']
rslt = []
for ii in cols:
    reg = smf.ols(f'{ii} ~ 1+mkt_rf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    reg1 = smf.ols(f'{ii} ~ 1+fmom10+mkt_rf+smb+hml+rmw+cma',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    reg2 = smf.ols(f'{ii} ~ 1+fmom10+mkt_rf+smb+hml+rmw+cma+BAS',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    reg3 = smf.ols(f'{ii} ~ 1+fmom20+mkt_rf+smb+hml+rmw+cma+BAS',data=df).fit(cov_type='HAC',cov_kwds={'maxlags':5})
    ret1 = pd.Series({'FF5':reg.params[0], 'FF5_FMOM':reg1.params[0], 
                      'fmom10':reg2.params[0], 'beta_fmom10':reg2.params[1],
                      'fmom20':reg3.params[0], 'beta_fmom20':reg3.params[1]},name=ii)
    t1 = pd.Series({'FF5':reg.tvalues[0], 'FF5_FMOM':reg1.tvalues[0], 
                    'fmom10':reg2.tvalues[0], 'beta_fmom10':reg2.tvalues[1],
                    'fmom20':reg3.tvalues[0], 'beta_fmom20':reg3.tvalues[1]},name=ii)
    temp = pd.concat([ret1,t1],axis=1).T
    rslt.append(temp)
        
rslt_ret = pd.concat(rslt, axis=0)

#******************************** GRS *******************************
fmodels = {}
fmodels[0] = ['mkt_rf','smb','hml','rmw','cma']
fmodels[1] = ['mkt_rf','smb','hml','rmw','cma','fmom10']
fmodels[2] = ['mkt_rf','smb','hml','rmw','cma','BAS','fmom10']
fmodels[3] = ['mkt_rf','smb','hml','rmw','cma','BAS','fmom20']

resid_all = {}
alphas_all = {}
cols = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10']
for ii, fmodel in fmodels.items():
    rslt = []
    resid = []
    alp = []
    for col in cols:
        lst = functools.reduce(lambda a,b : '{}+{}'.format(a,b),fmodel)
        lst = '1 + '+lst# all together
        df_ = df.dropna()
        reg = smf.ols('{} ~ {}'.format(col, lst),data=df_).fit(cov_type='HAC',cov_kwds={'maxlags':5})
        resid.append(reg.resid)
        alp.append(reg.params[0])
    resid = pd.concat(resid, axis=1)
    resid_all[ii] = resid
    alphas_all[ii] = alp

df_ = df.dropna()
rslt_grs = []
for num, fmodel in fmodels.items():
    grs_t, grs_p = grs_test(resid_all[num].values, np.reshape(np.array(alphas_all[num]), (len(cols), 1)), df_[fmodels[num]].values)
    grs_t = grs_t[0][0]
    grs_p = grs_p[0][0]*100
    abs_alpa = np.mean(np.abs(alphas_all[num]))
    rslt_grs.append(pd.Series({'abs_alpa':abs_alpa, 'grs_t':grs_t,
                           'grs_p':grs_p},name=num))

    print(abs_alpa, grs_t, grs_p)
rslt_grs = pd.concat(rslt_grs, axis=1)
