#############################################
# programConstructForecastLongShortSubgroup.R
#
# Last modified: 18-Apr-2021
#
# The following are defined in programMain.R:
#
# r
# pHold
# estimateEnetAicc (function)
#############################################

###########
# Load data
###########

# Market excess return
dataReturn = read.xlsx('./Data/dataMarketRx.xlsx')

# Convert date variable to date format
dataReturn$date = as.Date(as.character(dataReturn[ , 1 ]),
                          format = '%Y%m%d')

# Convert to percent return
dataReturn[ , -1 ] = 100*dataReturn[ , -1 ]

# Extract date vector
date = dataReturn[ , 1 ]

# Anomaly returns
dataAnomaly = read.xlsx('./Data/dataLongShortMissing.xlsx')

# Convert date variable to date format
dataAnomaly$date = as.Date(as.character(dataAnomaly[ , 1 ]),
                           format = '%Y%m%d')

# Convert to percent return
dataAnomaly[ , -1 ] = 100*dataAnomaly[ , -1 ]

# Keep data frame with missing anomaly returns
dataAnomalyMissing = dataAnomaly

# Anomaly names
nameAnomaly = names(dataAnomaly)[ -1 ]

#############################################################
# Create list object with anomaly indices to define subgroups
#############################################################

# Load subgroup identifiers
subgroupId = read.xlsx('./Data/dataSubgroupId.xlsx')

# Subgroup names
nameSubgroup = colnames(subgroupId)[ -(1:2) ]

# Storage list object

indexSubgroup = rep(list(NULL),
                    times = length(nameSubgroup))

names(indexSubgroup) = nameSubgroup

# Iterate over subgroups

for ( i in 1:length(nameSubgroup) ){

  # Indices for subgroup i
  indexSubgroup[[ i ]] = na.omit(subgroupId[ , i+2 ])

  # Anomaly names for subgroup i
  names(indexSubgroup[[ i ]]) = nameAnomaly[ indexSubgroup[[ i ]] ]

}

########################################################################
# Create data list object for anomaly subgroups & fill in missing values
########################################################################

# Storage list object (filled-in returns)

dataSubgroup = rep(list(NULL),
                   times = length(indexSubgroup))

names(dataSubgroup) = nameSubgroup

# Storage list object (missing returns)

dataSubgroupMissing = rep(list(NULL),
                          times = length(indexSubgroup))

names(dataSubgroupMissing) = nameSubgroup

# Iterate over subgroups

  for ( i in 1:length(dataSubgroup) ){

    cat(sprintf('%s\n', nameSubgroup[ i ]))

    # Data for subgroup i (ignore date)
    iDataAnomaly = dataAnomaly[ , indexSubgroup[[ i ]]+1 ]

    # Iterate over months

    for ( t in 1:nrow(iDataAnomaly) ){

      # Check for missing values

      if ( sum(is.na(iDataAnomaly[ t , ])) > 0 ){

        # Fill in missing values with cross-sectional mean
        iDataAnomaly[ t , which(is.na(iDataAnomaly[ t , ])) ] =
          apply(iDataAnomaly[ t , ], 1, mean, na.rm = TRUE)

      }

    }

    # Update list object (filled-in returns)
    dataSubgroup[[ i ]] = data.frame(date,
                                     iDataAnomaly)

    # Update list object (missing returns)
    dataSubgroupMissing[[ i ]] =
      data.frame(date,
                 dataAnomalyMissing[ , indexSubgroup[[ i ]]+1 ])

  }

##########################################################
# Take care of preliminaries for out-of-sample forecasting
##########################################################

# Target variable
y = as.matrix(dataReturn[ , -1 ])

# Number of out-of-sample observations (including holdout period)
p = length(date) - r

# Storage vector for realized market excess return
actual = matrix(NA, p, 1)

# Storage list object for C-ENet GR coefficient estimates

coefCenetSub = rep(list(NULL),
                   times = length(nameSubgroup))

names(coefCenetSub) = nameSubgroup

# Storage vector for benchmark forecast
forecastPm = matrix(NA, p, 1)

# Storage list object for univariate predictive regression forecasts

forecastUniSub = rep(list(NULL),
                     times = length(nameSubgroup))

names(forecastUniSub) = nameSubgroup

# Forecasting strategies
forecastName = c('Ols',
                 'Enet',
                 'Combine',
                 'Cenet',
                 'Avg',
                 'Pc',
                 'Pls')

# Storage list object for forecasts based on multiple anomalies

forecastSub = rep(list(matrix(NA, p, length(forecastName))),
                  times = length(nameSubgroup))

names(forecastSub) = nameSubgroup

# Iterate over subgroups

for ( i in 1:length(nameSubgroup) ){

  # Storage matrix
  coefCenetSub[[ i ]] = matrix(NA, p, length(indexSubgroup[[ i ]]))

  # Anomaly names for subgroup
  colnames(coefCenetSub[[ i ]]) = nameAnomaly[ indexSubgroup[[ i ]]]

  # Storage matrix
  forecastUniSub[[ i ]] = matrix(NA, p, length(indexSubgroup[[ i ]]))

  # Anomaly names for subgroup
  colnames(forecastUniSub[[ i ]]) = nameAnomaly[ indexSubgroup[[ i ]]]

  # Forecasting strategy names
  colnames(forecastSub[[ i ]]) = forecastName

}

######################################################
# Compute out-of-sample market excess return forecasts
######################################################

# Iterate over out-of-sample periods

for ( s in 1:p ){

  cat(sprintf('%s\n', date[ r+s ]))

  # Available dependent variable observations
  sy = y[ 1:(r+(s-1)) ]

  # Check if past holdout period

  if ( s > pHold ){

    # Realized market excess return
    actual[ s ] = y[ r+s ]

    # Benchmark forecast
    forecastPm[ s ] = mean(sy)

  }

  # Iterate over subgroups

  for ( i in 1:length(dataSubgroup) ){

    # Available anomaly return observations
    six = as.matrix(dataSubgroup[[ i ]][ 1:(r+(s-1)) , -1 ])

    # Iterate over anomalies

    for ( j in 1:ncol(six) ){

      # Fit univariate predictive regression via OLS
      sijFit = lm(sy[ -1 ] ~ six[ -nrow(six) , j ])

      # OLS forecast for univariate predictive regression
      forecastUniSub[[ i ]][ s , j ] =
        sum(c(1, six[ nrow(six) , j ])*sijFit$coefficients)

    }

    # Check if past holdout period

    if ( s > pHold ){

      # Data frame for OLS
      siDataOls = data.frame(sy[ -1 ],
                             six[ -nrow(six) , ])

      # Clean up variable names
      colnames(siDataOls) = c('MKT',
                              nameAnomaly[ indexSubgroup[[ i ]] ])

      # Check for linear dependence
      ldVar = attributes(
        alias(lm(MKT ~ .,
                 data = siDataOls))$Complete)$dimnames[[ 1 ]]

      # Fix linear dependence if necessary

      if ( length(ldVar) > 0 ){

        # Drop problematic predictors
        siOlsIndex = which(!(colnames(siDataOls)[ -1 ] %in% ldVar))

      # No need to fix linear dependence

      } else {

        # Include all predictors
        siOlsIndex = 1:length(indexSubgroup[[ i ]])

      }

      # Fit multiple predictive regression via OLS
      siFit = lm(sy[ - 1] ~ six[ -nrow(six) , siOlsIndex ])

      # OLS forecast for multiple predictive regression
      forecastSub[[ i ]][ s , 'Ols' ] =
        sum(c(1, six[ nrow(six) , siOlsIndex ])*siFit$coefficients)

      # Fit multiple predictive regression via ENet
      siResult = estimateEnetAicc(six[ -nrow(six) , ],
                                  sy[ -1 ],
                                  lb = -Inf)

      # ENet forecast for multiple predictive regression
      forecastSub[[ i ]][ s , 'Enet' ] =
        sum(c(1, six[ nrow(six) , ])*siResult$b)

      # Simple combination forecast
      forecastSub[[ i ]][ s , 'Combine' ] =
        mean(forecastUniSub[[ i ]][ s , ])

      # Market excess return observations for GR regression
      syGr = sy[ -(1:r) ]

      # Univariate forecasts for GR regression
      sixGr = forecastUniSub[[ i ]][ 1:(s-1) , ]

      # Fit GR regression via ENet
      siResultGr = estimateEnetAicc(sixGr,
                                    syGr,
                                    lb = 0)

      # Store GR slope estimates
      coefCenetSub[[ i ]][ s , ] = siResultGr$b[ -1 ]

      # Univariate forecasts selected by ENet in GR regression
      siCenetIndex = which(siResultGr$b[ -1 ] != 0 )

      # At least one univariate forecast selected

      if ( length(siCenetIndex) > 0 ){

        # Exactly one univariate forecast selected

        if ( length(siCenetIndex) == 1 ){

          # C-ENet forecast
          forecastSub[[ i ]][ s , 'Cenet' ] =
            forecastUniSub[[ i ]][ s , siCenetIndex ]

        # More than one univariate forecast selected

        } else {

          # C-ENet forecast
          forecastSub[[ i ]][ s , 'Cenet' ] =
            mean(forecastUniSub[[ i ]][ s , siCenetIndex ])

        }

      # No univariate forecasts selected

      } else {

        # C-ENet forecast set to benchmark forecast
        forecastSub[[ i ]][ s , 'Cenet' ] = forecastPm[ s ]

      }

      # Available anomaly return observations with missing values
      sixMissing = as.matrix(dataSubgroupMissing[[ i ]][ 1:(r+(s-1)) , -1 ])

      # Vector of cross-sectional averages
      sixAvg = apply(sixMissing, 1, mean, na.rm = TRUE)

      # Fit predictor average regression via OLS
      siFit = lm(sy[ -1 ] ~ sixAvg[ -length(sixAvg) ])

      # OLS forecast for predictor average regression
      forecastSub[[ i ]][ s , 'Avg' ] =
        sum(c(1, sixAvg[ length(sixAvg) ])*siFit$coefficients)

      # Standardize anomaly returns
      sixTilde = scale(six)

      # Fit principal component predictive regression
      siFitPc = pcr(sy[ -1 ] ~ sixTilde[ -nrow(sixTilde) , ],
                    ncomp = 1,
                    scale = FALSE)

      # Principal component predictive regression forecast
      forecastSub[[ i ]][ s , 'Pc' ] =
        predict(siFitPc,
                ncomp = 1,
                newdata = t(sixTilde[ nrow(sixTilde) , ]))

      # Fit predictive regression via PLS
      siFitPls = plsr(sy[ -1 ] ~ sixTilde[ -nrow(sixTilde) , ],
                      ncomp = 1,
                      scale = FALSE)

      # PLS forecast
      forecastSub[[ i ]][ s , 'Pls' ] =
        predict(siFitPls,
                ncomp = 1,
                newdata = t(sixTilde[ nrow(sixTilde) , ]))

    }

  }

}

cat('\n')

########################################
# Create data frames & save as CSV files
########################################

# Forecast evaluation period
date = date[ -(1:(r+pHold)) ]

# Realized values for forecast evaluation period
actual = data.frame(date,
                    actual[ -(1:pHold) ])

# Benchmark forecasts for forecast evaluation period
forecastPm = data.frame(date,
                        forecastPm[ -(1:pHold) ])

# Iterate over subgroups

for ( i in 1:length(nameSubgroup) ){

  # Predicted values for forecast evaluation period
  iForecast = data.frame(date,
                         forecastSub[[ i ]][ -(1:pHold) , ])

  # Save forecasts
  write.csv(iForecast,
            paste0('./Forecast/forecastLongShortHorizon01',
                   nameSubgroup[ i ],
                   '.csv'),
            row.names = FALSE)

}
