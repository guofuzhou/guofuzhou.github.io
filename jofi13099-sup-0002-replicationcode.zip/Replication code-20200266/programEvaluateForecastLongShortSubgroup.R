#############################################
# programEvaluateForecastLongShortSubgroup.R
#
# Last modified: 18-Apr-2021
#
# The following are defined in programMain.R:
#
# computeR2os (function)
#############################################

###################################
# Load realized returns & forecasts
###################################

# Realized excess returns
actual = read.csv('./Forecast/actual.csv')

# Convert date variable to date format
actual$date = as.Date(actual$date)

# One-month horizon
actual = actual[ , 1:2 ]

# Benchmark forecast
forecastPm = read.csv('./Forecast/forecastPm.csv')

# Convert date variable to date format
forecastPm$date = as.Date(forecastPm$date)

# One-month horizon
forecastPm = forecastPm[ , 1:2 ]

# Load subgroup identifiers
subgroupId = read.xlsx('./Data/dataSubgroupId.xlsx')

# Subgroup names
nameSubgroup = colnames(subgroupId)[ -(1:2) ]

# List object for forecasts
forecastSub = rep(list(NULL),
                  times = length(nameSubgroup))

# Iterate over subgroups

for ( i in 1:length(forecastSub) ){
  
  # Forecasts based on subgroup i
  iForecastSub = read.csv(paste0('./Forecast/forecastLongShortHorizon01',
                                 nameSubgroup[ i ],
                                 '.csv'))

  # Convert date variable to date format
  iForecastSub$date = as.Date(iForecastSub$date)

  # Update list object
  forecastSub[[ i ]] = iForecastSub

}

# Forecasting strategies
nameForecast = names(forecastSub[[ i ]])[ -1 ]

#####################################
# Evaluate forecasts in terms of MSFE
#####################################

# Iterate over subgroups

for ( i in 1:length(nameSubgroup) ){

  # Storage matrix for out-of-sample results

  iStat = matrix(NA, length(nameForecast), 2)

  rownames(iStat) = nameForecast

  colnames(iStat) = c('r2os',
                      'cw')

  # Iterate over forecasts

  for ( j in 1:length(nameForecast) ){

    # Evaluate forecasts
    ijResult = computeR2os(actual = actual[ , 2 ],
                           f1 = forecastPm[ , 2 ],
                           f2 = forecastSub[[ i ]][ , j+1 ],
                           h = 1)

    # Store results
    iStat[ j ,  ] = c(ijResult$r2os,
                      ijResult$cw)

  }

  # Convert to table object
  iStat = as.table(round(iStat, 2))

  # Save table
  write.csv(iStat,
            paste0('./Table/tableOosStatLongShortHorizon01',
                   nameSubgroup[ i ],
                   '.csv'))

}
