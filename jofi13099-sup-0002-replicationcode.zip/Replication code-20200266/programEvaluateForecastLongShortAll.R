#############################################
# programEvaluateForecastLongShortAll.R
#
# Last modified: 18-Apr-2021
#
# The following are defined in programMain.R:
#
# h
# computeR2os (function)
#############################################

###################################
# Load realized returns & forecasts
###################################

# Realized excess returns
actual = read.csv('./Forecast/actual.csv')

# Convert date variable to date format
actual$date = as.Date(actual$date)

# Benchmark forecasts
forecastPm = read.csv('./Forecast/forecastPm.csv')

# Convert date variable to date format
forecastPm$date = as.Date(forecastPm$date)

# Storage list object for forecasts

forecastAll = rep(list(NULL),
                  times = length(h))

names(forecastAll) = names(h)

# Iterate over horizons

for ( i in 1:length(h) ){

  # Forecasts based on anomaly returns
  iForecastAll = read.csv(paste0('./Forecast/forecastLongShort',
                                 names(h)[ i ],
                                 'All.csv'))

  # Convert date variable to date format
  iForecastAll$date = as.Date(iForecastAll$date)

  # Update list object
  forecastAll[[ i ]] = iForecastAll

}

# Forecasting strategies
nameForecast = names(forecastAll[[ 1 ]])[ -1 ]

# First year of forecast evaluation period
yearStart = 1985

# Last year of first subsample
yearBreak = 2001

# Index for end of first subsample
breakIndex = (yearBreak - (yearStart - 1))*12

#####################################
# Evaluate forecasts in terms of MSFE
#####################################

# Iterate over horizons

for ( i in 1:length(h) ){

  # Storage matrix for out-of-sample results

  iStat = matrix(NA, length(nameForecast), 2)

  rownames(iStat) = nameForecast

  colnames(iStat) = c('r2os',
                      'cw')

  # Iterate over forecasts

  for ( j in 1:length(nameForecast) ){

    # Collect realized value & forecasts
    ijData = cbind(actual[ , i+1 ],
                   forecastPm[ , i+1 ],
                   forecastAll[[ i ]][ , j+1 ])

    # Remove missing observations due to multi-period return
    ijData = na.omit(ijData)

    # Evaluate forecasts
    ijResult = computeR2os(actual = ijData[ , 1 ],
                           f1 = ijData[ , 2 ],
                           f2 = ijData[ , 3 ],
                           h = h[ i ])

    # Store results
    iStat[ j ,  ] = c(ijResult$r2os,
                      ijResult$cw)

  }

  # Convert to table object
  iStat = as.table(round(iStat, 2))

  # Save table
  write.csv(iStat,
            paste0('./Table/tableOosStatLongShort',
                   names(h)[ i ],
                   'All.csv'))

}

# Storage matrix for out-of-sample results (subsamples)

statSub = matrix(NA, length(nameForecast), 4)

rownames(statSub) = nameForecast

colnames(statSub) = c('r2osSub1',
                      'cwSub1',
                      'r2osSub2',
                      'cwSub2')

# Iterate over forecasts (one-month horizon)

for ( i in 1:length(nameForecast) ){

  # Collect realized value & forecasts (first subsample)
  iDataSub1 = cbind(actual[ 1:breakIndex , 2 ],
                    forecastPm[ 1:breakIndex , 2 ],
                    forecastAll[[ 1 ]][ 1:breakIndex , i+1 ])

  # Collect realized value & forecasts (second subsample)
  iDataSub2 = cbind(actual[ -(1:breakIndex) , 2 ],
                    forecastPm[ -(1:breakIndex) , 2 ],
                    forecastAll[[ 1 ]][ -(1:breakIndex) , i+1 ])

  # Evaluate forecasts (first subsample)
  iResultSub1 = computeR2os(actual = iDataSub1[ , 1 ],
                            f1 = iDataSub1[ , 2 ],
                            f2 = iDataSub1[ , 3 ],
                            h = h[ 1 ])

  # Evaluate forecasts (second subsample)
  iResultSub2 = computeR2os(actual = iDataSub2[ , 1 ],
                            f1 = iDataSub2[ , 2 ],
                            f2 = iDataSub2[ , 3 ],
                            h = h[ 1 ])

  # Store results (first subsample)
  statSub[ i , 1:2 ] = c(iResultSub1$r2os,
                         iResultSub1$cw)

  # Store results (first subsample)
  statSub[ i , 3:4 ] = c(iResultSub2$r2os,
                         iResultSub2$cw)

}

# Convert to table object
statSub = as.table(round(statSub, 2))

# Save table
write.csv(statSub,
          './Table/tableOosStatLongShortHorizon01AllSubsample.csv')
