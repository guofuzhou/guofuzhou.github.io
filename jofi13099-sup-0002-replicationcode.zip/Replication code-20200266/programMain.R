############################
# programMain.R
#
# Last modified: 19-Apr-2021
############################

###############
# Load packages
###############

library(openxlsx)
library(varhandle)
library(glmnet)
library(pls)
library(sandwich)

##################
# Define functions
##################

computeMultiPeriodRetun = function(r, h){

  # Storage matrix for cumulative multi-period return
  rMulti = matrix(NA, length(r), 1)

  # Iterate over periods

  for ( t in 1:(length(r)-(h-1))){

    # Multi-period return
    rMulti[ t ] = mean(r[ t:(t+(h-1)) ])

  }

  return(rMulti)

}

estimateEnetAicc = function(x, y, lb){

  # Total sum of squares
  tss = sum((y - mean(y))^2)

  # ENet estimation
  fit = glmnet(x, y,
               alpha = 0.5,
               nlambda = 200,
               lower.limits = lb)

  # Extract ENet coefficient estimates
  b = coef(fit)

  # Storage vector for R-squared statistics
  r2 = matrix(0, length(fit$lambda), 1)

  # Storage vector for corrected AIC values
  aicc = matrix(0, length(fit$lambda), 1)

  # Iterate over lambda values

  for ( j in 1:length(fit$lambda) ){

    # Residual vector
    ej = y - cbind(matrix(1, length(y), 1), x) %*% b[ , j ]

    # R-squared statistic
    r2[ j ] = 1 - sum(ej^2)/tss

    # Corrected AIC
    aicc[ j ] = length(y)*log(sum(ej^2)/length(y)) +
      2*fit$df[ j ]*length(y)/(length(y) - fit$df[ j ] - 1)

  }

  # Optimal lambda

  minIndex = which.min(aicc)

  lambda = fit$lambda[ minIndex ]

  # Vector of final ENet coefficient estimates
  b = b[ , minIndex ]

  # R-squared statistic for vector of final ENet coefficient estimates
  r2 = r2[ minIndex ]

  # List object for output
  result = list('lambda' = lambda,
                'b' = b,
                'r2' = r2,
                'minIndex' = minIndex)

  return(result)

}

computeR2os = function(actual, f1, f2, h){

  # MSFE for benchmark forecast (1)
  msfe1 = mean((actual-f1)^2)

  # MSFE for competing forecast (2)
  msfe2 = mean((actual-f2)^2)

  # Campbell-Thompson out-of-sample R-squared statistic
  r2os = 100*(1 - msfe2/msfe1)

  # Loss differential
  d = (actual - f1)^2 - (actual - f2)^2

  # Adjusted loss differential
  f = d + (f1 - f2)^2

  # Clark-West regression
  fit = lm(f ~ 1)

  # Robust variance
  var = NeweyWest(fit,
                  lag = h,
                  prewhite = FALSE)

  # Clark-West statistic
  cw = fit$coefficients/sqrt(var)

  # List object for output
  result = list('r2os' = r2os,
                'cw' = cw)

  return(result)

}

############################
# Take care of preliminaries
############################

# Forecast horizons

h = c(1, 2, 3, 6, 12)

names(h) = c('Horizon01',
             'Horizon02',
             'Horizon03',
             'Horizon06',
             'Horizon12')

# Number of initial in-sample observations
r = 120

# Number of holdout out-of-sample observations
pHold = 60

############################
# Compute summary statistics
############################

# Data files for anomaly returns
fileData = c('dataLongShortMissing.xlsx',
             'dataLongMissing.xlsx',
             'dataShortMissing.xlsx')

# Portfolio types
type = c('LongShort',
         'Long',
         'Short')

# Compute statistics
source('programComputeStat.R')

# Clear up some memory
rm.all.but(keep = c('h', 'r', 'pHold'),
           keep_functions = TRUE)

##########################################
# Compute/evaluate market return forecasts
##########################################

# Construct market excess return forecasts - all long-short returns
source('programConstructForecastLongShortAll.R')

# Clear up some memory
rm.all.but(keep = c('h', 'r', 'pHold'),
           keep_functions = TRUE)

# Evaluate market excess return forecasts - all long-short returns
source('programEvaluateForecastLongShortAll.R')

# Clear up some memory
rm.all.but(keep = c('r', 'pHold'),
           keep_functions = TRUE)

# Economic value - all long-short returns
source('programComputeDeltaLongShortAll.R')

# Clear up some memory
rm.all.but(keep = c('r', 'pHold'),
           keep_functions = TRUE)

# Anomaly portfolio legs
leg = c('Long',
        'Short')

# Iterate over legs

for ( i in 1:length(leg) ){

  # Anomaly portfolio leg
  nameLeg = leg[ i ]

  # Construct market excess return forecasts
  source('programConstructForecastLegAll.R')

  # Clear up some memory
  rm.all.but(keep = c('leg', 'nameLeg', 'r', 'pHold'),
             keep_functions = TRUE)

  # Evaluate market excess return forecasts
  source('programEvaluateForecastLegAll.R')

  # Clear up some memory
  rm.all.but(keep = c('leg', 'nameLeg', 'r', 'pHold'),
             keep_functions = TRUE)

}

# Compute recursive slope coefficients
source('programComputeRecursiveAvgPcPls.R')

# Clear up some memory
rm.all.but(keep = c('r', 'pHold'),
           keep_functions = TRUE)

# Construct market excess return forecasts - subgroups
source('programConstructForecastLongShortSubgroup.R')

# Clear up some memory
rm.all.but(keep = c('r', 'pHold'),
           keep_functions = TRUE)

# Evaluate market excess return forecasts - subgroups
source('programEvaluateForecastLongShortSubgroup.R')
