#############################################
# programConstructForecastLongShortAll.R
#
# Last modified: 18-Apr-2021
#
# The following are defined in programMain.R:
#
# h
# r
# pHold
# computeMultiPeriodRetun (function)
# estimateEnetAicc (function)
#############################################

####################
# Load/organize data
####################

# Market excess return
dataReturn = read.xlsx('./Data/dataMarketRx.xlsx')

# Convert date variable to date format
dataReturn$date = as.Date(as.character(dataReturn$date),
                          format = '%Y%m%d')

# Convert to percent return
dataReturn[ , -1 ] = 100*dataReturn[ , -1 ]

# Extract date vector
date = dataReturn[ , 1 ]

# Anomaly returns
dataAnomaly = read.xlsx('./Data/dataLongShortMissing.xlsx')

# Convert date variable to date format
dataAnomaly$date = as.Date(as.character(dataAnomaly$date),
                           format = '%Y%m%d')

# Convert to percent return
dataAnomaly[ , -1 ] = 100*dataAnomaly[ , -1 ]

# Keep data frame with missing anomaly returns
dataAnomalyMissing = dataAnomaly

# Iterate over months

for ( t in 1:nrow(dataAnomaly) ){

  # Check for missing values

  if ( sum(is.na(dataAnomaly[ t , ])) > 0 ){

    # Fill in missing values with cross-sectional mean
    dataAnomaly[ t , which(is.na(dataAnomaly[ t , ])) ] =
      apply(dataAnomaly[ t , -1 ], 1, mean, na.rm = TRUE)

  }

}

# Anomaly names
nameAnomaly = names(dataAnomaly)[ -1 ]

##########################################################
# Take care of preliminaries for out-of-sample forecasting
##########################################################

# Forecasting strategies
nameForecast = c('Ols',
                 'Enet',
                 'Combine',
                 'Cenet',
                 'Avg',
                 'Pc',
                 'Pls')

# Target variable
y = as.matrix(dataReturn[ , -1 ])

# Number of out-of-sample observations (including holdout period)
p = length(date) - r

# Storage matrix for realized market excess return

actual = matrix(NA, p, length(h))

colnames(actual) = names(h)

# Storage list object for C-ENet GR coefficient estimates

coefCenetAll = rep(list(matrix(NA, p, length(nameAnomaly))),
                   times = length(h))

names(coefCenetAll) = names(h)

# Storage matrix for benchmark forecast

forecastPm = matrix(NA, p, length(h))

colnames(forecastPm) = names(h)

# Storage list object for univariate forecasts

forecastUniAll = rep(list(matrix(NA, p, length(nameAnomaly))),
                     times = length(h))

names(forecastUniAll) = names(h)

# Storage list object for forecasts based on multiple anomalies

forecastAll = rep(list(matrix(NA, p, length(nameForecast))),
                  times = length(h))

names(forecastAll) = names(h)

# Iterate over forecast horizons

for ( i in 1:length(h) ){

  # Anomaly names for columns
  colnames(coefCenetAll[[ i ]]) = nameAnomaly

  # Anomaly names for columns
  colnames(forecastUniAll[[ i ]]) = nameAnomaly

  # Forecast names for columns
  colnames(forecastAll[[ i ]]) = nameForecast

}

######################################################
# Compute out-of-sample market excess return forecasts
######################################################

# Iterate over out-of-sample periods

for ( s in 1:p ){

  cat(sprintf('%s\n', date[ r+s ]))

  # Available dependent variable observations
  sy = y[ 1:(r+(s-1)) ]

  # Iterate over forecast horizons

  for ( i in 1:length(h) ){

    # Cumulative multi-period return for horizon h
    siy = computeMultiPeriodRetun(sy, h[ i ])

    # Check if past holdout period

    if ( s > pHold ){

      # Check if multi-period return available

      if ( s <= p-(h[ i ]-1)  ){

        # Realized market excess return
        actual[ s , i ] = mean(y[ (r+s):(r+s+(h[ i ]-1)) ])

      }

      # Benchmark forecast
      forecastPm[ s , i ] = mean(siy, na.rm = TRUE)

    }

    # Available anomaly return observations
    sx = as.matrix(dataAnomaly[ 1:(r+(s-1)) , -1 ])

    # Collect market excess return & anomaly returns
    siData = cbind(siy, sx)

    # Remove missing observations due to multi-period return
    siData = na.omit(siData)

    # Dependent variable vector
    siy = as.matrix(siData[ , 1 ])

    # Data matrix
    six = as.matrix(siData[ , -1 ])

    # Iterate over anomalies

    for ( j in 1:ncol(six) ){

      # Fit univariate predictive regression via OLS
      sijFit = lm(siy[ -1 ] ~ six[ -nrow(six) , j ])
  
      # OLS forecast for univariate preditive regression
      forecastUniAll[[ i ]][ s , j ] =
        sum(c(1, sx[ nrow(sx) , j ])*sijFit$coefficients)

    }

    # Check if past holdout period

    if ( s > pHold ){

      # Data frame for OLS
      siDataOls = data.frame(siy[ -1 ],
                             six[ -nrow(six) , ])

      # Clean up variable names
      colnames(siDataOls) = c('MKT',
                              nameAnomaly)

      # Check for linear dependence
      ldVar = attributes(alias(lm(MKT ~ .,
                                  data = siDataOls))$Complete)$dimnames[[ 1 ]]

      # Fix linear dependence if needed

      if ( length(ldVar) > 0 ){

        # Drop problematic predictors
        siOlsIndex = which(!(colnames(siDataOls)[ -1 ] %in% ldVar))

      # No need to fix linear dependence

      } else {

        # Include all predictors
        siOlsIndex = 1:length(nameAnomaly)

      }

      # Fit multiple predictive regression via OLS
      siFit = lm(siy[ -1] ~ six[ -nrow(six) , siOlsIndex ])

      # OLS forecast for predictive multiple regression
      forecastAll[[ i ]][ s , 'Ols' ] =
        sum(c(1, sx[ nrow(sx) , siOlsIndex ])*siFit$coefficients)

      # Fit multiple predictive regression via ENet
      siResult = estimateEnetAicc(six[ -nrow(six) , ],
                                  siy[ -1 ],
                                  lb = -Inf)

      # ENet forecast for multiple predictive regression
      forecastAll[[ i ]][ s , 'Enet' ] = sum(c(1, sx[ nrow(sx) , ])*siResult$b)

      # Simple combination forecast
      forecastAll[[ i ]][ s , 'Combine' ] = mean(forecastUniAll[[ i ]][ s , ])

      # Market excess return observations for GR regression
      siyGr = siy[ -(1:r) ]

      # Univariate forecasts for GR regression
      sixGr = forecastUniAll[[ i ]][ 1:((s-1)-(h[ i ]-1)) , ]

      # Fit GR regression via ENet
      siResultGr = estimateEnetAicc(sixGr,
                                    siyGr,
                                    lb = 0)

      # Store GR slope estimates
      coefCenetAll[[ i ]][ s , ] = siResultGr$b[ -1 ]

      # Univariate forecasts selected by ENet in GR regression
      siCenetIndex = which(siResultGr$b[ -1 ] != 0 )

      # At least one univariate forecast selected

      if ( length(siCenetIndex) > 0 ){

        # Exactly one univariate forecast selected

        if ( length(siCenetIndex) == 1 ){

          # C-ENet forecast
          forecastAll[[ i ]][ s , 'Cenet' ] =
            forecastUniAll[[ i ]][ s , siCenetIndex ]

          # More than one univariate forecast selected

        } else {

          # C-ENet forecast
          forecastAll[[ i ]][ s , 'Cenet' ] =
            mean(forecastUniAll[[ i ]][ s , siCenetIndex ])

        }

      # No univariate forecasts selected

      } else {

        # C-ENet forecast set to benchmark forecast
        forecastAll[[ i ]][ s , 'Cenet' ] = forecastPm[ s , i ]

      }

      # Available anomaly return observations with missing values
      sxMissing = as.matrix(dataAnomalyMissing[ 1:(r+(s-1)) , -1 ])

      # Vector of cross-sectional averages
      sxAvg = apply(sxMissing, 1, mean, na.rm = TRUE)

      # Predictor variable vector for predictor average regression
      sixAvg = sxAvg[ 1:(r+(s-1)-(h[ i ]-1)) ]

      # Fit predictor average regression via OLS
      siFit = lm(siy[ -1 ] ~ sixAvg[ -length(sixAvg) ])

      # OLS forecast for predictor average regression
      forecastAll[[ i ]][ s , 'Avg' ] =
        sum(c(1, sxAvg[ length(sxAvg) ])*siFit$coefficients)

      # Standardize anomaly returns
      sxTilde = scale(sx)

      # Data matrix for PC/PLS regressions
      sixTilde = sxTilde[ 1:(r+(s-1)-(h[ i ]-1)) , ]

      # Fit principal component predictive regression
      siFitPc = pcr(siy[ -1 ] ~ sixTilde[ -nrow(sixTilde) , ],
                    ncomp = 1,
                    scale = FALSE)

      # Principal component predictive regression forecast
      forecastAll[[ i ]][ s , 'Pc' ] =
        predict(siFitPc,
                ncomp = 1,
                newdata = t(sxTilde[ nrow(sxTilde) , ]))

      # Fit predictive regression via PLS
      siFitPls = plsr(siy[ -1 ] ~ sixTilde[ -nrow(sixTilde) , ],
                      ncomp = 1,
                      scale = FALSE)

      # PLS forecast
      forecastAll[[ i ]][ s , 'Pls' ] =
        predict(siFitPls,
                ncomp = 1,
                newdata = t(sxTilde[ nrow(sxTilde) , ]))

    }

  }

}

cat('\n')

########################################
# Create data frames & save as CSV files
########################################

# Forecast evaluation period
date = date[ -(1:(r+pHold)) ]

# Realized values for forecast evaluation period
actual = data.frame(date,
                    actual[ -(1:pHold) , ])

# Benchmark forecasts for forecast evaluation period
forecastPm = data.frame(date,
                        forecastPm[ -(1:pHold) , ])

# Save realized values
write.csv(actual,
          './Forecast/actual.csv',
          row.names = FALSE)

# Save benchmark forecasts
write.csv(forecastPm,
          './Forecast/forecastPm.csv',
          row.names = FALSE)

# Iterate over forecast horizons

for ( i in 1:length(h) ){

  # Predicted values for forecast evaluation period
  iForecast = data.frame(date,
                         forecastAll[[ i ]][ -(1:pHold) , ])

  # Save forecasts
  write.csv(iForecast,
            paste0('./Forecast/forecastLongShort',
                   names(h)[ i ],
                   'All.csv'),
            row.names = FALSE)

}
