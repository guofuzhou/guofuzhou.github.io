#############################################
# programEvaluateForecastLegAll.R
#
# Last modified: 18-Apr-2021
#
# The following are defined in programMain.R:
#
# nameLeg
# computeR2os (function)
#############################################

###################################
# Load realized returns & forecasts
###################################

# Realized excess returns
actual = read.csv('./Forecast/actual.csv')

# Convert date variable to date format
actual$date = as.Date(actual$date)

# One-month horizon
actual = actual[ , 1:2 ]

# Benchmark forecast
forecastPm = read.csv('./Forecast/forecastPm.csv')

# Convert date variable to date format
forecastPm$date = as.Date(forecastPm$date)

# One-month horizon
forecastPm = forecastPm[ , 1:2 ]

# Forecasts based on anomaly returns
forecastAll = read.csv(paste0('./Forecast/forecast',
                              nameLeg,
                              'Horizon01All.csv'))

# Convert date variable to date format
forecastAll$date = as.Date(forecastAll$date)

# Forecasting strategies
nameForecast = names(forecastAll)[ -1 ]

#####################################
# Evaluate forecasts in terms of MSFE
#####################################

# Storage matrix for out-of-sample results

stat = matrix(NA, length(nameForecast), 2)

rownames(stat) = nameForecast

colnames(stat) = c('r2os',
                   'cw')

# Iterate over forecasts

for ( i in 1:length(nameForecast) ){

  # Collect realized value & forecasts
  iData = cbind(actual[ , 2 ],
                forecastPm[ , 2 ],
                forecastAll[ , i+1 ])

  # Evaluate forecasts
  iResult = computeR2os(actual = iData[ , 1 ],
                        f1 = iData[ , 2 ],
                        f2 = iData[ , 3 ],
                        h = 1)

  # Store results
  stat[ i ,  ] = c(iResult$r2os,
                   iResult$cw)

}

# Convert to table object
stat = as.table(round(stat, 2))

# Save table
write.csv(stat,
          paste0('./Table/tableOosStat',
                 nameLeg,
                 'Horizon01All.csv'))
