#############################################
# programConstructForecastLegAll.R
#
# Last modified: 18-Apr-2021
#
# The following are defined in programMain.R:
#
# nameLeg
# h
# r
# pHold
# estimateEnetAicc (function)
#############################################

###########
# Load data
###########

# Market excess return
dataReturn = read.xlsx('./Data/dataMarketRx.xlsx')

# Convert date variable to date format
dataReturn$date = as.Date(as.character(dataReturn$date),
                          format = '%Y%m%d')

# Convert to percent return
dataReturn[ , -1 ] = 100*dataReturn[ , -1 ]

# Extract date vector
date = dataReturn[ , 1 ]

# Anomaly returns
dataAnomaly = read.xlsx(paste0('./Data/data',
                               nameLeg,
                               'Missing.xlsx'))

# Convert date variable to date format
dataAnomaly$date = as.Date(as.character(dataAnomaly[ , 1 ]),
                           format = '%Y%m%d')

# Convert to percent return
dataAnomaly[ , -1 ] = 100*dataAnomaly[ , -1 ]

# Keep data frame with missing anomaly returns
dataAnomalyMissing = dataAnomaly

# Iterate over months

for ( t in 1:nrow(dataAnomaly) ){

  # Check for missing values

  if ( sum(is.na(dataAnomaly[ t , ])) > 0 ){

    # Fill in missing values with cross-sectional mean
    dataAnomaly[ t , which(is.na(dataAnomaly[ t , ])) ] =
      apply(dataAnomaly[ t , -1 ], 1, mean, na.rm = TRUE)

  }

}

# Anomaly names
nameAnomaly = names(dataAnomaly)[ -1 ]

##########################################################
# Take care of preliminaries for out-of-sample forecasting
##########################################################

# Forecasting strategies
nameForecast = c('Ols',
                 'Enet',
                 'Combine',
                 'Cenet',
                 'Avg',
                 'Pc',
                 'Pls')

# Target variable
y = as.matrix(dataReturn[ , -1 ])

# Number of out-of-sample observations (including holdout period)
p = length(date) - r

# Storage vector for realized market excess return
actual = matrix(NA, p, 1)

# Storage matrix for C-ENet GR coefficient estimates

coefCenetAll = matrix(NA, p, length(nameAnomaly))

colnames(coefCenetAll) = nameAnomaly

# Storage vector for benchmark forecast
forecastPm = matrix(NA, p, 1)

# Storage matrix for univariate forecasts

forecastUniAll = matrix(NA, p, length(nameAnomaly))

colnames(forecastUniAll) = nameAnomaly

# Storage matrix for forecasts based on multiple anomalies

forecastAll = matrix(NA, p, length(nameForecast))

colnames(forecastAll) = nameForecast

######################################################
# Compute out-of-sample market excess return forecasts
######################################################

# Iterate over out-of-sample periods

for ( s in 1:p ){

  cat(sprintf('%s\n', date[ r+s ]))

  # Available dependent variable observations
  sy = y[ 1:(r+(s-1)) ]

  # Check if past holdout period

  if ( s > pHold ){

    # Realized market excess return
    actual[ s ] = y[ r+s ]

    # Benchmark forecast
    forecastPm[ s ] = mean(sy)

  }

  # Available anomaly return observations
  sx = as.matrix(dataAnomaly[ 1:(r+(s-1)) , -1 ])

  # Iterate over anomalies

  for ( j in 1:ncol(sx) ){

    # Fit univariate predictive regression via OLS
    sjFit = lm(sy[ -1 ] ~ sx[ -nrow(sx) , j ])

    # OLS forecast for univariate predictive regression
    forecastUniAll[ s , j ] = sum(c(1, sx[ nrow(sx) , j ])*sjFit$coefficients)

  }

  # Check if past holdout period

  if ( s > pHold ){

    # Data frame for OLS
    sDataOls = data.frame(sy[ -1 ],
                          sx[ -nrow(sx) , ])

    # Clean up variable names
    colnames(sDataOls) = c('MKT',
                           nameAnomaly)

    # Check for linear dependence
    ldVar = attributes(alias(lm(MKT ~ .,
                                data = sDataOls))$Complete)$dimnames[[ 1 ]]

    # Fix linear dependence if necessary

    if ( length(ldVar) > 0 ){

      # Drop problematic predictors
      sOlsIndex = which(!(colnames(sDataOls)[ -1 ] %in% ldVar))

    # No need to fix linear dependence

    } else {

      # Include all predictors
      sOlsIndex = 1:length(nameAnomaly)

    }

    # Fit multiple predictive regression via OLS
    sFit = lm(sy[ - 1] ~ sx[ -nrow(sx) , sOlsIndex ])

    # OLS forecast for multiple predictive regression
    forecastAll[ s , 'Ols' ] =
      sum(c(1, sx[ nrow(sx) , sOlsIndex ])*sFit$coefficients)

    # Fit multiple predictive regression via ENet
    sResult = estimateEnetAicc(sx[ -nrow(sx) , ],
                                 sy[ -1 ],
                                 lb = -Inf)

    # ENet forecast for multiple predictive regression
    forecastAll[ s , 'Enet' ] = sum(c(1, sx[ nrow(sx) , ])*sResult$b)

    # Simple combination forecast
    forecastAll[ s , 'Combine' ] = mean(forecastUniAll[ s , ])

    # Market excess return observations for GR regression
    syGr = sy[ -(1:r) ]

    # Univariate forecasts for GR regression
    sxGr = forecastUniAll[ 1:(s-1) , ]

    # Fit GR regression via ENet
    sResultGr = estimateEnetAicc(sxGr,
                                 syGr,
                                 lb = 0)

    # Store GR slope estimates
    coefCenetAll[ s , ] = sResultGr$b[ -1 ]

    # Univariate forecasts selected by ENet in GR regression
    sCenetIndex = which(sResultGr$b[ -1 ] != 0 )

    # At least one univariate forecast selected

    if ( length(sCenetIndex) > 0 ){

      # Exactly one univariate forecast selected

      if ( length(sCenetIndex) == 1 ){

        # C-ENet forecast
        forecastAll[ s , 'Cenet' ] = forecastUniAll[ s , sCenetIndex ]

      # More than one univariate forecast selected

      } else {

        # C-ENet forecast
        forecastAll[ s , 'Cenet' ] = mean(forecastUniAll[ s , sCenetIndex ])

      }

    # No univariate forecasts selected

    } else {

      # C-ENet forecast set to benchmark forecast
      forecastAll[ s , 'Cenet' ] = forecastPm[ s ]

    }

    # Available anomaly return observations with missing values
    sxMissing = as.matrix(dataAnomalyMissing[ 1:(r+(s-1)) , -1 ])

    # Vector of cross-sectional averages
    sxAvg = apply(sxMissing, 1, mean, na.rm = TRUE)

    # Fit predictor average regression via OLS
    sFit = lm(sy[ -1 ] ~ sxAvg[ -length(sxAvg) ])

    # OLS forecast for predictor average regression
    forecastAll[ s , 'Avg' ] =
      sum(c(1, sxAvg[ length(sxAvg) ])*sFit$coefficients)

    # Standardize anomaly returns
    sxTilde = scale(sx)

    # Fit principal component predictive regression
    sFitPc = pcr(sy[ -1 ] ~ sxTilde[ -nrow(sxTilde) , ],
                 ncomp = 1,
                 scale = FALSE)

    # Principal component predictive regression forecast
    forecastAll[ s , 'Pc' ] = predict(sFitPc,
                                      ncomp = 1,
                                      newdata = t(sxTilde[ nrow(sxTilde) , ]))

    # Fit predictive regression via PLS
    sFitPls = plsr(sy[ -1 ] ~ sxTilde[ -nrow(sxTilde) , ],
                   ncomp = 1,
                   scale = FALSE)

    # PLS forecast
    forecastAll[ s , 'Pls' ] = predict(sFitPls,
                                       ncomp = 1,
                                       newdata = t(sxTilde[ nrow(sxTilde) , ]))

  }

}

cat('\n')

########################################
# Create data frames & save as CSV files
########################################

# Forecast evaluation period
date = date[ -(1:(r+pHold)) ]

# Realized values for forecast evaluation period
actual = data.frame(date,
                    actual[ -(1:pHold) ])

# Benchmark forecasts for forecast evaluation period
forecastPm = data.frame(date,
                        forecastPm[ -(1:pHold) ])

# Predicted values for forecast evaluation period
forecastAll = data.frame(date,
                         forecastAll[ -(1:pHold) , ])

# Save forecasts
write.csv(forecastAll,
          paste0('./Forecast/forecast',
                 nameLeg,
                 'Horizon01All.csv'),
          row.names = FALSE)
