
# coding: utf-8

# In[1]:


import numpy as np
import statsmodels.api as sm

from collections import namedtuple


# In[1]:


def olsnw(Y,X,nwlags=0):
    """ OLS with Newey-West HC estimator
    ___________
    Parameters:
    Y: T-by-1, dependent variable
    X: T-by-K, independent variables without constant. The constant term will be added.
    nwlags: number of lags in Newey-West estimator. If set to 0, it estimates White's HC estimator (HC0)
            default 0.
    _______
    Return:
    B: A K+1 vector, the first component is the intercept
    tstat: t-statistics 
    pvals: p values for t tests
    bse: Newey-West estimator of standard error of betas(B)
    adjR2: Adjusted R-squared
    Yhat: Fitted values
    """
    X = sm.add_constant(X) # add constant
    
    model = sm.OLS(Y,X)
    res = model.fit(cov_type='HAC',cov_kwds={'maxlags':nwlags},use_t=True)
    
    B = res.params
    tstat = res.tvalues
    pvals = res.pvalues
    bse = res.bse
    adjR2 = res.rsquared_adj
    Yhat = res.fittedvalues
    
    olsnw = namedtuple('olsnw',['beta_est','tstat','p_value','NW_est','adjR2','y_fitted'])
    
    return olsnw(B,tstat,pvals,bse,adjR2,Yhat)
    
    
    

