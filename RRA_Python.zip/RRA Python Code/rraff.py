
# coding: utf-8

# In[114]:


import numpy as np
from numpy.linalg import inv, eig
from scipy.linalg import fractional_matrix_power as power

import pandas as pd

import statsmodels.api as sm
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
from sklearn.decomposition import PCA
from sklearn.cross_decomposition import PLSRegression

from collections import namedtuple


# In[117]:


def rraff(R,G,K):
    """ Using R=a+BG+u to extract K factors
    ___________
    Parameters:
    R: T-by-N, excess returns of N assets
    G: T-by-L, L proxies
    K: the number of factors to be extracted from the L proxies (G)
    _______
    Return:
    rraf: T-by-K factors via RRA 
    pcaf: T-by-K factors via PCA
    plsf: T-by-K factors via PLS
    """
    T,L = G.shape
    N = R.shape[1]
    Z = sm.add_constant(G) # Z = [ones G]
    M = L+1
    
    X = np.ones((T,1))
    
    W1 = np.identity(N)
    W2 = np.identity(M)
    P0 = Z @ W2 @ Z.T
    P = P0 - P0 @ X @ inv(X.T@P0@X) @ X.T @ P0
    Q = (G.T @ P @ G)/T**2
    A = power(Q,-.5).T @ (G.T @ P @ R/T**2) @ W1 @ (G.T @ P @ R/T**2).T @ power(Q,-.5)
    v,E = eig(A)
    ind = v.argsort()[::-1]   
    E = E[:,ind]
    Phi = power(Q,-.5) @ E[:,:K]
    Gstar=G @ Phi
    Beta = inv(Gstar.T @ P @ Gstar) @ Gstar.T @ P @ R 
    Theta = Phi @ Beta
    Alpha = inv(X.T @ P0 @ X) @ X.T @ P0 @ (R - G @ Theta)
    Alpha = Alpha.T
    U = R - X @ Alpha.T - G @ Theta
    S1 = np.diag(np.diag(U.T@U/T))
    S2 = np.diag(np.diag(Z.T@Z/T))
    
    W1 = inv(S1)
    W2 = inv(S2)
    P0 = Z @ W2 @ Z.T
    P = P0 - P0 @ X @ inv(X.T@P0@X) @ X.T @ P0
    Q = (G.T @ P @ G)/T**2
    A = power(Q,-.5).T @ (G.T @ P @ R/T**2) @ W1 @ (G.T @ P @ R/T**2).T @ power(Q,-.5)
    v,E = eig(A)
    ind = v.argsort()[::-1]   
    E = E[:,ind]
    Phi = power(Q,-.5) @ E[:,:K]
    Gstar=G @ Phi
    
    rraf = Gstar.real
    
    pca = PCA(n_components=K)
    G = sc.fit_transform(G)
    pcaf = pca.fit_transform(G)
    
    pls = PLSRegression(n_components=K,scale=False)
    X = sc.fit_transform(G)
    plsf = pls.fit(X=X,Y=R).x_scores_
    
    rraff = namedtuple('rraff',['rraf','pcaf','plsf'])
    
    return rraff(rraf,pcaf,plsf)

