function OUTres = performance_portfolio(ret, FF)
% calculate total R2 and PE
% ret: T*N FF T*K they are already matched

[T,N] = size(ret);
res = []; 
for i = 1:N
    i
    Ri = ret(:,i);
 %[b, tstat, s2, vcvnw, R2, rbar, yhat] = olsnw(Ri,FF ,1,0);
 [b,bse,~,~,~] = regress_jc(Ri,[ones(length(Ri),1),FF],0);
  
  adj = (length(Ri)-1)/(length(Ri)-1-size(FF,2));
  yhat = [ones(length(Ri),1),FF]*b;
  Res_Ri2 = sum((Ri-yhat).^2)*adj; 
  Ri2 = sum(Ri.^2);
  Alpha = b(1);
  Sig_res = std(Ri-yhat);
  Rbar = mean(Ri);

  %%          1        2    3      4        5          
  res = [res; Res_Ri2, Ri2, Alpha, Sig_res, Rbar];
 
end
 
MPE = 100*sqrt(mean(res(:,3).^2));
TotalR2 = 100*(1- sum(res(:,1))/sum(res(:,2)) );
SR = mean( abs( res(:,3)./res(:,4) ) );
A2R = mean( abs(res(:,3)./res(:,5)) ); 
OUTres = [MPE, TotalR2, SR, A2R];
 