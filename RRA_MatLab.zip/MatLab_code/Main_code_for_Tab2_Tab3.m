clear;clc
%% For Panels A and B of Tabs 2

st_date = 197401; et_date = 201612;
z = xlsread('Portfolio_returns.xlsx','FF5','A2:I653','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
rf = z(tt,7)/100;
tdate = z(tt,1);

%% Factor proxies G
z = xlsread('Portfolio_returns.xlsx','Anomaly','A3:AE518','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
f5 = z(tt,2:7)/100; %benchmark: 1, 3, 5, 6 factors
G = z(tt,2:end)/100;
[T,L] = size(G);

%% 48 Industries
z = xlsread('Portfolio_returns.xlsx','FF48vw','A3:AW530','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
N = size(z,2)-1;
R48 = z(tt,2:end)/100 - rf*ones(1,N);

%% 202 characteristic portfolios
z = xlsread('Portfolio_returns.xlsx','Dacheng202vw','A3:GU554','basic'); 
tt = find(z(:,1)>=st_date & z(:,1)<=et_date);
N = size(z,2)-1;
R202 = z(tt,2:end)/100 - rf*ones(1,N);
  
NF = [1 3 5 6]; % number of factors
NoFF = 4; % number of models: FF, PCA, PLS, and RRA

MPE = nan(NoFF,size(NF,2),4);  TR2 = nan(NoFF,size(NF,2),4);  
SR = nan(NoFF,size(NF,2),4);   A2R = nan(NoFF,size(NF,2),4);   

 
for j =1:size(NF,2); % No. of factors
mu = mean(G);
y1 = G'*G/T-mu'*mu;
[E,v] = eig(y1);
[v,ind] = sort(diag(v),'descend');
E = E(:,ind(1:NF(j))); 
pcaf = G*E*inv(E'*E);

 
 [~,~,~,~,~,~,~,stats] = plsregress(G,R48,NF(j));% R48 are basis assets
  plsf = G*stats.W; 
 
 rra48  = func_rraff(R48,G,NF(j)); % R48 are basis assets
 
 FFs = nan(T,NF(j),NoFF);
 FFs(:,:,1)  = f5(:,1:NF(j));
 FFs(:,:,2)  = pcaf;  FFs(:,:,3)= plsf;  FFs(:,:,4)= rra48;

 for i = 1:NoFF;  % No. of models
           
      ff = FFs(:,:,i);  
      
      res  = performance_portfolio(R48, ff); % OUTres = [MPE, TotalR2, SR, A2R];
      MPE(i,j,1) = res(1); TR2(i,j,1) = res(2); 
      SR(i,j,1)=res(3); A2R(i,j,1) = res(4);
      
      res = performance_portfolio(R202, ff);
      MPE(i,j,2)=res(1); TR2(i,j,2)= res(2); 
      SR(i,j,2) =res(3); A2R(i,j,2)= res(4);
    
    end
    clear ff FFs;
end
Panel_A = [MPE(:,:,1),TR2(:,:,1)]
Panel_B = [MPE(:,:,2),TR2(:,:,2)]
 
